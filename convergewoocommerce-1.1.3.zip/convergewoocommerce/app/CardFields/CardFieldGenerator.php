<?php

namespace App\CardFields;

use App\CardFields\Properties\FieldProperties;

/**
 * Class CardFieldGenerator
 * @package App\CardFields
 */
class CardFieldGenerator
{

    /**
     * @param FieldProperties[] $fieldProperties
     * @param array $customCSSClasses
     * @return string
     */
    public function addCardField($fieldProperties, $customCSSClasses = [])
    {
        $defaultCSSClasses = ['form-row', 'validate-required'];
        $cssClasess = empty($customCSSClasses) ? $defaultCSSClasses : array_merge($defaultCSSClasses,
            $customCSSClasses);
        $generatedFields = array_map(function (/** @var FieldProperties $properties */ $properties) {
            return $properties->hasLabel()
                ? $this->addLabel($properties) . $this->addField($properties)
                : $this->addField($properties);
        }, $fieldProperties);
        return '<p class="' . implode(' ', $cssClasess) . '">' . implode($generatedFields) . '</p>';
    }

    /**
     * @param FieldProperties $properties
     * @return string
     */
    protected function addLabel($properties)
    {
        $requiredMarker = $properties->isRequired() ? $this->requiredMarker() : null;
        return $this->label($properties->getFor(), $properties->name(), $properties->text(), $requiredMarker);
    }

    /**
     * @return string
     */
    private function requiredMarker()
    {
        return '&nbsp;<abbr class="required" title="required">*</abbr>';
    }

    /**
     * @param string $for
     * @param string $name
     * @param string $text
     * @param string|null $requiredMarker
     * @return string
     */
    private function label($for, $name, $text, $requiredMarker = null)
    {
        return $requiredMarker === null
            ? '<label for="' . $for . '-' . $name . '">' . $text . '</label>'
            : '<label for="' . $for . '-' . $name . '">' . $text . $requiredMarker . '</label>';
    }

    /**
     * @param FieldProperties $properties
     * @return string
     */
    protected function addField($properties)
    {
        $inputField = '<input type="text" ' . $this->generateFieldAttributes($properties->getFieldAttributes()) . ' />';
        return '<span class="woocommerce-input-wrapper">' . $inputField . '</span>';
    }

    /**
     * @param array $attributes
     * @return string
     */
    private function generateFieldAttributes($attributes)
    {
        $fieldAttributes = '';
        foreach ($attributes as $attribute => $attributeValue) {
            $fieldAttributes .= $attribute . '="' . $attributeValue . '"';
        }
        return $fieldAttributes;
    }
}
