<?php

namespace App\CardFields;

use App\CardFields\Properties\CardExpiryMonthFieldProperties;
use App\CardFields\Properties\CardExpiryYearFieldProperties;
use App\CardFields\Properties\CardNumberFieldProperties;
use App\CardFields\Properties\CardVerificationNumberFieldProperties;

/**
 * Class CardFormGenerator
 * @package App\CardFields
 */
final class CardFormGenerator extends CardFieldGenerator
{

    /**
     * @var string
     */
    protected $id;
    /**
     * @var array
     */
    protected $fields;

    /**
     * CardFormGenerator constructor.
     * @param string $id
     */
    public function __construct($id)
    {
        $this->id = $id;
        $this->fields = $this->getFields();
    }

    /**
     * @return array
     */
    protected function getFields()
    {
        return wp_parse_args($this->fields,
            apply_filters('woocommerce_credit_card_form_fields', $this->generateFormFields(), $this->id));
    }

    /**
     * @return array
     */
    protected function generateFormFields()
    {
        return [
            'card-number-field' => $this->addCardField([
                new CardNumberFieldProperties()
            ], [
                'form-row-first',
                'card-number-field-xl'
            ]),
            'card-expiry-field' => $this->addCardField([
                new CardExpiryMonthFieldProperties(),
                new CardExpiryYearFieldProperties()
            ], [
                'form-row-first',
                'card-expiry-field-xl'
            ]),
            'card-cvv-field'    => $this->addCardField([
                new CardVerificationNumberFieldProperties()
            ], [
                'form-row-first',
                'card-cvv-field-xl'
            ]),
        ];
    }

    /**
     * @param string $fieldId
     * @return string
     */
    public function run($fieldId)
    {
        return '
            <fieldset id="wc-' . $fieldId . '-cc-form"
                class="elavon-converge-form-container wc-credit-card-form wc-payment-form">
                ' . do_action('woocommerce_credit_card_form_start', $this->id) . '
                ' . implode(array_map('trim', $this->fields)) . '
                ' . do_action('woocommerce_credit_card_form_end', $this->id) . '
                <div class="clear"></div>
            </fieldset>
        ';
    }

    /**
     * @param array $styles
     * @return void
     */
    public function addStyle($styles)
    {
        foreach ($styles as $handle => $src) {
            wp_enqueue_style($handle, $src, [], rand(111, 9999), 'all');
        }
    }

    /**
     * @param array $scripts
     * @return void
     */
    public function addScripts($scripts)
    {
        foreach ($scripts as $handle => $src) {
            wp_enqueue_script($handle, $src, [], rand(111, 9999), true);
        }
    }
}
