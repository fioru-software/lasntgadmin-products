<?php

namespace App\CardFields;

use App\CardFields\Validation\CardExpiryDateValidation;
use App\CardFields\Validation\CardNumberValidation;
use App\CardFields\Validation\CardVerificationNumberValidation;
use Exception;

/**
 * Class PaymentFieldsValidation
 * @package App\CardFields
 */
final class PaymentFieldsValidation
{

    /**
     * @var array
     */
    protected $params = [];
    /**
     * @var CardNumberValidation
     */
    protected $cardNumberValidation;
    /**
     * @var CardExpiryDateValidation
     */
    protected $cardExpiryDateValidation;
    /**
     * @var CardVerificationNumberValidation
     */
    protected $cardVerificationNumberValidation;

    /**
     * PaymentFieldsValidation constructor.
     * @param array $request
     * @throws Exception
     */
    public function __construct($request)
    {
        $this->params = $this->getParams($request);
        $this->cardNumberValidation = new CardNumberValidation(
            $this->params['card-number']
        );
        $this->cardExpiryDateValidation = new CardExpiryDateValidation(
            $this->params['card-expiry-month'],
            $this->params['card-expiry-year']);
        $this->cardVerificationNumberValidation = new CardVerificationNumberValidation(
            $this->params['card-verification-number']
        );
    }

    /**
     * @param array $request
     * @return array
     */
    protected function getParams($request)
    {
        return array_map(function ($fieldValue) {
            return $this->getFieldValue($fieldValue);
        }, array_filter($request, function ($fieldName) {
            return in_array($fieldName, [
                'card-number',
                'card-expiry-month',
                'card-expiry-year',
                'card-verification-number'
            ]);
        }, ARRAY_FILTER_USE_KEY));
    }

    /**
     * @param string|null $fieldValue
     * @return string|null
     */
    protected function getFieldValue($fieldValue)
    {
        return $fieldValue === null ? null : $this->sanitizeFieldValue($fieldValue);
    }

    /**
     * @param string $fieldValue
     * @return string
     */
    protected function sanitizeFieldValue($fieldValue)
    {
        return preg_replace('/\D/i', '', $fieldValue);
    }

    /**
     * @return bool
     * @throws Exception
     */
    public function runValidation()
    {
        $cardNumberValidation = $this->cardNumberValidation->runValidation();
        $cardExpirationDate = $this->cardExpiryDateValidation->runValidation();
        $cardVerificationNumberValidation = $this->cardVerificationNumberValidation->runValidation();
        return $cardNumberValidation && $cardExpirationDate && $cardVerificationNumberValidation;
    }
}
