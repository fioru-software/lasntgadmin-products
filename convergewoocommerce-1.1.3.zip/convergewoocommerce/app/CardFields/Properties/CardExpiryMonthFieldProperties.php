<?php

namespace App\CardFields\Properties;

/**
 * Class CardExpiryMonthFieldProperties
 * @package App\CardFields\Properties
 */
final class CardExpiryMonthFieldProperties extends FieldProperties
{

    /**
     * @return string
     */
    public function id()
    {
        return 'elavon-converge-gateway-card-expiry-month';
    }

    /**
     * @return array
     */
    public function class()
    {
        return [
            'text-center',
            'expiry-date-container',
            'mr-10'
        ];
    }

    /**
     * @return string
     */
    public function name()
    {
        return 'card-expiry-month';
    }

    /**
     * @return string
     */
    public function placeholder()
    {
        return 'MM';
    }

    /**
     * @return string
     */
    public function maxlength()
    {
        return '2';
    }

    /**
     * @return string
     */
    public function jsSelector()
    {
        return 'card-expiry-month';
    }

    /**
     * @return bool
     */
    public function hasLabel()
    {
        return true;
    }

    /**
     * @return bool
     */
    public function isRequired()
    {
        return true;
    }

    /**
     * @return string
     */
    public function text()
    {
        return 'Expiration Date';
    }
}
