<?php
declare(strict_types=1);

namespace App\CardFields\Properties;

/**
 * Class CardExpiryYearFieldProperties
 * @package App\CardFields\Properties
 */
final class CardExpiryYearFieldProperties extends FieldProperties
{

    /**
     * @return string
     */
    public function id()
    {
        return 'elavon-converge-gateway-card-expiry-year';
    }

    /**
     * @return array
     */
    public function class()
    {
        return [
            'text-center',
            'expiry-date-container'
        ];
    }

    /**
     * @return string
     */
    public function name()
    {
        return 'card-expiry-year';
    }

    /**
     * @return string
     */
    public function placeholder()
    {
        return 'YY';
    }

    /**
     * @return string
     */
    public function maxlength()
    {
        return '2';
    }

    /**
     * @return string
     */
    public function jsSelector()
    {
        return 'card-expiry-year';
    }

    /**
     * @return bool
     */
    public function hasLabel()
    {
        return false;
    }

    /**
     * @return bool
     */
    public function isRequired()
    {
        return true;
    }

    /**
     * @return string
     */
    public function text()
    {
        return 'Expiration Date';
    }
}
