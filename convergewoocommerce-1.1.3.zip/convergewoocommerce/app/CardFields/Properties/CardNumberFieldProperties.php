<?php
declare(strict_types=1);

namespace App\CardFields\Properties;

/**
 * Class CardNumberFieldProperties
 * @package App\CardFields\Properties
 */
final class CardNumberFieldProperties extends FieldProperties
{

    /**
     * @return string
     */
    public function id()
    {
        return 'elavon-converge-gateway-card-number';
    }

    /**
     * @return array
     */
    public function class()
    {
        return [];
    }

    /**
     * @return string
     */
    public function name()
    {
        return 'card-number';
    }

    /**
     * @return string
     */
    public function placeholder()
    {
        return 'Card Number';
    }

    /**
     * @return string
     */
    public function maxlength()
    {
        return '19';
    }

    /**
     * @return string
     */
    public function jsSelector()
    {
        return 'card-number';
    }

    /**
     * @return bool
     */
    public function hasLabel()
    {
        return true;
    }

    /**
     * @return bool
     */
    public function isRequired()
    {
        return true;
    }

    /**
     * @return string
     */
    public function text()
    {
        return 'Credit Card Number';
    }
}
