<?php
declare(strict_types=1);

namespace App\CardFields\Properties;

/**
 * Class CardVerificationNumberFieldProperties
 * @package App\CardFields\Properties
 */
final class CardVerificationNumberFieldProperties extends FieldProperties
{

    /**
     * @return string
     */
    public function id()
    {
        return 'elavon-converge-gateway-card-verification-number';
    }

    /**
     * @return array
     */
    public function class()
    {
        return [];
    }

    /**
     * @return string
     */
    public function name()
    {
        return 'card-verification-number';
    }

    /**
     * @return string
     */
    public function placeholder()
    {
        return 'CVV';
    }

    /**
     * @return string
     */
    public function maxlength()
    {
        return '4';
    }

    /**
     * @return string
     */
    public function jsSelector()
    {
        return 'card-verification-number';
    }

    /**
     * @return bool
     */
    public function hasLabel()
    {
        return true;
    }

    /**
     * @return bool
     */
    public function isRequired()
    {
        return true;
    }

    /**
     * @return string
     */
    public function text()
    {
        return 'Card Verification Number';
    }
}
