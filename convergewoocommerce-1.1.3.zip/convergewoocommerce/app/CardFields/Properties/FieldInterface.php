<?php
declare(strict_types=1);

namespace App\CardFields\Properties;

/**
 * Interface FieldInterface
 * @package App\CardFields\Properties
 */
interface FieldInterface
{

    /**
     * @return string
     */
    public function id();

    /**
     * @return array
     */
    public function class();

    /**
     * @return string
     */
    public function name();

    /**
     * @return string
     */
    public function placeholder();

    /**
     * @return string
     */
    public function maxlength();

    /**
     * @return string
     */
    public function jsSelector();
}
