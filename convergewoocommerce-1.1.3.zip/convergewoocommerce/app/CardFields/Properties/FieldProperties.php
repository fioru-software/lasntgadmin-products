<?php

namespace App\CardFields\Properties;

/**
 * Class FieldProperties
 * @package App\CardFields\Properties
 */
abstract class FieldProperties implements FieldInterface, LabelInterface
{

    /**
     * @return array
     */
    final public function getFieldAttributes()
    {
        return [
            'id'               => $this->id(),
            'class'            => $this->generatedClasses(),
            'name'             => $this->name(),
            'placeholder'      => $this->placeholder(),
            'maxlength'        => $this->maxlength(),
            'data-js-selector' => $this->jsSelector(),
        ];
    }

    /**
     * @return string
     */
    final protected function generatedClasses()
    {
        $defaultClasses = [
            'input-text',
            'wc-credit-card-form-' . $this->id()
        ];
        return empty($this->class())
            ? implode(' ', $defaultClasses)
            : implode(' ', array_merge($defaultClasses, $this->class()));
    }

    /**
     * @return string
     */
    final public function getFor()
    {
        return $this->id();
    }
}