<?php
declare(strict_types=1);

namespace App\CardFields\Properties;

/**
 * Interface LabelInterface
 * @package App\CardFields\Properties
 */
interface LabelInterface
{

    /**
     * @return bool
     */
    public function hasLabel();

    /**
     * @return bool
     */
    public function isRequired();

    /**
     * @return string
     */
    public function text();
}