<?php
declare(strict_types=1);

namespace App\CardFields\Validation;

use DateTime;
use Exception;

/**
 * Class CardExpiryDateValidation
 * @package App\CardFields\Validation
 */
final class CardExpiryDateValidation
{

    /**
     * @var string|null
     */
    protected $cardExpiryMonth;
    /**
     * @var string|null
     */
    protected $cardExpiryYear;

    /**
     * CardExpiryDateValidation constructor.
     * @param string|null $cardExpiryMonth
     * @param string|null $cardExpiryYear
     */
    public function __construct($cardExpiryMonth, $cardExpiryYear)
    {
        $this->cardExpiryMonth = $cardExpiryMonth;
        $this->cardExpiryYear = $cardExpiryYear;
    }

    /**
     * @return bool
     * @throws Exception
     */
    public function runValidation()
    {
        if (!$this->isNotEmptyExpiryMonth()) {
            ValidationAssets::addNotice(
                'Card Expiration Month',
                'This is a required field.',
                'elavon-converge-gateway-card-expiry-month'
            );
            return false;
        }

        if (!$this->isNotEmptyExpiryYear()) {
            ValidationAssets::addNotice(
                'Card Expiration Year',
                'This is a required field.',
                'elavon-converge-gateway-card-expiry-year'
            );
            return false;
        }

        $cardExpirationDate = ValidationAssets::getExpiryDateTime($this->cardExpiryMonth, $this->cardExpiryYear);

        if (!$this->isValidExpiryMonth($cardExpirationDate)) {
            ValidationAssets::addNotice(
                'Card Expiration Month',
                'The expiration month is not valid.',
                'elavon-converge-gateway-card-expiry-month'
            );
            return false;
        }

        if (!$this->isValidExpiryYear($cardExpirationDate)) {
            ValidationAssets::addNotice(
                'Card Expiration Year',
                'This is a required field.',
                'elavon-converge-gateway-card-expiry-year'
            );
            return false;
        }

        if (!$this->isValidExpiryDate($cardExpirationDate)) {
            ValidationAssets::addNotice(
                'Card Expiration Date',
                'The expiration date is not valid.',
                'elavon-converge-gateway-card-expiry-year'
            );
            return false;
        }

        return true;
    }

    /**
     * @return bool
     */
    protected function isNotEmptyExpiryMonth()
    {
        return ValidationAssets::notEmpty($this->cardExpiryMonth);
    }

    /**
     * @return bool
     */
    protected function isNotEmptyExpiryYear()
    {
        return ValidationAssets::notEmpty($this->cardExpiryYear);
    }

    /**
     * @param DateTime|null $cardExpirationDate
     * @return bool
     */
    protected function isValidExpiryMonth($cardExpirationDate)
    {
        return $cardExpirationDate === null
            ? false
            : in_array(intval($cardExpirationDate->format('m')), range(1, 12));
    }

    /**
     * @param DateTime|null $cardExpirationDate
     * @return bool
     */
    protected function isValidExpiryYear($cardExpirationDate)
    {
        return $cardExpirationDate === null
            ? false
            : $cardExpirationDate->format('Y') <= $cardExpirationDate->format('Y');
    }

    /**
     * @param DateTime|null $cardExpirationDate
     * @return bool
     * @throws Exception
     */
    protected function isValidExpiryDate($cardExpirationDate)
    {
        if ($cardExpirationDate instanceof DateTime) {
            return new DateTime() <= $cardExpirationDate;
        }
        return false;
    }
}
