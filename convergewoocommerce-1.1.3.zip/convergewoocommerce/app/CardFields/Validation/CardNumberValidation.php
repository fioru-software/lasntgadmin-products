<?php
declare(strict_types=1);

namespace App\CardFields\Validation;

/**
 * Class CardNumberValidation
 * @package App\CardFields\Validation
 */
final class CardNumberValidation
{

    /**
     * @var string|null
     */
    protected $cardNumber;

    /**
     * CardNumberValidation constructor.
     * @param string|null $cardNumber
     */
    public function __construct($cardNumber)
    {
        $this->cardNumber = $cardNumber;
    }

    /**
     * @return bool
     */
    public function runValidation()
    {
        if (!$this->isNotEmptyCardNumberIsEmpty()) {
            ValidationAssets::addNotice(
                'Card Number',
                'This is a required field.',
                'elavon-converge-gateway-card-number'
            );
            return false;
        }

        if (!$this->isValidCardNumber()) {
            ValidationAssets::addNotice(
                'Card Number',
                'The card number is not valid.',
                'elavon-converge-gateway-card-number'
            );
            return false;
        }

        return true;
    }

    /**
     * @return bool
     */
    protected function isNotEmptyCardNumberIsEmpty()
    {
        return ValidationAssets::notEmpty($this->cardNumber);
    }

    /**
     * @return bool
     */
    protected function isValidCardNumber()
    {
        return strlen($this->cardNumber) === 16;
    }
}