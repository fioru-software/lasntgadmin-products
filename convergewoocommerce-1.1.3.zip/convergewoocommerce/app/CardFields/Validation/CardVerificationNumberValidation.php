<?php
declare(strict_types=1);

namespace App\CardFields\Validation;

/**
 * Class CardVerificationNumberValidation
 * @package App\CardFields\Validation
 */
final class CardVerificationNumberValidation
{

    /**
     * @var string|null
     */
    protected $cardVerificationNumber;

    /**
     * CardVerificationNumberValidation constructor.
     * @param string|null $cardVerificationNumber
     */
    public function __construct($cardVerificationNumber)
    {
        $this->cardVerificationNumber = $cardVerificationNumber;
    }

    /**
     * @return bool
     */
    public function runValidation()
    {
        if (!$this->isNotEmptyCardVerificationNumber()) {
            ValidationAssets::addNotice(
                'Card Verification Number',
                'This is a required field.',
                'elavon-converge-gateway-card-number'
            );
            return false;
        }

        if (!$this->isValidCardVerificationNumber()) {
            ValidationAssets::addNotice(
                'Card Verification Number',
                'Must be at least 3 characters long.',
                'elavon-converge-gateway-card-number'
            );
            return false;
        }

        return true;
    }

    /**
     * @return bool
     */
    protected function isNotEmptyCardVerificationNumber()
    {
        return ValidationAssets::notEmpty($this->cardVerificationNumber);
    }

    /**
     * @return bool
     */
    protected function isValidCardVerificationNumber()
    {
        $cardVerificationNumberLength = strlen($this->cardVerificationNumber);
        return 3 <= $cardVerificationNumberLength && $cardVerificationNumberLength <= 4;
    }
}
