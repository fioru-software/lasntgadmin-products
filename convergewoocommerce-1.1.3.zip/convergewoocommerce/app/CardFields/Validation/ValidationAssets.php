<?php

namespace App\CardFields\Validation;

use DateTime;
use Exception;

/**
 * Class ValidationAssets
 * @package App\CardFields\Validation
 */
class ValidationAssets
{

    /**
     * @param string $fieldName
     * @param string $noticeMessage
     * @param string $fieldId
     */
    static public function addNotice($fieldName, $noticeMessage, $fieldId)
    {
        wc_add_notice("<strong>$fieldName</strong> $noticeMessage", 'error', ['id' => $fieldId]);
    }

    /**
     * @param int $start
     * @param int $end
     * @param string|null $fieldValue
     * @return bool
     */
    static public function length($start, $end, $fieldValue)
    {
        if (self::notEmpty($fieldValue)) {
            $fieldValueLength = strlen($fieldValue);
            return $start <= $fieldValueLength && $fieldValueLength <= $end;
        }
        return false;
    }

    /**
     * @param string|null $fieldValue
     * @return bool
     */
    static public function notEmpty($fieldValue)
    {
        return !empty($fieldValue);
    }

    /**
     * @param string $cardExpiryMonth
     * @param string $cardExpiryYear
     * @return DateTime
     * @throws Exception
     */
    static public function getExpiryDateTime($cardExpiryMonth, $cardExpiryYear)
    {
        $expiryDateTime = new DateTime('20' . $cardExpiryYear . '-' . $cardExpiryMonth . '-01 23:59:59');
        return $expiryDateTime->modify('last day of this month');
    }
}