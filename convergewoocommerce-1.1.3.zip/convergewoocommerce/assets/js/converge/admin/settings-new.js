/**
 * @typedef {{trans_no_option: string}} wp_object
 */
(function($) {
    var form;
    var body;
    var terminalConfigured;
    var detectedFormChanges = false;
    var beforeErrorElement;
    var validFields = null;
    var displayTerminalSetupSuccessMsg = false;

    $(document).ready(function() {
        form = $('#mainform');
        body = $('body');
        terminalConfigured = $('#woocommerce_elavon-converge-gateway_merchant_id').val() !== "" && $('#woocommerce_elavon-converge-gateway_user_id').val() !== "" && $('#woocommerce_elavon-converge-gateway_user_pin').val() !== "";
        beforeErrorElement = $('.woo-nav-tab-wrapper');

        console.log("terminalConfigured:"+terminalConfigured);

        form.submit(function( event ) {

            if (!terminalConfigured) {
                event.preventDefault();
                event.stopPropagation();

                $('html, body').animate({scrollTop: beforeErrorElement.offset().top}, 1000);

                var errorMessage = getErrorMessageHtml('Please click the terminal setup button.');

                $('.woo-nav-tab-wrapper').after(errorMessage);
            }
            return;
        });


        $('.terminal-setup-notifier').change(function () {
            displayTerminalSetupSuccessMsg = false;
            detectedFormChanges = true;
            terminalConfigured = false;
        });

        $('#woocommerce_elavon-converge-gateway_terminal_setup').on('click', function () {
            displayTerminalSetupSuccessMsg = true;
            var terminalResponse = getTerminalInfo();
            if(terminalResponse) {
                terminalResponse.done(handleResponse);
            }
        });

        if(terminalConfigured) {

            var terminalResponse = getTerminalInfo();
            if(terminalResponse) {
                terminalResponse.done(handleResponse);
            }
        }

        form.bind('submit', function () {
            $(this).find(':input').prop('disabled', false);
            $(this).find(".cvg-multiselect").find('option:not([value=""])').prop("selected", true);
        });

        $(document).on("change", "#woocommerce_elavon-converge-gateway_payment_action", populatePaymentTypes);
    });

    function populatePaymentTypes() {
        var value = $("#woocommerce_elavon-converge-gateway_payment_action").val();
        var prefix = "#woocommerce_elavon-converge-gateway_";
        var paymentTypes = validFields['paymentTypes'];

        if(value === "auth_only") {
            paymentTypes = validFields['paymentTypes'].filter(function(paymentType) {
                return paymentType.value !== 'payment_type_ach' && paymentType.value !== 'payment_type_gift_card'
            });
        }

        populateListBox(paymentTypes, prefix + "payment_types_accepted");
    }

    function getTerminalInfo() {
        var $merchantId = $('#woocommerce_elavon-converge-gateway_merchant_id');
        if($merchantId.length === 0) {
            return null;
        }

        var ajaxConstructor = {
            method: 'POST',
            dataType: 'JSON',
            url: route('admin/class-wc-converge-gateway-settings@terminalSetup'),
            data: {
                merchant_id: $merchantId.val(),
                user_id: $('#woocommerce_elavon-converge-gateway_user_id').val(),
                user_pin: $('#woocommerce_elavon-converge-gateway_user_pin').val(),
                environment: $('#woocommerce_elavon-converge-gateway_environment :selected').val(),
                use_proxy: $('#woocommerce_elavon-converge-gateway_use_proxy :selected').val(),
                proxy_host: $('#woocommerce_elavon-converge-gateway_proxy_host').val(),
                proxy_port: $('#woocommerce_elavon-converge-gateway_proxy_port').val()
            }
        };

        return $.ajax(ajaxConstructor);
    }

    function handleResponse(response) {
        var html;
        var $html = $('html, body');
        if (response.success === true ) {
            removeMessages();
            terminalConfigured = true;
            detectedFormChanges = false;
            validFields = response.data;

            if ( wp_object.config_saved == 1 && !displayTerminalSetupSuccessMsg)
            {
                $html.animate({scrollTop: beforeErrorElement.offset().top}, 1000);
                html = getSuccessMessageHtml(wp_object.trans_config_saved_msg);
                beforeErrorElement.after(html);
            }

            if (displayTerminalSetupSuccessMsg)
            {
                displayTerminalSetupSuccessMsg = false;
                $html.animate({scrollTop: beforeErrorElement.offset().top}, 1000);
                html = getSuccessMessageHtml(response.message);
                beforeErrorElement.after(html);
            }

            return populateFormFromTerminalSetupResponse(response.data);
        }

        $html.animate({scrollTop: beforeErrorElement.offset().top}, 1000);
        html = getErrorMessageHtml(response.message);
        beforeErrorElement.after(html);
    }

    /**
     *
     * @param {{terminalName: string,
     *          merchantName: string,
     *          region: string,
     *          paymentTypes: [],
     *          creditCardTypesAccepted: [],
     *          walletTypesAccepted: [],
     *          valueAddedServiceAccepted: [],
     *          currencyConversionAccepted: [],
     *          languagesAccepted: []}} data
     */
    function populateFormFromTerminalSetupResponse(data) {
        // console.log(data);
        var prefix = "#woocommerce_elavon-converge-gateway_";
        $(prefix + "terminal_name").val(data.terminalName);
        $(prefix + "merchant_name").val(data.merchantName);
        $(prefix + "region").val(data.region);
        $(prefix + "currency").val(data.currency);

        populatePaymentTypes();
        populateListBox(data.creditCardTypesAccepted, prefix + "credit_cards_accepted");
        populateListBox(data.walletTypesAccepted, prefix + "wallets_enabled");
        populateListBox(data.valueAddedServiceAccepted, prefix + "value_added_service");
        populateListBox(data.currencyConversionAccepted, prefix + "currency_conversion");
        populateListBox(data.languagesAccepted, prefix + "language_translations");
    }

    function populateListBox(list, listBoxId) {
        var $listBox = $(listBoxId);
        $listBox.find("option").remove();

        if(list.length === 0) {
            var $option = $('<option value="">' + wp_object.trans_no_option + '</option>');
            $listBox.append($option);
        }

        list.forEach(function(element) {
            var $option = $('<option value="' + element.value + '">' + element.label + '</option>');
            $listBox.append($option);
        });
    }

    function route(alias) {
        return window.location.href + '&converge_route=' + alias;
    }

    function getErrorMessageHtml(message) {
        removeMessages();
        return '<div id="converge_messages" class="error notice is-dismissible">' +
            '<p>' + message + '</p>' +
            '<button type="button" class="notice-dismiss">' +
            '</button>' +
            '</div>';
    }

    function getSuccessMessageHtml(message) {
        removeMessages();
        return '<div id="converge_messages" class="success notice is-dismissible">' +
            '<p>' + message + '</p>' +
            '<button type="button" class="notice-dismiss">' +
            '</button>' +
            '</div>';
    }

    function removeMessages() {
        $('#converge_messages').fadeOut().remove();
    }


})(jQuery);
