(function ($) {
    function ACHService() {
        this.baseConstructor.call(this);
        this.type = "converge-payment-option-ach";
    }

    ACHService.prototype = Object.create(CheckoutService.prototype);
    ACHService.prototype.baseConstructor = CheckoutService.prototype.constructor;
    ACHService.prototype.constructor = ACHService;

    ACHService.prototype.validateCheckoutForm = function (message) {
        // noinspection JSUnresolvedFunction
        var transitNumber = $("#elavon-converge-gateway-ach-transit-number").val();
        // noinspection JSUnresolvedFunction
        var bankAccountNumber = $("#elavon-converge-gateway-ach-bank-account-number").val();
        // noinspection JSUnresolvedFunction
        var bankAccountType = $("#elavon-converge-gateway-ach-bank-account-type").val();
        // noinspection JSUnresolvedFunction
        var firstName = $("#elavon-converge-gateway-ach-first-name").val();
        // noinspection JSUnresolvedFunction
        var lastName = $("#elavon-converge-gateway-ach-last-name").val();
        // noinspection JSUnresolvedFunction
        var company = $("#elavon-converge-gateway-ach-company").val();
        var ok = true;

        if (transitNumber === "") {
            ok = false;
            message = this.addToErrorMessage(message, "<strong>Bank Routing/Transit Number</strong> is a required field.");
        } else if (transitNumber.length > 0 && transitNumber.length < 9) {
            ok = false;
            message = this.addToErrorMessage(message, "The <strong>Bank Routing/Transit Number</strong> is not valid.");
        }

        if (bankAccountNumber === "") {
            ok = false;
            message = this.addToErrorMessage(message, "<strong>Bank Account Number</strong> is a required field.");
        }

        if (bankAccountType === "0") {
            if (firstName === "") {
                ok = false;
                message = this.addToErrorMessage(message, "<strong>First Name</strong> is a required field.");
            }
            if (lastName === "") {
                ok = false;
                message = this.addToErrorMessage(message, "<strong>Last Name</strong> is a required field.");
            }
        } else {
            if (company === "") {
                ok = false;
                message = this.addToErrorMessage(message, "<strong>Company</strong> is a required field.");
            }
        }

        if (!$("#elavon-converge-gateway-ach-agree").is(":checked")) {
            ok = false;
            message = this.addToErrorMessage(message, "Please click the <strong>'I agree'</strong> checkbox to proceed with your order.");
        }

        return {ok: ok, message: message};
    };

    /**
     * Get Payment Fields
     *
     * Creates payment fields depending on payment type chosen
     *
     * @param {string} token
     * @returns {{ssl_agree: string, ssl_txn_auth_token: *, ssl_aba_number: *, ssl_bank_account_number: *, ssl_bank_account_type: *}}
     */
    ACHService.prototype.getPaymentFields = function (token) {
        // noinspection JSUnresolvedFunction
        var paymentFields = {
            ssl_txn_auth_token: token,
            ssl_aba_number: $("#elavon-converge-gateway-ach-transit-number").val(),
            ssl_bank_account_number: $("#elavon-converge-gateway-ach-bank-account-number").val(),
            ssl_bank_account_type: $("#elavon-converge-gateway-ach-bank-account-type").val(),
            ssl_agree: $("#elavon-converge-gateway-ach-agree").is(":checked") ? "1" : "0"
        };

        // noinspection JSUnresolvedFunction
        var check_number = $("#elavon-converge-gateway-ach-check-number").val();
        if (check_number !== "") {
            paymentFields.ssl_check_number = check_number;
        }

        if (paymentFields.ssl_bank_account_type === "0") {
            // noinspection JSUnresolvedFunction
            paymentFields.ssl_first_name = $("#elavon-converge-gateway-ach-first-name").val();
            // noinspection JSUnresolvedFunction
            paymentFields.ssl_last_name = $("#elavon-converge-gateway-ach-last-name").val();
            paymentFields.ssl_ecs_product_code = "WEB";
        } else {
            // noinspection JSUnresolvedFunction
            paymentFields.ssl_company = $("#elavon-converge-gateway-ach-company").val();
            paymentFields.ssl_ecs_product_code = "WEB";
        }

        return paymentFields;
    };

    window.ACHService = ACHService;
})(jQuery);