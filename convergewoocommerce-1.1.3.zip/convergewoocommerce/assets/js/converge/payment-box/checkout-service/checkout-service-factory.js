(function ($) {
    function CheckoutServiceFactory(type) {
        var giftCardService;
        var creditCardService;
        var achCardService;
        var walletsService;
        this.getService = function (type) {
            switch (type) {
                case "wallets":
                    if (!walletsService) {
                        walletsService = new WalletsService();
                    }
                    return walletsService;
                case "converge-payment-option-credit-card":
                    if (!creditCardService) {
                        creditCardService = new CreditCardService();
                    }
                    return creditCardService;
                case "converge-payment-option-ach":
                    if (!achCardService) {
                        achCardService = new ACHService();
                    }
                    return achCardService;
                case "converge-payment-option-gift-card":
                    if (!giftCardService) {
                        giftCardService = new GiftCardService();
                    }
                    return giftCardService;
                default:
                    Utilities.prototype.getForm().prepend('<div class="woocommerce-error">Please select <strong>Payment Option</strong>.</div>');
                    // noinspection JSUnresolvedFunction
                    $.scroll_to_notices($(".woocommerce-error"));
                    return {};
            }
        }
    }

    window.CheckoutServiceFactory = CheckoutServiceFactory;
})(jQuery);