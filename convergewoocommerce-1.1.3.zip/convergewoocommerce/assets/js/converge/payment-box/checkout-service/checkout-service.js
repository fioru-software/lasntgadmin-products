'use script';
// noinspection JSUnresolvedVariable
(function ($) {
    function CheckoutService() {
        this.ifGiftNeedRefund = 0;
        this.giftCardPartialResponse = null;
    }

    /**
     * Block
     *
     * Creates loader and place it on form
     */
    function block() {
        $(".woocommerce-NoticeGroup-checkout, .woocommerce-error, .woocommerce-message").remove();

        var $form = Utilities.prototype.getForm();
        // noinspection JSValidateTypes
        1 !== $form.data()["blockUI.isBlocked"] && $form.block({
            message: null,
            overlayCSS: {
                background: "#fff",
                opacity: .6
            }
        });
    }

    /**
     * Unblock
     *
     * Removes loader from form and if any error or message is supposed to appear,
     * this function renders it
     *
     * @param {string} type
     * @param {string} message
     */
    function unblock(type, message) {
        var $form = Utilities.prototype.getForm();

        if (type) {
            $form.prepend('<div class="woocommerce-' + type + '">' + message + '</div>');
            // noinspection JSUnresolvedFunction
            $.scroll_to_notices($(".woocommerce-" + type));
        }

        // noinspection JSUnresolvedFunction
        $form.removeClass("processing").unblock();
    }

    /**
     * Checkout Js Place Order
     *
     * Call getNonce, use the fetched token to place order with checkoutJs.
     * After the response from converge has been retrieved,
     * add the result fields from the response to the checkout form as hidden inputs
     * and submit the form.
     * After which the converge response can be retrieved in gateway with $_POST variable
     * partialAmount param indicates if payment is partial, i.e get nonce will be modified for that amount
     */
    CheckoutService.prototype.placeOrder = function (partialAmount) {

        if (this.type === 'converge-payment-option-gift-card' && this.isPartialPayment) {
            if (!this.nextPaymentMethod.validateForm()) {
                return;
            }
        }

        if (!this.validateForm()) {
            return;
        }

        block();

        // noinspection JSUnresolvedFunction
        this.getNonce(partialAmount, 'get nonce for place order').then(this.pay.bind(this));
    };


    CheckoutService.prototype.getNonce = function (partialAmount, context = 'unknown') {
        partialAmount = partialAmount || 0;

        return $.post("?wc-ajax=get_nonce", {
            "billing_first_name": $("#billing_first_name").val(),
            "billing_last_name": $("#billing_last_name").val(),
            "billing_company": $("#billing_company").val(),
            "billing_phone": $("#billing_phone").val(),
            "billing_email": $("#billing_email").val(),
            "shipping_first_name": $("#shipping_first_name").val(),
            "shipping_last_name": $("#shipping_last_name").val(),
            "shipping_company": $("#shipping_company").val(),
            "shipping_phone": $("#shipping_phone").val(),
            "ship_to_different_address": $("#ship-to-different-address-checkbox").is(':checked'),
            "payment_type": this.type,
            "partial_amount": partialAmount,
            "elavon-converge-gateway-gift-card-number": $("#elavon-converge-gateway-gift-card-number").val(),
            "order_key": this.getQueryParams(document.location.search).key,
            "is_lightbox": this.integration == "converge-lightbox",
            "save_for_later_use": $('#wc-elavon-converge-gateway-new-payment-method').is(':checked'),
            "context": context
        });
    };

    CheckoutService.prototype.getEFSEci = function (eci) {
        if (eci === '02' || eci === '05'){
            return '5';
        } else if (eci === '01' || eci === '06'){
            return '6';
        } else {
            return '7';
        }
    };

    CheckoutService.prototype.getQueryParams = function (qs) {
        qs = qs.split('+').join(' ');

        var params = {},
            tokens,
            re = /[?&]?([^=]+)=([^&]*)/g;

        while (tokens = re.exec(qs)) {
            params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
        }

        return params;
    };

    CheckoutService.prototype.addQueryParam = function (url, param, value) {
        var a = document.createElement('a'), regex = /(?:\?|&amp;|&)+([^=]+)(?:=([^&]*))*/g;
        var match, str = []; a.href = url; param = encodeURIComponent(param);
        while (match = regex.exec(a.search))
            if (param != match[1]) str.push(match[1]+(match[2]?"="+match[2]:""));
        str.push(param+(value?"="+ encodeURIComponent(value):""));
        a.search = str.join("&");
        return a.href;
    };

    CheckoutService.prototype.handle3DSWebSdk = function () {
        var instance = this;
        var sdkE3D = new window.Elavon3DSWebSDK({ baseUrl : instance.converge.server_3ds2_url, token : instance.converge.ssl_3ds2_token, el : 'holder' });
        var expMM = instance.converge.ssl_exp_date.substring(0,2);
        var expYY = instance.converge.ssl_exp_date.substring(2,4);
        var purchaseAmount = parseFloat(parseFloat(instance.converge.ssl_amount).toFixed(2) * 100).toFixed(0);

        var request = {
            'purchaseAmount' : purchaseAmount,
            'purchaseCurrency' : "840",
            'purchaseExponent' : "2",
            'acctNumber' : instance.converge.ssl_card_number,
            'cardExpiryDate' : expYY.concat(expMM),
            'messageCategory' : "01",
            'transType' : "01",
            'threeDSRequestorAuthenticationInd' : "01",
            'challengeWindowSize': "03",
            'displayMode': "lightbox"
        };

        sdkE3D.web3dsFlow(request).then( function success(response) {

            instance.converge.ssl_dir_server_tran_id = response.dsTransID;
            instance.converge.ssl_eci_ind = instance.getEFSEci(response.eci);
            instance.converge.ssl_eci_message = response.message;
            if (response.authenticationValue) {
                instance.converge.ssl_3dsecure_value = response.authenticationValue;
            }

            var paymentData = {
                ssl_txn_auth_token: instance.converge.ssl_txn_auth_token,
                ssl_card_number: instance.converge.ssl_card_number,
                ssl_exp_date: instance.converge.ssl_exp_date,
                ssl_cvv2cvc2: instance.converge.ssl_cvv2cvc2,
                ssl_program_protocol: instance.converge.ssl_program_protocol,
                ssl_dir_server_tran_id: instance.converge.ssl_dir_server_tran_id,
                ssl_eci_ind: instance.converge.ssl_eci_ind,
                ssl_3dsecure_value: instance.converge.ssl_3dsecure_value
            };

            ConvergeEmbeddedPayment.pay(paymentData, instance.ccCallback());

        }, function error(response) {

            instance.sendOrderToWoo(response, "error", 'handle 3DS2 WebSdk error');
            instance.converge.ssl_eci_ind = "7";
            return false;
        });
    };



    CheckoutService.prototype.ccCallback = function () {

        var instance = this;
        var callback = {
            onError: function (error) {
                instance.sendOrderToWoo(error, "error", "cc callback -> error");
                return false;
            },
            onDeclined: function (response) {
                instance.sendOrderToWoo(response, "declined", "cc callback -> decline");
                return false;
            },
            onApproval: function (response) {
                if (instance.type === 'converge-payment-option-gift-card' && instance.isPartialPayment) {
                    instance.nextPaymentMethod.ifGiftNeedRefund = instance.amountOnGiftCard;
                    instance.nextPaymentMethod.placeOrder(instance.amountToPayWithCC);
                    instance.nextPaymentMethod.giftCardPartialResponse = response;
                } else {
                    //no need for gift refund
                    instance.ifGiftNeedRefund = false;
                    instance.sendOrderToWoo(response, "approved", "cc callback -> approved");
                }
            },
            onThreeDSecure: function (response) {
                instance.ifGiftNeedRefund = false;
                instance.sendOrderToWoo(response, "approved", "cc callback -> 3ds1 approved");
                return false;
            },
            onThreeDSecure2: function (response) {
                if (response.ssl_3ds2_token){
                    instance.converge.ssl_3ds2_token = response.ssl_3ds2_token;
                    instance.handle3DSWebSdk();
                    return false;
                } else {
                    instance.sendOrderToWoo(response, "error", "cc callback -> 3ds2 error");
                    return false;
                }
            },

            onCancelled: function () {
                console.log("CANCELED");
                unblock("message", "Error processing checkout. Please try again.");
            }
        };

        return callback;
    };


    /**
     * Pay
     * Performs payment using converge gateway
     *
     * @param data
     */
    CheckoutService.prototype.pay = function (data) {

        var instance = this;

        /**
         *
         * @type {{token: string}} data
         */

        if (data.token === "") {
            unblock("error", "Error processing checkout. Please try again.");
            return;
        }

        var paymentFields = this.getPaymentFields(data.token);

        instance.converge = {
            "has_3d_secure_v2" : checkout_properties.has3DS2Enabled,
            "server_3ds2_url" : checkout_properties.server3DS2Url,
            "ssl_txn_auth_token" : data.token,
            "ssl_amount" : data.amount,
            "ssl_card_number" : paymentFields.ssl_card_number,
            "ssl_exp_date" : paymentFields.ssl_exp_date,
            "ssl_cvv2cvc2" : paymentFields.ssl_cvv2cvc2,
            "ssl_3ds2_token" : "",
            "ssl_dir_server_tran_id" : "",
            "ssl_eci_ind" : "",
            "ssl_eci_message" : "",
            "ssl_3dsecure_value" : "",
            "ssl_program_protocol" : 2
        };


        if (this.integration === "converge-lightbox") {

            PayWithConverge.open(paymentFields, instance.ccCallback());

        } else {
            
            if( instance.converge.has_3d_secure_v2
                && !instance.isPartialPayment
                && instance.type != "converge-payment-option-gift-card"
                && instance.type != "converge-payment-option-ach"
            ){
                var paymentData = { ssl_txn_auth_token: instance.converge.ssl_txn_auth_token };
                ConvergeEmbeddedPayment.getEFSToken(paymentData, instance.ccCallback());
            } else {

                if ($('#wc-elavon-converge-gateway-new-payment-method').is(':checked')) {
                    paymentFields.ssl_add_token = 'Y';
                }

                ConvergeEmbeddedPayment.pay(paymentFields, instance.ccCallback());
            }
        }
    };

    /**
     * Sends the order to WooCommerce
     *
     * @param {array} data
     * @param {string} type
     */
    CheckoutService.prototype.sendOrderToWoo = function (data, type, context = '') {
        var checkout_form = Utilities.prototype.getForm();
        checkout_form.off('checkout_place_order_elavon-converge-gateway');

        var formElem = document.createElement('input');
        formElem.setAttribute('type', 'hidden');
        formElem.setAttribute('name', 'converge_response');
        formElem.setAttribute('value', JSON.stringify(data));
        checkout_form.append(formElem);

        var formElem = document.createElement('input');
        formElem.setAttribute('type', 'hidden');
        formElem.setAttribute('name', 'converge_response_type');
        formElem.setAttribute('value', type);
        checkout_form.append(formElem);

        var formElem = document.createElement('input');
        formElem.setAttribute('type', 'hidden');
        formElem.setAttribute('name', 'context');
        formElem.setAttribute('value', context);
        checkout_form.append(formElem);

        if (this.ifGiftNeedRefund) {
            var formElem = document.createElement('input');
            formElem.setAttribute('type', 'hidden');
            formElem.setAttribute('name', 'refund_gift');
            formElem.setAttribute('value', this.ifGiftNeedRefund);
            checkout_form.append(formElem);
        }

        if (this.giftCardPartialResponse) {
            var formElem = document.createElement('input');
            formElem.setAttribute('type', 'hidden');
            formElem.setAttribute('name', 'gift_card_response');
            formElem.setAttribute('value', JSON.stringify(this.giftCardPartialResponse));
            checkout_form.append(formElem);
        }

        checkout_form.submit();
    };

    /**
     * Validate Form
     *
     * This function beside the form validation validates address fields as well
     * because checkoutJs payment flow will first request payment token, perform the payment
     * and only then go to backend field validation
     *
     * @returns {boolean}
     */
    CheckoutService.prototype.validateForm = function () {
        // noinspection JSJQueryEfficiency
        $(".woocommerce-error").remove();
        var instance = this;

        var address_types = $("#ship-to-different-address-checkbox").is(":checked") ? ["billing_", "shipping_"] : ["billing_"];
        var address_fields = ["first_name", "last_name", "country", "state", "address_1", "address_2", "city", "postcode", "phone", "email", "company"];
        var address_fields_not_required = ["address_2", "company"];
        var address_types_names = {"billing_": "Billing", "shipping_": "Shipping"};
        var address_fields_names = {
            "first_name": "First Name",
            "last_name": "Last Name",
            "country": "Country",
            "state": " State/County",
            "address_1": " Street Address Line 1",
            "address_2": " Street Address Line 2",
            "city": "Town/City",
            "postcode": "Postcode/ZIP",
            "phone": "Phone",
            "email": "Email",
            "company": "Company"
        };
        var address_fields_limits = {
            "first_name": 20,
            "last_name": 30,
            "country": 30,
            "address_1": 30,
            "address_2": 30,
            "city": 30,
            "postcode": 9,
            "phone": 20,
            "company": 50,
            "state": 30,
            "email": 100,
        };
        var ok = true;
        var message = "";

        //validates Billing and Shipping address

        address_types.forEach(function (typeElement) {
            address_fields.forEach(function (fieldElement) {
                if (typeElement === "shipping_" && (fieldElement === "phone" || fieldElement === "email")) {
                    return;
                }

                var elementId = "#" + typeElement + fieldElement;
                if ($(elementId).length === 0) {
                    return;
                }

                if(fieldElement === 'state') {
                    var $stateField = $("#" + typeElement + fieldElement + "_field");
                    if($stateField.find(">label").find("abbr").length === 0) {
                        return;
                    }
                }

                // noinspection JSUnresolvedFunction
                if (!address_fields_not_required.includes(fieldElement) && $(elementId).val() === "") {
                    message = instance.addToErrorMessage(message, "<strong>" + address_types_names[typeElement] + " " + address_fields_names[fieldElement] + "</strong> is a required field.");
                    ok = false;
                } else {
                    if (address_fields_limits[fieldElement] !== undefined) {
                        if ($(elementId).val().length > address_fields_limits[fieldElement]) {
                            message = instance.addToErrorMessage(message, "<strong>%1 %2<strong> cannot be longer than %3 characters.".replace('%1', address_types_names[typeElement]).replace('%2', address_fields_names[fieldElement]).replace('%3', address_fields_limits[fieldElement]));
                            ok = false;
                        }
                    }
                }
            });
        });

        // validates checkout form

        var $checkedPaymentOption = $(".converge-payment-option:checked");
        var $checkedSavedCard = $(".woocommerce-SavedPaymentMethods-tokenInput");

        if ($checkedPaymentOption.length === 0 && $checkedSavedCard.length === 0) {
            message = this.addToErrorMessage(message, "Please select <strong>Payment Option</strong>.");
            ok = false;
        } else {
            var validationResult = this.validateCheckoutForm(message);
            ok = ok && validationResult.ok;
            message = validationResult.message;
        }

        if (!ok) {
            Utilities.prototype.getForm().prepend('<div class="woocommerce-error">' + message + '</div>');
            // noinspection JSUnresolvedFunction
            $.scroll_to_notices($(".woocommerce-error"));
        }

        return ok;
    };

    CheckoutService.prototype.validateExpirationDate = function (date) {

        var dateArray = date.split("/");

        if (dateArray.length === 1) {
            return false;
        }

        var ed_mm = dateArray[0].trim();
        var ed_yy = dateArray[1].trim();


        // noinspection JSUnresolvedFunction
        if (!$.isNumeric(ed_mm) || !$.isNumeric(ed_yy)) {
            return false;
        }

        if (parseInt(ed_mm) < 1 || parseInt(ed_mm) > 12) {
            return false;
        }

        return true;
    };

    CheckoutService.prototype.addToErrorMessage = function (currentMessage, errorMessage) {
        if (currentMessage.length > 0) {
            currentMessage += "<br>";
        }

        currentMessage += errorMessage;
        return currentMessage;
    };

    CheckoutService.prototype.getPaymentFields = function (token) {
        return {"ssl_token": token};
    };

    CheckoutService.prototype.validateCheckoutForm = function (message) {
        return {ok: true, message: message};
    };

    CheckoutService.prototype.encodeQueryData = function (obj) {
        var str = [];
        for (var p in obj)
            if (obj.hasOwnProperty(p)) {
                str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
            }
        return str.join("&");
    };

    window.CheckoutService = CheckoutService;


})(jQuery);
