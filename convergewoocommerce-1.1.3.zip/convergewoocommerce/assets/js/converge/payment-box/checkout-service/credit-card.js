(function ($) {
    function CreditCardService() {
        this.baseConstructor.call(this);
        this.type = "converge-payment-option-credit-card";
    }

    CreditCardService.prototype = Object.create(CheckoutService.prototype);
    CreditCardService.prototype.baseConstructor = CheckoutService.prototype.constructor;
    CreditCardService.prototype.constructor = CreditCardService;

    jQuery(document).on('change', "input[type=radio][id=payment-option-credit-card_converge-payment-option-credit-card]:checked", function (e) {
        var cardNumberField = document.getElementById("elavon-converge-gateway-card-number");
        if (cardNumberField) {
            Utilities.prototype.setInputFilter(cardNumberField, function (value) {
                return /^((\d*\ ?)*)$/.test(value);
            });
        }
    });

    CreditCardService.prototype.validateCheckoutForm = function (message) {
        var $creditCardNumber = $("#elavon-converge-gateway-card-number");
        var $expiryDate = $("#elavon-converge-gateway-card-expiry");
        var $cvc = $("#elavon-converge-gateway-card-cvc");
        var ok = true;

        // noinspection JSUnresolvedFunction
        if ($creditCardNumber.val() === "") {
            ok = false;
            message = this.addToErrorMessage(message, "<strong>Card Number</strong> is a required field.");
        }

        // noinspection JSUnresolvedFunction
        if ($expiryDate.val() === "") {
            ok = false;
            message = this.addToErrorMessage(message, "<strong>Expiration Date</strong> is a required field.");
        } else { // noinspection JSUnresolvedFunction
            if (!this.validateExpirationDate($expiryDate.val())) {
                ok = false;
                message = this.addToErrorMessage(message, "The <strong>Expiration Date</strong> is not valid.");
            }
        }

        // noinspection JSUnresolvedFunction
        if ($cvc.val() === "") {
            ok = false;
            message = this.addToErrorMessage(message, "<strong>Card Verification Number</strong> is a required field.");
        } else { // noinspection JSUnresolvedFunction
            if ($cvc.val().length < 3) {
                ok = false;
                message = this.addToErrorMessage(message, "<strong>Card Verification Number</strong> must be at least 3 characters long");
            }
        }

        return {ok: ok, message: message};
    };

    /**
     * Get Payment Fields
     *
     * Creates payment fields depending on payment type chosen
     *
     * @param {string} token
     * @returns {{ssl_txn_auth_token: *, ssl_exp_date: *, ssl_card_number: *, ssl_cvv2cvc2: *}}
     */
    CreditCardService.prototype.getPaymentFields = function (token) {
        // noinspection JSUnresolvedFunction,JSUnresolvedVariable
        return {
            ssl_txn_auth_token: token,
            ssl_card_number: $("#elavon-converge-gateway-card-number").val().split(" ").join(""),
            ssl_exp_date: $("#elavon-converge-gateway-card-expiry").val().split(" / ").join(""),
            ssl_cvv2cvc2: $("#elavon-converge-gateway-card-cvc").val(),
            ssl_add_token: 'N'
        };
    };

    window.CreditCardService = CreditCardService;
})(jQuery);