(function ($) {
    function GiftCardService() {
        this.type = "converge-payment-option-gift-card";
        this.amountOnGiftCard = 0;
        this.orderTotal = 0;
        this.amountToPayWithCC = 0;
        this.isPartialPayment = false;
        this.nextPaymentMethod;
        var instance = this;
        $(document).on("click", "#converge-apply-gift", function (e) {

            e.preventDefault();
            e.stopImmediatePropagation();
            if ($("#converge-apply-gift").html() === "CANCEL") {
                cancel();
                instance.isPartialPayment = false;
                return;
            }
            if (!instance.validateForm()) {
                return;
            }

            instance.getBalance();

        });
        this.baseConstructor.call(this);
    }

    GiftCardService.prototype = Object.create(CheckoutService.prototype);
    GiftCardService.prototype.baseConstructor = CheckoutService.prototype.constructor;
    GiftCardService.prototype.constructor = GiftCardService;


    GiftCardService.prototype.getBalance = function () {
        var instance = this;
        instance.isPartialPayment = false;
        var gift_card_code = $("#elavon-converge-gateway-gift-card-code").length ? $("#elavon-converge-gateway-gift-card-code").val() : '';

        $.post("?wc-ajax=giftcard_balance", {
            "elavon-converge-gateway-gift-card-number": $("#elavon-converge-gateway-gift-card-number").val(),
            "elavon-converge-gateway-gift-card-code": gift_card_code,
            "order_key": instance.getQueryParams(document.location.search).key
        }).then(function (response) {
            console.log(response);
            var message;
            if (response.success) {
                instance.amountOnGiftCard = parseFloat(response.data.balance);
                instance.orderTotal = parseFloat(response.data.order_total);
                var delta = instance.amountOnGiftCard - instance.orderTotal;
                var absDelta = Math.abs(delta).toFixed(2);
                if (delta >= 0) {
                    message = "$" + instance.orderTotal + " will be applied. Remaining order total $0.00";
                    payOnlyWithGiftCard();
                } else if (instance.amountOnGiftCard == 0) message = 'The balance on your gift card is 0.';
                else {
                    instance.isPartialPayment = true;
                    message = "$" + instance.amountOnGiftCard + " will be applied. Remaining order total $" + absDelta + ". Proceed to complete your order.";
                    instance.amountToPayWithCC = absDelta;
                    prepareForPartialPayment();
                }
            } else {
                message = response.data;
            }
            $("#converge-gift-card-info").html(message);
        });
    }

    function payOnlyWithGiftCard() {
        $("#converge-apply-gift").html("CANCEL");
        $('input[name=converge-payment-option]').attr("disabled", true);

    }

    function prepareForPartialPayment() {
        $("#converge-apply-gift").html("CANCEL");

        $("#payment-option-credit-card_converge-payment-option-credit-card").trigger('click');
        $('input[name=converge-payment-option]').attr("disabled", true);
        $("#fieldset-converge-gift").show().slideDown();
        $("#elavon-converge-gateway-gift-card-number").prop('readonly', true);

    }

    function cancel() {
        $("#converge-apply-gift").html("APPLY");
        $('input[name=converge-payment-option]').attr("disabled", false);
        $("#place_order").prop('disabled', false);
        $("#converge-gift-card-info").html('');
        $("#payment-option-gift-card_converge-payment-option-gift-card").trigger('click');
        $("#wc-elavon-converge-gateway-cc-form :input").not(':input[type=radio]').val('');
        $("#elavon-converge-gateway-gift-card-number").prop('readonly', false);

    }

    GiftCardService.prototype.validateCheckoutForm = function (message) {

        var $giftCardNumber = $("#elavon-converge-gateway-gift-card-number");

        var ok = true;

        // noinspection JSUnresolvedFunction
        if ($giftCardNumber.val() === "") {
            ok = false;
            message = this.addToErrorMessage(message, "<strong>Card Number</strong> is a required field.");
        } else { // noinspection JSUnresolvedFunction
            if ($giftCardNumber.hasClass("unknown")) {
                ok = false;
                message = this.addToErrorMessage(message, "The <strong>Card Number</strong> is not valid.");
            }
        }


        return {ok: ok, message: message};
    };

    /**
     * Get Payment Fields
     *
     * Creates payment fields depending on payment type chosen
     *
     * @param {string} token
     * @returns {{ssl_txn_auth_token: *, ssl_exp_date: *, ssl_card_number: *, ssl_cvv2cvc2: *}}
     */
    GiftCardService.prototype.getPaymentFields = function (token) {
        // noinspection JSUnresolvedFunction,JSUnresolvedVariable
        return {
            ssl_txn_auth_token: token,
            ssl_card_number: $("#elavon-converge-gateway-gift-card-number").val().split(" ").join(""),
            ssl_exp_date: "1249",
            ssl_security_code: $("#elavon-converge-gateway-gift-card-code").length ? $("#elavon-converge-gateway-gift-card-code").val() : ''
        };
    };

    window.GiftCardService = GiftCardService;
})(jQuery);