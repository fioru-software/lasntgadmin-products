(function ($) {
    function LightBoxService() {
        this.baseConstructor.call(this);
        this.integration = "converge-lightbox";
        this.type = $("input[name='converge-payment-option']:checked").val();
    }

    LightBoxService.prototype = Object.create(CheckoutService.prototype);
    LightBoxService.prototype.baseConstructor = CheckoutService.prototype.constructor;
    LightBoxService.prototype.constructor = LightBoxService;

    /**
     * Get Payment Fields
     *
     * Creates payment fields depending on payment type chosen
     *
     * @param {string} token
     * @returns {{ssl_txn_auth_token: *, ssl_exp_date: *, ssl_card_number: *, ssl_cvv2cvc2: *}}
     */
    LightBoxService.prototype.getPaymentFields = function (token) {
        // noinspection JSUnresolvedFunction,JSUnresolvedVariable
        return {
            ssl_txn_auth_token: token
        };
    };

    window.LightBoxService = LightBoxService;
})(jQuery);