(function ($) {
    function StoredService() {
        this.baseConstructor.call(this);
        this.type = 'stored';
    }

    StoredService.prototype = Object.create(CheckoutService.prototype);
    StoredService.prototype.baseConstructor = CheckoutService.prototype.constructor;
    StoredService.prototype.constructor = StoredService;

    window.StoredService = StoredService;
})(jQuery);