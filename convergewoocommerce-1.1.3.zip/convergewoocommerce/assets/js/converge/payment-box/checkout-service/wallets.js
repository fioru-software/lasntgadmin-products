(function ($) {
    function WalletsService() {
        this.baseConstructor.call(this);
    }

    WalletsService.prototype = Object.create(CheckoutService.prototype);
    WalletsService.prototype.baseConstructor = CheckoutService.prototype.constructor;
    WalletsService.prototype.constructor = WalletsService;


    WalletsService.prototype.initWallets = function (){
        var instance = this;
        var osessionId = this.getQueryParams(document.location.search).osessionId;
        var verifier = this.getQueryParams(document.location.search).oauth_verifier;

        if (osessionId && verifier) {
            var callback = {
                onError: function (error) {
                    var response = {
                        error: error,
                        paid_via_wallet: true
                    };
                    CheckoutService.prototype.sendOrderToWoo(response, "declined", 'pay by masterpass callback -> error');
                },
                onDeclined: function (response) {
                    response.paid_via_wallet = true;
                    CheckoutService.prototype.sendOrderToWoo(response, "declined", 'pay by masterpass -> declined');
                },
                onApproval: function (response) {
                    response.paid_via_wallet = true;
                    response.wallet_used = 'masterpass';
                    CheckoutService.prototype.sendOrderToWoo(response, "approved", 'pay by masterpass -> approved');
                },
                onCancelled: function () {
                    window.location.reload();
                }
            };
            var paymentData = {
                osessionId: osessionId,
                oauth_verifier: verifier
            };
            ConvergeEmbeddedPayment.payByMasterpass(paymentData, callback);
        }

        var callback = {
            onError: function (error) {
                CheckoutService.prototype.sendOrderToWoo(error, "declined", 'wallets callback -> error');
            },
            onDeclined: function (response) {
                CheckoutService.prototype.sendOrderToWoo(response, "declined", 'wallets callback -> declined');
            },
            onApproval: function (response) {
                response.paid_via_wallet = true;
                response.wallet_used = "paypal";
                CheckoutService.prototype.sendOrderToWoo(response, "approved", 'wallets callback -> approved');
            },
            onCancelled: function () {
                window.location.reload();
            }
        };

        this.getNonce(this.amountToPayWithCC, 'get nonce for wallets').done(function( data ) {

            if ((data.hasOwnProperty('is_success') && !data.is_success) || !data.hasOwnProperty('token') ) {
                alert("The Converge payment method is currently unavailable. Please contact the merchant.");
                return;
            }

            token = data.token;
            var paymentFields = {
                ssl_txn_auth_token: token,
                ssl_callback_url: instance.addQueryParam(window.location.href, 'osessionId', token)
            };

            var wallets = checkout_properties.wallets;

            if (wallets !== null && $('#wallet-iframes').length) {
                if (wallets.indexOf("wallet_pp") > -1) {
                    ConvergeEmbeddedPayment.initPayPalCheckout('paypal-checkout-button', paymentFields, callback);
                }
                if (wallets.indexOf("wallet_masterpass") > -1 && document.body.classList.contains('logged-in')) {
                    callback.onApproval = function (response){
                        response.paid_via_wallet = true;
                        response.wallet_used = "masterpass";
                        CheckoutService.prototype.sendOrderToWoo(response, "approved", 'wallets callback -> approved');
                    }
                    ConvergeEmbeddedPayment.initMasterPass('masterpass-checkout-button', paymentFields, callback);
                }
                if (wallets.indexOf("wallet_pp") > -1) {
                    ConvergeEmbeddedPayment.initPayPalCredit('paypalcredit-checkout-button', paymentFields, callback);
                }
                if (window.ApplePaySession && wallets.indexOf("wallet_apple") > -1) {
                    ConvergeEmbeddedPayment.initApplePay('applepay-checkout-button', paymentFields, callback);
                }
            }
        });

    };

    window.WalletsService = WalletsService;
})(jQuery);