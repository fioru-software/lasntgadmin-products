'use script';

// noinspection JSUnresolvedFunction
jQuery(function ($) {
    var utilities = new Utilities();
    var lastCheckedConvergeMethod;
    var checkoutFactory = new CheckoutServiceFactory();
    var checkoutJsService;
    var giftCardService;
    var creditCardService;
    var AchCardService;
    var currentCheckedService;

    // noinspection JSValidateTypes
    $(document).ready(function () {
        $("#elavon-converge-gateway-ach-bank-account-type").select2({
            minimumResultsForSearch: -1
        });

        var $checkout_form = $('form.woocommerce-checkout');
        if ($checkout_form.length) {
            $checkout_form.on("checkout_place_order_elavon-converge-gateway", place_order);

            $(document.body).on('checkout_error', function () {
                $checkout_form.on("checkout_place_order_elavon-converge-gateway", place_order);
            });

            $(document.body).on('updated_checkout', function () {
                init_form();
            });
        } else {
            var $checkout_form_button = $('#place_order');
            if ($checkout_form_button.length){
                $checkout_form_button.on('click', function (e) {
                    e.preventDefault();
                    place_order(e);
                });
                init_form();
            }
        }
    });

    function place_order(e) {
        var $payWithStoredCardValue = $("input[name='wc-elavon-converge-gateway-payment-token']:checked").val();
        if ($payWithStoredCardValue && $payWithStoredCardValue !== 'new') {
            if (!new StoredService().validateForm()) {
                return false;
            }
            var $review_form = $('form#order_review');
            if ($review_form.length) {
                $review_form.submit();
            }
            return true;
        } else {
            // HostedPayment Call
            if (!properties.is_checkoutJS_integration) {
                new LightBoxService().placeOrder();
                return false;
            }
            if (!checkoutJsService) {
                checkoutJsService = checkoutFactory.getService($("[name='converge-payment-option']:checked").val());
            }
            if (typeof checkoutJsService.placeOrder === "function") {
                var partialPayAmmount = 0;
                if (giftCardService && giftCardService.isPartialPayment) {
                    partialPayAmmount = giftCardService.amountToPayWithCC;
                    if (!giftCardService.placeOrder(giftCardService.amountOnGiftCard)) {
                        return false;
                    }
                    giftCardService.isPartialPayment = false;
                }

                checkoutJsService.placeOrder(partialPayAmmount);

            }

            return false;
        }
    }

    function init_form() {
        var $newPaymentMethod = $("#wc-elavon-converge-gateway-new-payment-method");

        if ($("#elavon-converge-gateway-ach-bank-account-type").val() === "0") {
            $("#elavon-converge-gateway-ach-company_field").hide();
            $("#elavon-converge-gateway-ach-first-name_field").show();
            $("#elavon-converge-gateway-ach-last-name_field").show();
        } else {
            $("#elavon-converge-gateway-ach-first-name_field").hide();
            $("#elavon-converge-gateway-ach-last-name_field").hide();
            $("#elavon-converge-gateway-ach-company_field").show();
        }
        if (properties.is_checkoutJS_integration) {
            var walletsService = checkoutFactory.getService('wallets');
            var osessionId = walletsService.getQueryParams(document.location.search).osessionId;
            var verifier = walletsService.getQueryParams(document.location.search).oauth_verifier;

            if (osessionId && verifier) {
                $('#payment_method_elavon-converge-gateway').trigger('click');
            }
            if (checkout_properties.wallets !== null && $('#wallet-iframes').length) {
                walletsService.initWallets();
            }
        }
        $(document).on("change", ".converge-payment-option", function () {
            var checkedOption = $(".converge-payment-option:checked").val();

            if (!checkedOption) return;
            if (lastCheckedConvergeMethod == checkedOption) return;

            lastCheckedConvergeMethod = $(".converge-payment-option:checked").val();
            show_selected_converge_payment($(".converge-payment-option:checked").val());
            checkoutJsService = checkoutFactory.getService($("[name='converge-payment-option']:checked").val());

            // check if is  gift card object and store it for partial payment case
            if ((checkoutJsService instanceof GiftCardService)) {
                giftCardService = checkoutJsService;
            }

            if ((checkoutJsService instanceof CreditCardService) && giftCardService && giftCardService.isPartialPayment) {
                giftCardService.nextPaymentMethod = checkoutJsService;
            }
            // console.log(giftCardService.amountOnGiftCard || 'nema');
            // disable save to account if we change payment option
            $newPaymentMethod.prop("checked", false);
        });

        function show_selected_converge_payment(element) {
            if (!element) return;
            $('div[id^="fieldset-converge-"]').slideUp();
            var id_postfix = element.split("-")[3];
            var id = 'fieldset-converge-' + id_postfix;
            $('#' + id).slideDown();

        }

        $(document).on("change", "#elavon-converge-gateway-ach-bank-account-type", function () {
            if ($(this).val() === "0") {
                $("#elavon-converge-gateway-ach-company_field").hide();
                $("#elavon-converge-gateway-ach-first-name_field").show();
                $("#elavon-converge-gateway-ach-last-name_field").show();
            } else {
                $("#elavon-converge-gateway-ach-first-name_field").hide();
                $("#elavon-converge-gateway-ach-last-name_field").hide();
                $("#elavon-converge-gateway-ach-company_field").show();
            }
        });

        utilities.restrictToNumeric("#elavon-converge-gateway-ach-transit-number");
        utilities.restrictToNumeric("#elavon-converge-gateway-ach-bank-account-number");
        utilities.restrictToNumeric("#elavon-converge-gateway-ach-check-number");

        utilities.restrictToNumeric("#elavon-converge-gateway-gift-card-number");
        utilities.restrictToNumeric("#elavon-converge-gateway-gift-card-code");

    }
});
