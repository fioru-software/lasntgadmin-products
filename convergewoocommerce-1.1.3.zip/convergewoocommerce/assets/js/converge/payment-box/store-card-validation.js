(function($) {

    function addToErrorMessage (currentMessage, errorMessage) {
        if(currentMessage.length > 0) {
            currentMessage += "<br>";
        }

        currentMessage += errorMessage;
        return currentMessage;
    };

    function validateExpirationDate (date) {

        var dateArray = date.split("/");
        if(dateArray.length === 1) {
            return false;
        }

        var ed_mm = dateArray[0].trim();
        var ed_yy = dateArray[1].trim();

        // noinspection JSUnresolvedFunction
        if(!$.isNumeric(ed_mm) || !$.isNumeric(ed_yy)) {
            return false;
        }

        if(parseInt(ed_mm) < 1 || parseInt(ed_mm) > 12) {
            return false;
        }

        var now = new Date();
        var currentYear = now.getFullYear() % 100;
        var currentMonth = now.getMonth() + 1;

        if(parseInt(ed_yy) < currentYear) {
            return false;
        }

        if(parseInt(ed_yy) === currentYear && parseInt(ed_mm) < currentMonth) {
            return false;
        }

        return true;
    };

    var cardNumberField = document.getElementById("elavon-converge-gateway-card-number");
    if (cardNumberField) {
        Utilities.prototype.setInputFilter(cardNumberField, function (value) {
            return /^((\d*\ ?)*)$/.test(value);
        });
    }

    $(document).on("click", "#place_order", function (event) {

        var message = '';
        var $creditCardNumber = $("#elavon-converge-gateway-card-number");
        var $expiryDate = $("#elavon-converge-gateway-card-expiry");
        var $cvc = $("#elavon-converge-gateway-card-cvc");
        var $address = $("#elavon-converge-gateway-address");
        var $zip = $("#elavon-converge-gateway-zip-code");

        var ok = true;

        // noinspection JSUnresolvedFunction
        if ($creditCardNumber.val() === "") {
            ok = false;
            message = addToErrorMessage(message, "<strong>Card Number</strong> is a required field.");
        }

        // noinspection JSUnresolvedFunction
        if($expiryDate.val() === "") {
            ok = false;
            message = addToErrorMessage(message, "<strong>Expiration Date</strong> is a required field.");
        } else { // noinspection JSUnresolvedFunction
            if(! validateExpirationDate($expiryDate.val())) {
                ok = false;
                message = addToErrorMessage(message, "The <strong>Expiration Date</strong> is not valid.");
            }
        }

        // noinspection JSUnresolvedFunction
        if($cvc.val() === "") {
            ok = false;
            message = addToErrorMessage(message, "<strong>Card Verification Number</strong> is a required field.");
        } else { // noinspection JSUnresolvedFunction
            if($cvc.val().length < 3) {
                ok = false;
                message = addToErrorMessage(message, "<strong>Card Verification Number</strong> must be at least 3 characters long");
            }
        }

        // Check the address
        if($address.val() === "") {
            ok = false;
            message = addToErrorMessage(message, "<strong>Address</strong> is a required field.");
        }

        if($zip.val() === "") {
            ok = false;
            message = addToErrorMessage(message, "<strong>Zip Code</strong> is a required field.");
        }

        $(".woocommerce-error").remove();

        if(!ok) {

            $("#add_payment_method").prepend('<div class="woocommerce-error">' + message + '</div>');
            // noinspection JSUnresolvedFunction
            $.scroll_to_notices($(".woocommerce-error"));
            event.preventDefault();
        }
    });

})(jQuery);