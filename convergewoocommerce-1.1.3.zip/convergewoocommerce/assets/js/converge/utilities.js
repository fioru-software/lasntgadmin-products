(function($) {
    function Utilities() {

    }

    Utilities.prototype.allowSpecialCharacters = function(e) {
        if ($.inArray(e.keyCode, [46, 8, 9, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 35, 36, 37, 38, 39, 40]) !== -1 ||
            // Allow: Ctrl/cmd+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: Ctrl/cmd+C
            (e.keyCode === 67 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: Ctrl/cmd+X
            (e.keyCode === 88 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: Ctrl/cmd+v
            (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true))) {
            // let it happen, don't do anything
            return true;
        } else {
            return false;
        }
    };

    Utilities.prototype.limitInputField = function(selector, limit) {
        var instance = this;

        $(document).on("keydown", selector, function(e) {
            if(instance.allowSpecialCharacters(e)) {
                return;
            }

            if($(this).val().length === limit) {
                e.preventDefault();
            }
        });
    };


    Utilities.prototype.getForm = function() {
        var $checkout_form = $("form[name='checkout']");
        if (!$checkout_form.length) {
            $checkout_form = $('#order_review');
        }
        return $checkout_form;
    }

    Utilities.prototype.restrictToNumeric = function(selector, allowMinus, allowDot) {
        allowMinus = allowMinus || false;
        allowDot = allowDot || false;

        var instance = this;

        $(document).on("keydown", selector, function(e) {
            if(instance.allowSpecialCharacters(e)) {
                return;
            }

            if (allowMinus) {
                if (e.keyCode === 189 || e.keyCode === 109) {
                    if ($(this).val().indexOf("-") > -1 || $(this)[0].selectionStart !== 0) {
                        return false;
                    } else {
                        return true;
                    }
                }
            }

            if (allowDot) {
                if (e.keyCode === 190 || e.keyCode === 110) {
                    if ($(this).val().indexOf(".") > -1) {
                        return false;
                    } else {
                        return true;
                    }
                }
            }

            var ok = false;

            if (e.which >= 48 && e.which <= 57 && e.shiftKey === false && e.metaKey === false && e.ctrlKey === false) {
                ok = true;
            }

            return ok;
        });

        $(document).on("paste", selector, function() {
            var instance = this;
            setTimeout(function() {
                var pasteContent = $(instance).val();
                pasteContent = pasteContent.replace(/\D/g,'');
                $(instance).val(pasteContent);
            }, 0);
        });
    };


    Utilities.prototype.chunkSubstr = function(str, size) {
        var instance = this;
        str = instance.replaceAll(str, " ", "");
        var numChunks = Math.ceil(str.length / size);
        var chunks = new Array(numChunks);

        for (var i = 0, o = 0; i < numChunks; ++i, o += size) {
            chunks[i] = str.substr(o, size)
        }

        return chunks
    }

    Utilities.prototype.replaceAll = function(string, search, replacement) {
        return string.replace(new RegExp(search, 'g'), replacement);
    }

    Utilities.prototype.setInputFilter = function(textbox, inputFilter) {
        var instance = this;
        ["input", "keydown", "keyup", "mousedown", "mouseup", "select", "contextmenu", "drop"].forEach(function(event) {
            textbox.addEventListener(event, function() {
                if (inputFilter(this.value)) {
                    this.oldValue = this.value;
                    this.oldSelectionStart = this.selectionStart;
                    this.oldSelectionEnd = this.selectionEnd;

                    this.value = instance.chunkSubstr(this.value, 4).join(" ");

                } else if (this.hasOwnProperty("oldValue")) {
                    this.value = this.oldValue;
                    this.setSelectionRange(this.oldSelectionStart, this.oldSelectionEnd);
                } else {
                    this.value = "";
                }
            });
        });
    }

    window.Utilities = Utilities;
})(jQuery);