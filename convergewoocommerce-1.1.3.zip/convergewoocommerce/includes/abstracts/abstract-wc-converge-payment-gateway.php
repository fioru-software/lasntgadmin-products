<?php

/**
 * @noinspection DuplicatedCode
 * @noinspection PhpIncludeInspection
 * @noinspection PhpUndefinedClassInspection
 */

/**
 * Class WC_Converge_Payment_Gateway
 */
abstract class WC_Converge_Payment_Gateway extends WC_Payment_Gateway_CC {

	/**
	 * WC_Converge_Payment_Gateway constructor.
	 */
	public function __construct() {
		if ( WC_Converge_Gateway_Helper::skip_loading_plugin() ) {
			return;
		}
		$request  = $this->getRequest();

		$accessor = 'converge_route';
		if (
			array_key_exists( $accessor, $request ) &&
			! empty( $request[ $accessor ] ) &&
			( strpos( $request[ $accessor ], '@' ) !== false )
		) {
			list( $path, $action ) = explode( '@', $request[ $accessor ] );
		}
		$postData        = $this->get_post_data();
		$routePathAction = $this->get_field_value( $accessor, $postData );

		if ( ! empty( $value = $this->get_field_key( $accessor ) ) && ! empty( $routePathAction ) ) {
			list( $path, $action ) = explode( '@', $routePathAction );
		}
		if ( ! empty( $path ) && ! empty( $action ) && $action != "process_admin_options"  ) {
			$settings = new WC_Converge_Gateway_Settings($this);
			$settings->$action();
		}
	}

	/**
	 * @return array
	 */
	public function getRequest() {
		return $_REQUEST;
	}
}