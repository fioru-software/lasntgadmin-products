<?php

/**
 * @noinspection DuplicatedCode
 * @noinspection PhpUndefinedClassInspection
 */

use Elavon\Converge\Api\Transaction\AccountAdministration\AccessObject\TerminalSetupAccessObject;
use Elavon\Converge\Config\MerchantConfig;
use Elavon\Converge\Converge;
use Elavon\Converge\Exception\TransferObjectValidationException;

defined('ABSPATH') || exit;

/**
 * Class WC_Converge_Gateway_Settings
 */
class WC_Converge_Gateway_Settings extends WC_Payment_Gateway
{

    /**
     * @var WC_Converge_Gateway $gateway
     */
    private $gateway;

    /**
     * @var Converge $apiGateway
     */
    private $apiGateway;


    private $useProxy = '';

    private $proxyHost = '';

    private $proxyPort = '';

	/** @var WC_Gateway_Converge_Encryption */
	protected $encryption;

    /**
     * WC_Converge_Gateway_Settings constructor.
     *
     * @param WC_Converge_Gateway $gateway
     */
    public function __construct(WC_Converge_Gateway $gateway)
    {
        $this->gateway = $gateway;
        $this->apiGateway = $gateway->getApiGateway();
    }

    private function getConvergeGateway( $merchantId, $userId, $sslPin, $sandboxMode ) {
        $merchantConfig = new MerchantConfig( $merchantId, $userId, $sslPin );
        $merchantConfig->setSandboxMode( $sandboxMode );

        if ( ! empty( $this->useProxy ) ) {
            $proxy = trim(
                $this->proxyHost . ':' . $this->proxyPort,
                ': '
            );
            $merchantConfig->setProxyRepresentation( $proxy );
        }

        return new Converge( $merchantConfig, [ 'handler' => Handler::get() ] );
    }

    /**
     * @return void
     */
    public function terminalSetup()
    {
        $requestData = $this->gateway->getRequest();

        $merchantId = $requestData['merchant_id'];
        $userId = $requestData['user_id'];
        $sslPin = $requestData['user_pin'];
        $sandboxMode = ($requestData['environment'] === WGC_SETTING_ENV_SANDBOX);

        $this->useProxy = $requestData['use_proxy'];
        $this->proxyHost = $requestData['proxy_host'];
        $this->proxyPort = $requestData['proxy_port'];

        $apiGateway = $this->getConvergeGateway( $merchantId, $userId, $sslPin, $sandboxMode);
        $accountAdministrationType = $apiGateway->getTransaction()->getAccountAdministrationType();

        $error = null;
        $pleaseEnterFields = [];
        array_map(function ($fieldName) use (
            $merchantId,
            $sslPin,
            &$error,
            &$pleaseEnterFields,
            $userId
        ) {
            if ($fieldName === WGC_MODULE_MERCHANT_ID) {
                $length = mb_strlen($merchantId);
                $isEmpty = $length < 1;

                if ($isEmpty) {
                    array_push($pleaseEnterFields, __('Please enter Merchant ID', 'elavon-converge-gateway'));
                    return;
                }
            }

            if ($fieldName === WGC_MODULE_USER_PIN) {
                if (mb_strlen($userId) < 1) {
                    array_push($pleaseEnterFields, __('Please enter User ID', 'elavon-converge-gateway'));
                }
            }

            if ($fieldName === WGC_MODULE_USER_PIN) {

                $length = mb_strlen($sslPin);
                $isEmpty = $length < 1;

                if ($isEmpty) {
                    array_push($pleaseEnterFields, __('Please enter User pin', 'elavon-converge-gateway'));

                    return;
                }
            }
        }, [WGC_MODULE_MERCHANT_ID, WGC_MODULE_USER_ID, WGC_MODULE_USER_PIN]);

        if (!empty($pleaseEnterFields)) {
            wp_send_json(['success' => false, 'message' => implode(', ', $pleaseEnterFields), 'data' => null]);
        }

        if ($error !== null) {
            wp_send_json(['success' => false, 'message' => $error, 'data' => null]);
        }

        try {

            $terminalAccessObject = $accountAdministrationType->terminalSetup($merchantId, $userId, $sslPin);

        } catch (TransferObjectValidationException $ex) {
            wp_send_json([
                'success' => false,
                'message' => __('The terminal setup was unsuccessful. Please verify the terminal settings.',
                    'elavon-converge-gateway'),
                'data' => null
            ]);
        }

        if (!$terminalAccessObject->isValid()) {
            wp_send_json([
                'success' => false,
                'message' => __('The terminal setup was unsuccessful. Please verify that you have entered the correct credentials, and try again.',
                    'elavon-converge-gateway'),
                'data' => null
            ]);
        }

        wp_send_json([
            'success' => true,
            'data' => $this->prepareTerminalSetupPopulateDataMap($terminalAccessObject),
            'message' => __('Terminal configuration completed.', 'elavon-converge-gateway')
        ]);
    }

    /**
     * @param TerminalSetupAccessObject $terminalSetupAccessObject
     *
     * @return array
     */
    private function prepareTerminalSetupPopulateDataMap(TerminalSetupAccessObject $terminalSetupAccessObject)
    {
        $terminalInformation = $terminalSetupAccessObject->getTerminalInformation();
        $response = [
            'terminalName' => $terminalInformation->get('vm_friendly_name'),
            'merchantName' => $terminalSetupAccessObject->getMerchantInformation()->get('MerchantName'),
            'region' => $terminalInformation->get('vm_region'),
            'currency' => $terminalInformation->get('vm_currency'),
            'paymentTypes' => [],
            'creditCardTypesAccepted' => [],
            'walletTypesAccepted' => [],
            'valueAddedServiceAccepted' => [],
            'currencyConversionAccepted' => [],
            'languagesAccepted' => []
        ];

        // Payment Types Accepted
        $terminalPaymentTypes = $terminalInformation->get('vm_payment_types');
        $terminalAccessorMap = [
            'Credit' => WGC_SETTING_PAYMENT_TYPE_CC,
            'Gift' => WGC_SETTING_PAYMENT_TYPE_GIFT_CARD,
            'ECheck' => WGC_SETTING_PAYMENT_TYPE_ACH
        ];
        $translations = [
            'Credit' => __('Credit Card', 'elavon-converge-gateway'),
            'Gift' => __('Gift Card', 'elavon-converge-gateway'),
            'ECheck' => __('ACH', 'elavon-converge-gateway')
        ];

        foreach ($terminalAccessorMap as $terminalKey => $optionKey) {
            if($terminalPaymentTypes->get($terminalKey) === 'Y') {
                $response['paymentTypes'][] = [
                    "value" => $optionKey,
                    "label" => $translations[$terminalKey]
                ];
            }
        }

        // Credit Card Types Accepted
        $terminalCreditCardsAccepted = $terminalInformation->get('vm_card_brands');
        $terminalAccessorMap = [
            'Visa' => WGC_SETTING_CC_ACCEPTED_VISA,
            'MasterCard' => WGC_SETTING_CC_ACCEPTED_MASTER_CARD,
            'AmEx' => WGC_SETTING_CC_ACCEPTED_AMERICAN_EXPRESS,
            'JCB' => WGC_SETTING_CC_ACCEPTED_JCB,
            'CUP' => WGC_SETTING_CC_ACCEPTED_CUP,
            'Discover' => WGC_SETTING_CC_ACCEPTED_DISCOVER
        ];
        $translations = [
            'Visa' => __('Visa', 'elavon-converge-gateway'),
            'MasterCard' => __('Master Card', 'elavon-converge-gateway'),
            'AmEx' => __('American Express', 'elavon-converge-gateway'),
            'JCB' => __('JCB (Japan Credit Bureau)', 'elavon-converge-gateway'),
            'CUP' => __('CUP (Chinese UnionPay)', 'elavon-converge-gateway'),
            'Discover' => __('Discover', 'elavon-converge-gateway')
        ];

        foreach ($terminalAccessorMap as $terminalKey => $optionKey) {
            if($terminalCreditCardsAccepted->get($terminalKey) === 'Y') {
                $response['creditCardTypesAccepted'][] = [
                    "value" => $optionKey,
                    "label" => $translations[$terminalKey]
                ];
            }
        }

        // Wallet Types Accepted
        $terminalWalletsAccepted = $terminalInformation->get('vm_wallet');
        $terminalAccessorMap = [
            'MasterPass' => WGC_SETTING_WALLET_MASTERPASS,
            'VisaCheckout' => WGC_SETTING_WALLET_VISA,
            'PayPal' => WGC_SETTING_WALLET_PP,
            'ApplePay' => WGC_SETTING_WALLET_APPLE
        ];

        $translations = [
            'MasterPass' => __('MasterPass', 'elavon-converge-gateway'),
            'VisaCheckout' => __('Visa Checkout', 'elavon-converge-gateway'),
            'PayPal' => __('PayPal', 'elavon-converge-gateway'),
            'ApplePay' => __('ApplePay', 'elavon-converge-gateway')
        ];

        foreach ($terminalAccessorMap as $terminalKey => $optionKey) {
            $hasTerminalAnyWallets = $terminalWalletsAccepted;
            $selected = $hasTerminalAnyWallets === null ? false : $terminalWalletsAccepted->get($terminalKey) === 'Y';
            if($selected) {
                $response['walletTypesAccepted'][] = [
                    "value" => $optionKey,
                    "label" => $translations[$terminalKey]
                ];
            }
        }

        // Currency Conversion
        $terminalCreditOptionsAccepted = $terminalInformation->get('vm_credit_option');
        $terminalAccessorMap = [
            'DCC' => WGC_SETTING_CURRENCY_DYNAMIC,
            'MCC' => WGC_SETTING_CURRENCY_MULTI
        ];

        $translations = [
            'DCC' => __('Dynamic Currency Conversion', 'elavon-converge-gateway'),
            'MCC' => __('Multi Currency Conversion', 'elavon-converge-gateway')
        ];

        foreach ($terminalAccessorMap as $terminalKey => $optionKey) {
            if($terminalCreditOptionsAccepted->get($terminalKey) === 'Y') {
                $response['currencyConversionAccepted'][] = [
                    "value" => $optionKey,
                    "label" => $translations[$terminalKey]
                ];
            }
        }

        // Languages accepted
        $response['languagesAccepted'][] = [
            "value" => 'en_US',
            "label" => __('English', 'elavon-converge-gateway')
        ];

        // Value Added Service Types Accepted
        list($level3, $secure3D, $secure3D2, $tokenization)
            = $terminalSetupAccessObject->getTerminalValueAddedServices();
        $terminalAccessorMap = array(
            WGC_SETTING_VALUE_ADDED_SERVICE_3D_LEVEL => __('Level 3 Data', 'elavon-converge-gateway'),
            WGC_SETTING_VALUE_ADDED_SERVICE_3DS => __('3DSecure 1.0', 'elavon-converge-gateway'),
            WGC_SETTING_VALUE_ADDED_SERVICE_3DS2 => __('3DSecure 2.0', 'elavon-converge-gateway'),
            WGC_SETTING_VALUE_ADDED_SERVICE_TOKENIZATION => __('Tokenization', 'elavon-converge-gateway')
        );
        $valueAddedServiceAccepted = array(
            WGC_SETTING_VALUE_ADDED_SERVICE_3D_LEVEL => $level3 === 'Y',
            WGC_SETTING_VALUE_ADDED_SERVICE_3DS => $secure3D === 'Y',
            WGC_SETTING_VALUE_ADDED_SERVICE_3DS2 => $secure3D2 === 'Y',
            WGC_SETTING_VALUE_ADDED_SERVICE_TOKENIZATION => $tokenization === 'Y',
        );

        foreach ($valueAddedServiceAccepted as $optionKey => $isAccepted) {
            if($isAccepted) {
                $response['valueAddedServiceAccepted'][] = [
                    "value" => $optionKey,
                    "label" => $terminalAccessorMap[$optionKey]
                ];
            }
        }

        return $response;
    }

    public function process_admin_options()
    {
        $post_data = $this->gateway->get_post_data();
        $form_fields = $this->gateway->get_form_fields();

        $maxLength = [
            WGC_KEY_TITLE => 64,
            WGC_KEY_LICENSE_CODE => 64,
            WGC_KEY_SAVE_FOR_LATER_USE => 255
        ];

        foreach ($form_fields as $key => $field) {
            try {
                if ($key === WGC_MODULE_USER_PIN) {
                    $value = $this->gateway->get_field_value($key, $field, $post_data);

                    if ($value === ENCRYPTION_KEY_MASK) {
                        $value = $this->get_option(WGC_MODULE_USER_PIN);
                    }

                    $this->gateway->settings[$key] = $value;
                    continue;
                }

                if ($key === WGC_MODULE_TERMINAL_SETUP) {
                    $this->gateway->settings[$key] = WGC_MODULE_TERMINAL_SETUP_VALUE;
                    continue;
                }

                if (
                    array_key_exists($key, $maxLength) &&
                    (mb_strlen($this->gateway->get_field_value($key, $field, $post_data)) > $maxLength[$key])
                ) {
                    $this->add_error(
                        vsprintf(
                            __(
                                'Max length for field: %s is: %s characters.',
                                'elavon-converge-gateway'
                            ),
                            [$key, $maxLength[$key]]
                        )
                    );
                }

                $this->gateway->settings[$key] = $this->gateway->get_field_value(
                    $key,
                    $field,
                    $post_data
                );

            } catch (Exception $e) {
                $this->add_error($e->getMessage());
            }
        }

	    $this->gateway->settings[ WGC_KEY_TITLE ] = htmlentities( $this->gateway->get_field_value( WGC_KEY_TITLE, $form_fields[ WGC_KEY_TITLE ], $post_data ) );

        $credentialsFields = [];
        array_map(function ($fieldName) use (
            $form_fields,
            $post_data,
            &$credentialsFields
        ) {
            $value = $this->gateway->get_field_value($fieldName, $form_fields[$fieldName],
                $post_data);
            $credentialsFields[$fieldName] = $value;
            if ($fieldName === WGC_MODULE_USER_PIN && $value === ENCRYPTION_KEY_MASK) {
                $credentialsFields[$fieldName] = $this->gateway->get_option($fieldName);
            }
        }, [WGC_MODULE_MERCHANT_ID, WGC_MODULE_USER_ID, WGC_MODULE_USER_PIN]);

        if ($this->get_errors()) {
            $this->display_errors();

            return false;
        }

        list($merchantId, $userId, $sslPin) = array_values($credentialsFields);

        $environment = $this->gateway->get_field_value(WGC_KEY_ENVIRONMENT, $form_fields[WGC_KEY_ENVIRONMENT], $post_data);
        $sandboxMode = ($environment === WGC_SETTING_ENV_SANDBOX);

        $this->useProxy = $this->gateway->get_field_value(WGC_KEY_USE_PROXY, $form_fields[WGC_KEY_USE_PROXY], $post_data);;
        $this->proxyHost = $this->gateway->get_field_value(WGC_KEY_PROXY_HOST, $form_fields[WGC_KEY_PROXY_HOST], $post_data);;
        $this->proxyPort = $this->gateway->get_field_value(WGC_KEY_PROXY_PORT, $form_fields[WGC_KEY_PROXY_PORT], $post_data);;

        $apiGateway = $this->getConvergeGateway( $merchantId, $userId, $sslPin, $sandboxMode );

        $administrationType = $apiGateway->getTransaction()->getAccountAdministrationType();

        $requiredFields = [
            'ssl_merchant_id' => __('Merchant ID is required.', 'elavon-converge-gateway'),
            'ssl_user_id' => __('User ID is required.', 'elavon-converge-gateway'),
            'ssl_pin' => __('User pin field is required.', 'elavon-converge-gateway')
        ];

        try {
            $terminalAccessObject = $administrationType->terminalSetup();
            if (!$terminalAccessObject->isValid()) {
                $terminalResponse = $terminalAccessObject->getResponse();
                $this->add_error($terminalResponse->getExceptionMessage());
            }
        } catch (TransferObjectValidationException $ex) {
            foreach ($ex->getMessages() as $field => $value) {
                $this->add_error($requiredFields[$field]);
            }
        }

        if ($this->get_errors()) {
            $this->display_errors();

            return false;
        }
        $gift_security_code = $terminalAccessObject->getTerminalInformation()->get('vm_gift_loyalty_option')->get('security_code');
        $this->gateway->settings[WGC_GIFT_CARD_SECURITY_CODE] = $gift_security_code;

        update_option(
            $this->gateway->get_option_key(),
            apply_filters(
                'woocommerce_settings_api_sanitized_fields_' . $this->gateway->id,
                $this->gateway->settings
            ),
            'yes'
        );

        wp_redirect($_SERVER['HTTP_REFERER']."&config_saved=1");
        exit;
    }
}