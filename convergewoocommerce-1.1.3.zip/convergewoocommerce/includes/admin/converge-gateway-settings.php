<?php

/** @noinspection DuplicatedCode */

defined('ABSPATH') || exit;

include_once __DIR__ . '/../wc-converge-gateway-constants.php';

$credentials = [
	[
		'title'       => __('Credentials Converge Payment Settings', 'elavon-converge-gateway'),
		'type'        => 'title',
		'description' => '<hr/>',
	],
	WGC_KEY_ENVIRONMENT       => [
		'title'             => __('Environment', 'elavon-converge-gateway'),
		'type'              => 'select',
		'class'             => 'wc-enhanced-select terminal-setup-notifier',
		'default'           => WGC_SETTING_ENV_SANDBOX,
		'options'           => [
			WGC_SETTING_ENV_SANDBOX    => __('Sandbox', 'elavon-converge-gateway'),
			WGC_SETTING_ENV_PRODUCTION => __('Production', 'elavon-converge-gateway'),
		],
        'desc_tip' => __( 'Choose environment.', 'elavon-converge-gateway' ),
		'css'               => 'min-width: 400px!important; height: 32px !important; background: transparent;'
	],
	WGC_MODULE_MERCHANT_ID    => [
		'title'             => __('Merchant ID', 'elavon-converge-gateway'),
		'type'              => 'text',
		'arg_options'       => [
			'sanitize_callback' => 'sanitize_text_field',
		],
        'custom_attributes' => array( 'required' => true, ),
        'desc_tip' => __( 'The merchant ID is the Elavon-assigned Converge account ID.', 'elavon-converge-gateway' ),
		'class'             => 'terminal-setup-notifier',
	],
	WGC_MODULE_USER_ID        => [
		'title'             => __('User ID', 'elavon-converge-gateway'),
		'type'              => 'text',
		'arg_options'       => [
			'sanitize_callback' => 'sanitize_text_field',
		],
        'custom_attributes' => array( 'required' => true, ),
        'desc_tip' => __( 'The user ID is the Converge user ID that can send transaction requests through the terminal.', 'elavon-converge-gateway' ),
		'class'             => 'terminal-setup-notifier',
	],
	WGC_MODULE_USER_PIN       => [
		'title'             => __('User Pin', 'elavon-converge-gateway'),
		'type'              => 'password',
		'arg_options'       => [
			'sanitize_callback' => 'sanitize_text_field',
		],
		'class'             => 'terminal-setup-notifier',
        'custom_attributes' => array( 'required' => true, ),
        'desc_tip' => __( 'The user pin is the unique identifier of the terminal that will process the transaction request and submit to the Converge gateway.', 'elavon-converge-gateway' ),
	],
	WGC_MODULE_TERMINAL_NAME  => [
		'title'             => __('Terminal Name', 'elavon-converge-gateway'),
		'type'              => 'text',
		'arg_options'       => [
			'sanitize_callback' => 'sanitize_text_field',
		],
		'custom_attributes' => [
			'readonly' => 'readonly'
		],
        'desc_tip' => __( 'The terminal name is automatically filled based on terminal credentials.', 'elavon-converge-gateway' ),
	],
	WGC_MODULE_TERMINAL_SETUP => [
		'title'    => __('Terminal Setup', 'elavon-converge-gateway'),
		'default'  => __('Setup', 'elavon-converge-gateway'),
		'type'     => 'button',
		'desc_tip' => true,
		'class'    => 'button-primary',
		'css'      => 'line-height: 10px;',
		'id'       => 'activate',
	],
];

//$basic = include_once __DIR__ . '/settings/basic.php';
$basic = [
	[
		'title'       => __( 'Basic Converge Payment Settings', 'elavon-converge-gateway' ),
		'type'        => 'title',
		'description' => '<hr/>',
		'maxlength'=>64,

	],
	WGC_KEY_TITLE              => [
		'title'    => __( 'Title', 'elavon-converge-gateway' ),
		'type'     => 'text',
        'desc_tip' => __( 'Payment method title that the customer will see during checkout.', 'elavon-converge-gateway' ),
		'custom_attributes' => [
			'maxLength' => 64
		],

	],
	WGC_KEY_ENABLED            => [
		'title'    => __( 'Enabled', 'elavon-converge-gateway' ),
		'type'     => 'select',
		'options'  => [
			WGC_SETTING_ENABLED_NO  => __( 'No', 'elavon-converge-gateway' ),
			WGC_SETTING_ENABLED_YES => __( 'Yes', 'elavon-converge-gateway' ),
		],
        'desc_tip' => __( 'When enabled, the Wordpress site will be connected to the Converge environment.', 'elavon-converge-gateway' ),
	],

    WGC_KEY_DEBUG       => array(
        'title'       => __( 'Debug Log', 'elavon-converge-gateway' ),
        'type'        => 'checkbox',
        'label'       => __( 'Enable logging', 'elavon-converge-gateway' ),
        'default'     => WGC_SETTING_DEBUG_NO,
        /* translators: %s: URL */
        'description' => sprintf( __( 'Log Converge events inside %s . Use only for development purposes.', 'elavon-converge-gateway' ), '<code><a href='.admin_url('/admin.php?page=wc-status&tab=logs').'>' . WC_Log_Handler_File::get_log_file_path( wgc_get_payment_name() ) . '</a></code>' )
    ),

	WGC_KEY_PAYMENT_ACTION     => [
		'title'    => __( 'Payment Action', 'elavon-converge-gateway' ),
		'type'     => 'select',
		'options'  => [
			WGC_SETTING_PAYMENT_ACTION_AUTH_ONLY => __( 'Authorize', 'elavon-converge-gateway' ),
			WGC_SETTING_PAYMENT_ACTION_CAPTURE   => __( 'Authorize and Capture', 'elavon-converge-gateway' )
		],
		'default'  => WGC_SETTING_PAYMENT_ACTION_AUTH_ONLY,
        'desc_tip' => __( 'Choose whether you wish to capture funds immediately or authorize payment only.', 'elavon-converge-gateway' ),
	],
	WGC_KEY_INTEGRATION_OPTION => [
		'title'    => __( 'Integration Method', 'elavon-converge-gateway' ),
		'type'     => 'select',
		'options'  => [
			WGC_SETTING_INTEGRATION_HPP          => __( 'Lightbox (PCI SAQ A)', 'elavon-converge-gateway' ),
			WGC_SETTING_INTEGRATION_HPP_CHECKOUT => __( 'Checkout.js (PCI SAQ A-EP)', 'elavon-converge-gateway' )
		],
		'default'  => WGC_SETTING_INTEGRATION_HPP,
        'desc_tip' => __( 'Choose the integration method.', 'elavon-converge-gateway' ),
	],
	WGC_KEY_LICENSE_CODE       => [
		'title'             => __( 'License Code', 'elavon-converge-gateway' ),
		'type'              => 'text',
		'desc_tip'          => true,
		'custom_attributes' => [
			'max' => 64
		]
	],
	WGC_KEY_SAVE_FOR_LATER_USE => [
		'css'               => 'width: 400px;',
		'title'             => __( 'Save for Later Use Message', 'elavon-converge-gateway' ),
		'type'              => 'textarea',
        'default'           =>  __( 'By placing your order, you agree with your card details being saved.', 'elavon-converge-gateway' ),
        'desc_tip' => __( 'This message will be displayed to the shopper next to the Save for later use option.', 'elavon-converge-gateway' ),
		'custom_attributes' => [
			'max' => 255
		]
	],
];

//$advanced = include_once __DIR__ . '/settings/advanced.php';
$advanced = [
	[
		'title'       => __('Advanced Converge Payment Settings', 'elavon-converge-gateway'),
		'type'        => 'title',
		'description' => '<hr/>',
	],
	WGC_KEY_MERCHANT_NAME         => [
		'title'             => __('Merchant Name', 'elavon-converge-gateway'),
		'type'              => 'text',
		'custom_attributes' => [
			'readonly' => 'readonly'
		],
        'desc_tip' => __( 'The merchant name, as set up for the terminal.', 'elavon-converge-gateway' ),
	],
	WGC_KEY_REGION                => [
		'title'             => __('Region', 'elavon-converge-gateway'),
		'type'              => 'text',
		'custom_attributes' => [
			'readonly' => 'readonly'
		],
        'desc_tip' => __( 'The region, as set up for the terminal.', 'elavon-converge-gateway' ),
	],

    WGC_KEY_CURRENCY                => [
        'title'             => __('Currency', 'elavon-converge-gateway'),
        'type'              => 'text',
        'custom_attributes' => [
            'readonly' => 'readonly'
        ],
        'desc_tip'          => __('The currency for your terminal. Please select the same currency to display prices.', 'elavon-converge-gateway'),
    ],

	WGC_KEY_PAYMENT_TYPE_ACCEPTED => [
		'title'             => __('Payment Types Accepted', 'elavon-converge-gateway'),
		'type'              => 'multiselect',
		'class'             => 'cvg-multiselect',
		'custom_attributes' => [
			'disabled' => 'disabled',
			'multiple' => 'multiple'
		],
		'css'               => 'height:65px;',
		'options'           => [],
        'desc_tip' => __( 'Indicates if the terminal is set up for specific payment types.', 'elavon-converge-gateway' ),
	],
	WGC_KEY_CREDIT_CARD_ACCEPTED  => [
		'title'             => __('Credit Cards Accepted', 'elavon-converge-gateway'),
		'type'              => 'multiselect',
		'class'             => 'cvg-multiselect',
		'custom_attributes' => [
			'disabled' => 'disabled',
			'multiple' => 'multiple'
		],
		'css'               => 'height: 130px;',
		'options'           => [],
        'desc_tip' => __( 'Indicates if the terminal is set up to accept payments from specific card brands.', 'elavon-converge-gateway' ),
	],
	WGC_KEY_WALLETS_ENABLED       => [
		'title'             => __('Wallets Enabled', 'elavon-converge-gateway'),
		'type'              => 'multiselect',
		'class'             => 'cvg-multiselect',
		'custom_attributes' => [
			'disabled' => 'disabled',
			'multiple' => 'multiple'
		],
		'css'               => 'height: 90px;',
		'options'           => [],
        'desc_tip' => __( 'Indicates if the terminal is set up for specific wallets.', 'elavon-converge-gateway' ),
	],
	WGC_KEY_CURRENCY_CONVERSION   => [
		'title'             => __('Currency Conversion', 'elavon-converge-gateway'),
		'type'              => 'multiselect',
		'class'             => 'cvg-multiselect',
		'custom_attributes' => [
			'disabled' => 'disabled',
			'multiple' => 'multiple'
		],
		'css'               => 'height: 45px;',
		'options'           => [],
        'desc_tip' => __( 'Indicates if the terminal is set up for currency conversion.', 'elavon-converge-gateway' ),
	],
	WGC_KEY_LANGUAGE_TRANSLATION  => [
		'title'             => __('Language Translations', 'elavon-converge-gateway'),
		'type'              => 'multiselect',
		'class'             => 'cvg-multiselect',
		'custom_attributes' => [
			'disabled' => 'disabled',
			'multiple' => 'multiple'
		],
		'css'               => 'height: 45px;',
		'options'           => [],
        'desc_tip' => __( 'The language options for the terminal.', 'elavon-converge-gateway' ),
	],
	WGC_KEY_VALUE_ADDED_SERVICE   => [
		'title'             => __('Value Added Service', 'elavon-converge-gateway'),
		'type'              => 'multiselect',
		'class'             => 'cvg-multiselect',
		'custom_attributes' => [
			'disabled' => 'disabled',
			'multiple' => 'multiple'
		],
		'css'               => 'height: 65px;',
		'options'           => [],
        'desc_tip' => __( 'Indicates if the terminal is set up for specific value added services.', 'elavon-converge-gateway' ),
	],

    WGC_KEY_PROXY_SETTING => array(
        'title'       => __( 'Proxy Settings', 'elavon-converge-gateway' ),
        'type'        => 'title',
        'description' => __( 'If your system uses a proxy server to establish the connection between WooCommerce and Converge, set API Uses Proxy to “Yes” and complete the Proxy Host and Proxy Port fields.', 'elavon-converge-gateway' ),
    ),
    WGC_KEY_USE_PROXY  => array(
        'title'       => __( 'API Uses Proxy', 'elavon-converge-gateway' ),
        'type'        => 'select',
        'class'       => 'wc-enhanced-select',
        'default'     => WGC_SETTING_USE_PROXY_NO,
        'options'     => array(
            WGC_SETTING_USE_PROXY_NO  => __( 'No', 'elavon-converge-gateway' ),
            WGC_SETTING_USE_PROXY_YES => __( 'Yes', 'elavon-converge-gateway' ),
        ),
    ),
    WGC_KEY_PROXY_HOST  => array(
        'title'       => __( 'Proxy Host', 'elavon-converge-gateway' ),
        'type'        => 'text',
        'arg_options' => array(
            'sanitize_callback' => 'sanitize_text_field',
        ),
    ),
    WGC_KEY_PROXY_PORT  => array(
        'title'       => __( 'Proxy Port', 'elavon-converge-gateway' ),
        'type'        => 'text',
        'arg_options' => array(
            'sanitize_callback' => 'sanitize_text_field',
        ),
    ),

];

return array_merge_recursive(
    $credentials,
    $basic,
    $advanced,
    [
        WGC_CONVERGE_ROUTE => [
            'type'    => 'hidden',
            'default' => 'admin/class-wc-converge-gateway-settings@process_admin_options'
        ]
    ]
);