<?php

/**
 * Class WC_Converge_Gateway_Helper
 */
class WC_Converge_Gateway_Helper
{

    // Check if we need to skip loading plugin - Wocommerce settings other than our plugin  won't save if we don't skip
    public static function skip_loading_plugin()
    {
        $skip_loading = false;
        $elavon_section = isset($_GET['section']) && $_GET['section'] === WGC_PAYMENT_NAME;

        $checkout_tab = isset($_GET['tab']) && $_GET['tab'] === 'checkout' && !isset($_GET['section']);

        if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'wc-settings' && !$elavon_section && !$checkout_tab) {

            $skip_loading = true;
        }

        return $skip_loading;
    }

    public function validate_add_card_form($card_number, $card_expiry, $card_verification_number, $address, $zip_code)
    {

        $message = '';

        if ($card_number == '') {
            $message = $message . "<br/> " . __('<strong>Card Number</strong> is required field.');
        }
        if ($card_expiry == '') {
            $message = $message . "<br/> " . __('<strong>Expiry Date</strong> is required field.');
        }
        if ($card_verification_number == '') {
            $message = $message . "<br/> " . __('<strong>Card Verification Number</strong> is required field.');
        }
        if ($address == '') {
            $message = $message . "<br/> " . __('<strong>Address</strong> is required field.');
        }
        if ($zip_code == '') {
            $message = $message . "<br/> " . __('<strong>Zip Code</strong> is required field.');
        }

        if (strpos($message, "<br/> ") === 0) {
            $message = substr($message, 6);
        }

        return $message;
    }

    public static function resolveConvergeResponse($converge_response)
    {
        if (is_array($converge_response) && array_key_exists('ssl_result', $converge_response) && ($converge_response['ssl_result'] === "0")) {
            return "approved";
        }
	    if (is_array($converge_response) && !array_key_exists('ssl_result_message', $converge_response)) {
		    return "error";
	    }

        return "declined";
    }

    public static function cleanString($string, $lengthLimit = 0 )
    {
        $string = preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($string));

        $lengthLimit = (int) $lengthLimit;
        if (strlen($string) > $lengthLimit && $lengthLimit > 10)
            $string = substr($string, 0, ($lengthLimit-3) ) . '...';
        else if (strlen($string) > $lengthLimit && $lengthLimit > 0)
            $string = substr($string, 0, $lengthLimit);

        return $string;
    }

}