<?php

/** @noinspection PhpUndefinedClassInspection */
/** @noinspection DuplicatedCode */

defined('ABSPATH') || exit;

use Elavon\Converge\Config\MerchantConfig;
use Elavon\Converge\Constant\Field;
use Elavon\Converge\Converge;
use Elavon\Converge\Exception\TransferObjectValidationException;

/**
 * Class WC_Converge_Gateway
 */
class WC_Converge_Gateway extends WC_Converge_Payment_Gateway
{

    /**
     * @var WC_Gateway_Converge_Api
     */
    private $converge_api;

    /**
     * @var Converge
     */
    protected $apiGateway;

    /**
     * @var
     */
    private $converge_order_wrapper;

    protected $c1ApiService;

    /**
     * @var string
     */
    public $stored_card_key;
    /**
     * @var string
     */
    public $new_card_key;
    /**
     * @var string
     */
    public $new_card_value;

    /**
     * @var array
     */
    const LOG_LEVEL_MAP = [
        'log_level_debug' => WC_Log_Levels::DEBUG,
        'log_level_error' => WC_Log_Levels::ERROR,
        'log_level_critical' => WC_Log_Levels::CRITICAL
    ];

	/** @var WC_Gateway_Converge_Encryption */
	public $encryption;

	/**
     * WC_Converge_Gateway constructor.
     * @noinspection PhpUndefinedFieldInspection
     */
    public function __construct()
    {
        if (WC_Converge_Gateway_Helper::skip_loading_plugin()) {
            return;
        }
        $this->id = WGC_PAYMENT_NAME;
	    $this->method_title = __( 'Elavon Converge NA Gateway', 'elavon-converge-gateway' );
	    $this->title = $this->get_option( WGC_KEY_TITLE );
	    $this->method_description = sprintf( __( 'Receive credit card payments using %1$s.',
			    'elavon-converge-gateway' ), $this->method_title ) . '</br>' . $this->get_plugin_version();
        $this->has_fields = true;
        $this->supports = ['products', 'refunds', 'tokenization', 'add_payment_method', 'default_credit_card_form'];
        $this->description = $this->method_description;
	    $this->init_encryption();

        // Load the form fields / admin scripts and settings
        $this->init_form_fields();
        $this->init_admin_scripts();

        // Get settings values
        $this->enabled = $this->get_option(WGC_KEY_ENABLED, WGC_SETTING_ENABLED_NO);
        $this->environment = $this->get_option(WGC_KEY_ENVIRONMENT, WGC_SETTING_ENV_SANDBOX);
	    $this->sandboxMode = WGC_SETTING_ENV_SANDBOX === $this->get_option( WGC_KEY_ENVIRONMENT, WGC_SETTING_ENV_PRODUCTION );
	    $this->merchant_id = $this->get_option(WGC_MODULE_MERCHANT_ID);
        $this->user_id = $this->get_option(WGC_MODULE_USER_ID);
        $this->user_pin = $this->get_option(WGC_MODULE_USER_PIN);
        $this->terminal_name = $this->get_option(WGC_MODULE_TERMINAL_NAME);
        $this->terminal_setup = $this->get_option(WGC_MODULE_TERMINAL_SETUP, WGC_MODULE_TERMINAL_SETUP_VALUE);

        // Create SDK Gateway Instance
        $this->createApiGateway($this->merchant_id, $this->user_id, $this->user_pin, $this->sandboxMode);

        $this->stored_card_key = $this->id . '_stored_card';
        $this->new_card_key = $this->stored_card_key . '_new';
        $this->new_card_value = $this->id . '_new_card';

        $this->map_advanced_settings_section();

        /*Call payment scripts only on checkout page*/
        if (is_checkout()) {
            add_action('wp_enqueue_scripts', array($this, 'payment_scripts'));
        }

	    add_action( 'woocommerce_api_'. $this->get_gateway_id(), array( $this, 'return_handler' ) );

        wp_register_style('woocommerce_converge_css_fix',
            plugins_url('../assets/css/converge/css-fix.css', __FILE__));
        wp_enqueue_style('woocommerce_converge_css_fix');

        add_filter('woocommerce_payment_methods_list_item', array($this, 'payment_methods_list_item'), 10, 2);
        add_filter('woocommerce_available_payment_gateways', array(__CLASS__, 'available_payment_gateways'));

        add_filter('woocommerce_payment_gateway_get_saved_payment_method_option_html',
            array($this, 'woocommerce_before_account_payment_methods_checkout'), 10, 2);
        add_filter('woocommerce_payment_gateway_get_new_payment_method_option_html_label',
            array($this, 'new_payment_method_label'), 10, 2);

        if (is_add_payment_method_page()) {
            /*call script*/
            add_action('wp_enqueue_scripts', array($this, 'store_cards_script'));

            /*filter form fields*/
            add_filter('woocommerce_credit_card_form_fields', array($this, 'custom_credit_card_fields'), 10, 2);
        }

        add_action('woocommerce_update_options_payment_gateways_' . $this->get_gateway_id(), array(
            &$this,
            'process_admin_options'
        ));

        $this->converge_api = new WC_Gateway_Converge_Api($this);
        $this->setConvergeOrderWrapper(new WC_Gateway_Converge_Order_Wrapper($this));

        add_action('woocommerce_order_action_wgc_capture_transaction', array(
            $this,
            'capture_handler'
        ));

        add_action('woocommerce_order_action_wgc_void_transaction', array(
            $this,
            'void_handler'
        ));

        add_action('woocommerce_order_action_wgc_settle_transaction', array(
            $this,
            'settle_handler'
        ));

	    add_filter( "woocommerce_settings_api_sanitized_fields_" . $this->get_gateway_id(),
		    array( $this, 'encrypt_credential_settings' ) );


        if ( WC()->session && WC()->session->get( 'notice_store_card' ) ) {
            add_filter( 'woocommerce_thankyou_order_received_text', array( $this, 'order_received_message' ), 10, 2 );
            unset( WC()->session->notice_store_card );
        }

        parent::__construct();
    }

	/**
	 * @inheritdoc
	 */
	public function process_admin_options() {

		$settings = new WC_Converge_Gateway_Settings($this);
		return $settings->process_admin_options();
	}

	protected function init_encryption()
	{
		if (is_null($this->encryption)) {
			$this->encryption = new WC_Gateway_Converge_Encryption(wp_salt());
		}
	}

	/**
	 * Override for secret key encription.
	 *
	 */
	public function init_settings() {

		parent::init_settings();
		$this->init_encryption();

		if (!empty($this->settings[WGC_MODULE_USER_PIN])) {
			$this->settings[WGC_MODULE_USER_PIN] = $this->decrypt_credential($this->settings[WGC_MODULE_USER_PIN]);
		}
	}

	/**
	 * Encrypt multiple credentials.
	 *
	 * @param array $settings gateway settings
	 *
	 * @return array
	 */
	public function encrypt_credential_settings( $settings ) {

		if ( ! empty( $settings[ WGC_MODULE_USER_PIN ] ) ) {
			$settings[ WGC_MODULE_USER_PIN ] = $this->encrypt_credential( $settings[ WGC_MODULE_USER_PIN ] );
		}

		return $settings;
	}

	/**
	 * Encrypt single credential.
	 *
	 * @param string $credential
	 *
	 * @return string
	 */
	public function encrypt_credential( $credential ) {

		if ( empty( $credential ) ) {
			return null;
		}

		return $this->encryption->encryptCredential( $credential );
	}


	/**
	 * Decrypt single credential.
	 *
	 * @param string $credential
	 *
	 * @return string
	 */
	public function decrypt_credential( $credential ) {

		if ( empty( $credential ) ) {
			return null;
		}

		return $this->encryption->decryptCredential( $credential );
	}

    /**
     * Initialize gateway form fields.
     *
     * @return void
     */
    public function init_form_fields()
    {
        $this->form_fields = include __DIR__ . '/admin/converge-gateway-settings.php';
    }

    /**
     * @param WC_Gateway_Converge_Order_Wrapper $converge_order_wrapper
     */
    public function setConvergeOrderWrapper(WC_Gateway_Converge_Order_Wrapper $converge_order_wrapper)
    {
        $this->converge_order_wrapper = $converge_order_wrapper;
    }

    /**
     * Initialize required admin scripts.
     *
     * @return void
     */
    public function init_admin_scripts()
    {
        if (function_exists('get_current_screen')
            && null !== get_current_screen()
            && 'woocommerce_page_wc-settings' === get_current_screen()->id) {

            wp_register_script('woocommerce_converge_admin',
                plugins_url('assets/js/converge/admin/settings-new.js', WGC_MODULE_MAIN_FILE),
	            [],
	            rand(111, 9999),
	            true);

            wp_localize_script( 'woocommerce_converge_admin', 'wp_object', array(
                'trans_no_option' => __('No Option Available', 'elavon-converge-gateway'),
                'trans_config_saved_msg' => __('Your settings have been saved.', 'elavon-converge-gateway'),
                'config_saved' => (isset($_GET['config_saved']) ? 1 : 0),
            ) );
            wp_enqueue_script('woocommerce_converge_admin');

            wp_enqueue_style(
                'woocommerce_converge_admin_css',
                plugins_url('assets/css/converge/admin/settings.css', WGC_MODULE_MAIN_FILE),
                [],
                rand(111, 9999),
                'all'
            );

        }
    }

    /**
     * @return Converge
     */
    public function getApiGateway()
    {
        return $this->apiGateway;
    }

    /**
     * @param string $merchantId
     * @param string $userId
     * @param string $sslPin
     *
     * @return $this
     */
    public function createApiGateway($merchantId, $userId, $sslPin, $sandboxMode)
    {
        $merchantConfig = new MerchantConfig($merchantId, $userId, $sslPin);
        $merchantConfig->setSandboxMode($sandboxMode);

        if ( ! empty( $this->get_option( WGC_KEY_USE_PROXY ) ) ) {
            $proxy = trim(
                $this->get_option( WGC_KEY_PROXY_HOST ) . ':' . $this->get_option( WGC_KEY_PROXY_PORT ),
                ': '
            );
            $merchantConfig->setProxyRepresentation( $proxy );
        }

        $convergeGateway = new Converge($merchantConfig);
        $this->apiGateway = $convergeGateway;

        return $this;
    }

    /**
     * @return WC_Gateway_Converge_Order_Wrapper
     */
    public function getConvergeOrderWrapper()
    {
        return $this->converge_order_wrapper;
    }

    /**
     * @return void
     * @noinspection PhpUndefinedFieldInspection
     */
    public function map_advanced_settings_section()
    {
        $this->merchant_name = $this->get_option(WGC_KEY_MERCHANT_NAME);
        $this->region = $this->get_option(WGC_KEY_REGION);
        $this->currency = $this->get_option(WGC_KEY_CURRENCY);
        $advancedSectionOptionKeyMap = [
            WGC_SETTING_PAYMENT_TYPE_CC,
            WGC_SETTING_PAYMENT_TYPE_GIFT_CARD,
            WGC_SETTING_PAYMENT_TYPE_ACH,
            WGC_SETTING_CC_ACCEPTED_VISA,
            WGC_SETTING_CC_ACCEPTED_MASTER_CARD,
            WGC_SETTING_CC_ACCEPTED_AMERICAN_EXPRESS,
            WGC_SETTING_CC_ACCEPTED_JCB,
            WGC_SETTING_CC_ACCEPTED_CUP,
            WGC_SETTING_CC_ACCEPTED_DISCOVER,
            WGC_SETTING_WALLET_MASTERPASS,
            WGC_SETTING_WALLET_VISA,
            WGC_SETTING_WALLET_PP,
            WGC_SETTING_WALLET_APPLE,
            WGC_SETTING_VALUE_ADDED_SERVICE_3D_LEVEL,
            WGC_SETTING_VALUE_ADDED_SERVICE_3DS,
	        WGC_SETTING_VALUE_ADDED_SERVICE_3DS2,
            WGC_SETTING_VALUE_ADDED_SERVICE_TOKENIZATION,
        ];

        foreach ($advancedSectionOptionKeyMap as $optionKey) {
            $this->{$optionKey} = $this->get_option($optionKey);
        }
    }

    /**
     * @return Converge
     */
    public function getC1ApiService()
    {
        return $this->c1ApiService;
    }

	/**
	 * Return handler for Hosted Payments.
	 */
	public function return_handler() {
		@ob_clean();
		header( 'HTTP/1.1 200 OK' );

        if ( isset( $_GET['redirect_to_3eds1'] ) ) {

            // generate redirect form to 3DS1 (3ds1 - step1)
            echo $this->get_three_d_secure_redirect_form(
                $this->get_converge_3ds1_acs_url_session(),
                $this->get_converge_3ds1_pareq_session(),
                $this->get_converge_3ds1_md_session()
            );
            exit;

        }  else if ( isset( $_POST['PaRes'] ) ) {

            // return from 3ds1 (3ds1 - step2)
            echo $this->get_return_from_three_d_secure( $_REQUEST );
            exit;

        }  else if ( isset( $_POST['cc_authenticated'] ) ) {

            // get response from 3ds1 step 2 (3ds1 - step3)
            $converge_response = array();
            if ( isset( $_POST['converge_response'] ) && ! empty( $_POST['converge_response'] ) ) {
                $_response = json_decode( stripslashes( $_POST['converge_response'] ), true );

                if ( json_last_error() == JSON_ERROR_NONE ) {
                    $converge_response = $_response;
                }
            }

            $order_id = $this->get_converge_3ds1_order_id_session();
            $do_payment = $this->do_payment($order_id, $converge_response);

            if ($do_payment['result'] == 'failure') {

                wp_redirect( wc_get_page_permalink( 'cart' ) );

            } else {

                $order = wc_get_order( $order_id );
                wp_redirect( $this->get_return_url( $order ) );
            }

            $this->clear_sale_session();
            exit;
        }
        else {

			wp_redirect( wc_get_page_permalink( 'cart' ) );
		}
		exit;
	}


    /**
     * @param int $order_id
     * @return array|void
     * @throws WC_Data_Exception
     */
    public function process_payment($order_id)
    {
        $converge_response = array();
        $order = wc_get_order( $order_id );

        // reset the paid_with_lightbox session if we have checkoutJS activate
        if (WC()->session->get('paid_with_lightbox') && $this->isCheckoutJS()){
            WC()->session->set( 'paid_with_lightbox', null);
            unset(WC()->session->paid_with_lightbox);
        }

        if ( isset( $_POST['converge_response'] ) && ! empty( $_POST['converge_response'] ) ) {
            $_response = json_decode( stripslashes( $_POST['converge_response'] ), true );

            if ( json_last_error() == JSON_ERROR_NONE ) {
                $converge_response = $_response;
            }
        }

        // redirect to 3DS1 ?
        if ( array_key_exists( 'acs_url', $converge_response ) &&
             array_key_exists( 'pareq', $converge_response ) &&
             array_key_exists( 'md', $converge_response ) )
        {
            // if the user is not registered/logged-in, WooCommerce doesn't start its session until the user logs in
            if ( ! WC()->session->has_session() ) {
                WC()->session->set_customer_session_cookie( true );
            }

            $this->set_converge_3ds1_acs_url_session($converge_response['acs_url']);
            $this->set_converge_3ds1_pareq_session($converge_response['pareq']);
            $this->set_converge_3ds1_md_session($converge_response['md']);
            $this->set_converge_3ds1_order_id_session($order_id);


            if ( WC()->session->get( 'giftCardResponse' ) ) {
                unset( WC()->session->giftCardResponse );
                unset( WC()->session->elavon_converge_gateway_gift_card_number );
                unset( WC()->session->elavon_converge_gateway_gift_card_code );
            }

            if ( isset( $_POST['gift_card_response'] ) ) {
                $giftCardResponse = json_decode( stripslashes( $_POST['gift_card_response'] ), true );
                if ( $giftCardResponse !== false ) {
                    WC()->session->set('giftCardResponse', $giftCardResponse );
                    WC()->session->set('elavon_converge_gateway_gift_card_number', $_POST['elavon-converge-gateway-gift-card-number'] );
                    WC()->session->set('elavon_converge_gateway_gift_card_code', $_POST['elavon-converge-gateway-gift-card-code'] );

                    wgc_log_data( array('giftCardResponse' => $giftCardResponse), "saved gift card response in session before 3DS1 redirect", $order );
                } else {
                    wgc_log_data( array('gift_card_response' => $_POST['gift_card_response'] ), "saved gift card response in session before 3ds1 redirect", $order );
                    return error_processing_payment();
                }
            }

            return array(
                'result'   => 'success',
                'redirect' => sprintf( "%s?redirect_to_3eds1=1", $this->getReturnUrl() )
            );
        }

        return $this->do_payment($order_id, $converge_response);
    }

    protected function error_processing_payment() {
        wc_add_notice( sprintf( __( 'There was an error processing your payment.', 'elavon-converge-gateway' ) ), 'error' );

        return array( 'result' => 'failure' );
    }

    public function do_payment( $order_id, $converge_response = array() ) {
        $convergeLogger  = new ConvergeResponseLogger();
        $order           = wc_get_order( $order_id );
        $context         = isset( $_REQUEST['context'] ) ? $_REQUEST['context'] : '';
        $paid_via_wallet = isset( $converge_response['paid_via_wallet'] );
        $return_url      = $this->get_return_url( $order );

        if ( ! $paid_via_wallet ) {
            //Check if it is partial payment and we need to refund gift card
            if ( isset( $_POST['refund_gift'] ) && $_POST['refund_gift'] ) {

                if ( ( WC()->session->get( 'giftCardResponse' ) && is_array( WC()->session->get( 'giftCardResponse' ) ) ) ) {
                    $cardNumber     = WC()->session->get( 'elavon_converge_gateway_gift_card_number' );
                    $cardCode       = WC()->session->get( 'elavon_converge_gateway_gift_card_code' );
                    $amountToRefund = number_format( WC()->session->get( 'giftCardResponse' )['ssl_amount'], 2 );
                } else {
                    $cardNumber     = $_POST['elavon-converge-gateway-gift-card-number'];
                    $cardCode       = $_POST['elavon-converge-gateway-gift-card-code'];
                    $amountToRefund = number_format( $_POST['refund_gift'], 2 );
                }
                $transaction     = $this->apiGateway->getTransaction();
                $type            = $transaction->getGiftCardType();
                $giftCardHandler = new WC_Converge_Giftcard_Handler( $type, $convergeLogger );
                try {
                    $giftCardHandler->refundGiftCard( $cardNumber, $amountToRefund, $cardCode );
                } catch ( Exception $ex ) {
                    throw $ex;
                }
            }

	        $save_for_later_use = isset( $_POST['wc-elavon-converge-gateway-new-payment-method-save-for-later-use'] ) || array_key_exists( 'ssl_token', (array) $converge_response );

            if ( isset( $_POST['wc-elavon-converge-gateway-payment-token'] ) && $_POST['wc-elavon-converge-gateway-payment-token'] !== 'new' ) {

                $context = "pay with stored card";
                $stored_card       = new WC_Payment_Token_Converge_Gateway_StoredCard();
                $converge_response = $stored_card->pay_with_stored_card( $order, $context );
            }

            else if ( $save_for_later_use && ! $this->isCheckoutJS() ) {

                $context = "paid with lightbox";

                //customer token created via lightbox
                $converge_token_response = $converge_response;
                $response_type           = WC_Converge_Gateway_Helper::resolveConvergeResponse( $converge_token_response );
                $responseHandler         = new WC_Converge_Lightbox_Response( $order, $converge_token_response, $return_url,
                    $convergeLogger, $response_type, $context );
                $responseHandler->handleResponse();
                $stored_card       = new WC_Payment_Token_Converge_Gateway_StoredCard();
                $converge_response = $stored_card->pay_with_token( $converge_token_response['ssl_token'],
                    "pay with token -> " . $context,
                    $order
                );
            }
        }

        $response_type   = WC_Converge_Gateway_Helper::resolveConvergeResponse( $converge_response );
        $responseHandler = new WC_Converge_Response_Handler( $order, $converge_response, $return_url,
            $convergeLogger, $response_type, $context );

        if ( ! $paid_via_wallet ) {
            $converge_gift_card_response = null;
            if ( isset( $_POST['gift_card_response'] ) || ( WC()->session->get('giftCardResponse') && is_array(WC()->session->get('giftCardResponse')) ) ) {

                if ( isset( $_POST['gift_card_response'] ) && ! empty( $_POST['gift_card_response'] ) ) {

                    $gift_card_response = json_decode( stripslashes( $_POST['gift_card_response'] ), true );

                    if ( $gift_card_response !== false ) {
                        $converge_gift_card_response = $gift_card_response;
                    }

                } else {
                    $converge_gift_card_response = WC()->session->get('giftCardResponse');
                    WC()->session->set( 'giftCardResponse', null );
                    WC()->session->set( 'elavon_converge_gateway_gift_card_number', null );
                    WC()->session->set( 'elavon_converge_gateway_gift_card_code', null );
                    unset( WC()->session->giftCardResponse );
                    unset( WC()->session->elavon_converge_gateway_gift_card_number );
                    unset( WC()->session->elavon_converge_gateway_gift_card_code );
                }
            }

            if ( ! is_null( $converge_gift_card_response ) ) {
                $responseHandler->setGiftCardResponse( $converge_gift_card_response );
            }

            if ( $save_for_later_use ) {
                $responseHandler->setSaveForLaterUse();

                if ( ! $this->isCheckoutJS() ) {
                    $responseHandler->setTokenResponse( $converge_token_response );
                } elseif ( array_key_exists( 'ssl_token', $converge_response ) ) {
                    $responseHandler->setTokenResponse( $converge_response );
                }
            }
        }

        $result = $responseHandler->handleResponse();

        return $result;
    }


        /**
     * @param int $order_id
     * @param null $amount
     * @param string $reason
     *
     * @return bool|WP_Error
     */
    public function process_refund($order_id, $amount = null, $reason = '')
    {
        $order = wc_get_order($order_id);

        if(!wgc_is_converge_order($order)) {
            $order->add_order_note( sprintf( __( 'There was an error processing the refund. Error: The order was not made by Converge.', 'elavon-converge-gateway' )));
            return new WP_Error ('refund-error',
                sprintf(__('There was an error processing the refund. Error: The order was not made by Converge.', 'elavon-converge-gateway')));
        }

	    $transaction_id = $order->get_meta( Field::SSL_TXN_ID );
	    if ( empty( $transaction_id ) ) {
		    $transaction_id = $order->get_meta( 'ssl_gift_txn_id' );
	    }

        if (empty ($transaction_id)) {
            $order->add_order_note( sprintf( __( 'There was an error processing the refund. Error: Order %s does not contain a transaction id.', 'elavon-converge-gateway' ), $order_id));
            return new WP_Error ('refund-error',
                /* translators: %s: order id */
                sprintf(__('There was an error processing the refund. Error: Order %s does not contain a transaction id.', 'elavon-converge-gateway'),
                    $order_id));
        }

        $transaction_state = wgc_get_order_transaction_state($order);

        if(!$transaction_state->getResponse()->isSuccess()) {
            $order->add_order_note( wgc_get_order_error_note( __( 'There was an error processing the refund.',
                'elavon-converge-gateway' ),
                $transaction_state->getResponse() ) );
            return new WP_Error ('refund-error',
                sprintf(__('There was an error processing the refund. Converge error: %1$s', 'elavon-converge-gateway'), $transaction_state->getResponse()->getExceptionMessage()));
        }

        if ((float)$amount < EPSILON) {
            $order->add_order_note( sprintf( __( 'There was an error processing the refund. Error: Invalid refund amount.', 'elavon-converge-gateway' )));
            return new WP_Error ('refund-error',
                sprintf(__('There was an error processing the refund. Error: Invalid refund amount.', 'elavon-converge-gateway')));
        }

        //$gateway = new WC_Gateway_Converge_Api();
        $is_partial_payment = $this->converge_api->is_partial_payment_order($order);

        if ($is_partial_payment === false) {

            if ((float)$transaction_state->getAmount() - (float)$transaction_state->getTotalRefundedAmount() - (float)$amount < -EPSILON) {
                $order->add_order_note(sprintf(__('There was an error processing the refund. Error: Invalid refund amount.',
                    'elavon-converge-gateway')));
                return new WP_Error ('refund-error',
                    sprintf(__('There was an error processing the refund. Error: Invalid refund amount.',
                        'elavon-converge-gateway')));
            }

        }
        return $this->converge_api->refund_transaction($order, $amount);
    }

    /**
     * @return void
     */
    final public function payment_scripts()
    {
        $is_checkoutJS_integration = $this->get_option(WGC_KEY_INTEGRATION_OPTION) === "integration_checkout";
        if ($is_checkoutJS_integration) {
	        wp_enqueue_script('converge_checkoutJs', $this->getCheckoutJsUrl());
	        wp_enqueue_script('converge_efs3ds2', $this->getEfs3ds2JsUrl());

        } else {
            wp_enqueue_script('converge_lightbox', $this->getLightboxJsUrl());
        }

        wp_register_script('woocommerce_converge_utilities',
            plugins_url('../assets/js/converge/utilities.js', __FILE__));
        wp_enqueue_script('woocommerce_converge_utilities');


        wp_register_script('woocommerce_converge_checkout_service',
            plugins_url('../assets/js/converge/payment-box/checkout-service/checkout-service.js', __FILE__));

        wp_localize_script('woocommerce_converge_checkout_service', 'checkout_properties', array(
	        'wallets' => wgc_get_option(WGC_KEY_WALLETS_ENABLED),
	        'returnUrl' => $this->getReturnUrl(),
			'has3DS2Enabled' => $this->has3DS2Enabled(),
            'server3DS2Url' => $this->getServer3ds2Url()
        ));

        wp_enqueue_script('woocommerce_converge_checkout_service');

        wp_register_script('woocommerce_converge_checkout_credit_card_service',
            plugins_url('../assets/js/converge/payment-box/checkout-service/credit-card.js', __FILE__), [], false, true);
        wp_enqueue_script('woocommerce_converge_checkout_credit_card_service');

        wp_register_script('woocommerce_converge_checkout_ach_service',
            plugins_url('../assets/js/converge/payment-box/checkout-service/ach.js', __FILE__));
        wp_enqueue_script('woocommerce_converge_checkout_ach_service');

        wp_register_script('woocommerce_converge_checkout_gift_card_service',
            plugins_url('../assets/js/converge/payment-box/checkout-service/gift-card.js', __FILE__));
        wp_enqueue_script('woocommerce_converge_checkout_gift_card_service');

	    wp_register_script( 'woocommerce_converge_checkout_wallets_service',
		    plugins_url( '../assets/js/converge/payment-box/checkout-service/wallets.js', __FILE__ ), [], false, true );
	    wp_enqueue_script( 'woocommerce_converge_checkout_wallets_service' );

        wp_register_script( 'woocommerce_converge_checkout_stored_service',
            plugins_url( '../assets/js/converge/payment-box/checkout-service/stored.js', __FILE__ ), [], false, true );
        wp_enqueue_script( 'woocommerce_converge_checkout_stored_service' );

        wp_register_script('woocommerce_converge_checkout_light_box_service',
            plugins_url('../assets/js/converge/payment-box/checkout-service/lightbox.js', __FILE__));
        wp_enqueue_script('woocommerce_converge_checkout_light_box_service');

        wp_register_script('woocommerce_converge_checkout_service_factory',
            plugins_url('../assets/js/converge/payment-box/checkout-service/checkout-service-factory.js', __FILE__));
        wp_enqueue_script('woocommerce_converge_checkout_service_factory');

        wp_register_script('woocommerce_converge_payment_box',
            plugins_url('../assets/js/converge/payment-box/payment-box.js', __FILE__),
            ['woocommerce_converge_checkout_service_factory']);
        wp_localize_script('woocommerce_converge_payment_box', 'properties', array(
            'is_checkoutJS_integration' => $is_checkoutJS_integration
        ));
        wp_enqueue_script('woocommerce_converge_payment_box');

        wp_register_style('woocommerce_converge_css',
            plugins_url('../assets/css/converge/payment-box/checkout.css', __FILE__));
        wp_enqueue_style('woocommerce_converge_css');
    }


    /**
     * Init script
     */
    public function store_cards_script()
    {
	    wp_register_script( 'woocommerce_converge_stored_card_service_utilities',
		    plugins_url( '../assets/js/converge/utilities.js', __FILE__ ), [], false, true );
	    wp_enqueue_script( 'woocommerce_converge_stored_card_service_utilities' );

	    wp_register_script( 'woocommerce_converge_stored_card_service',
		    plugins_url( '../assets/js/converge/payment-box/store-card-validation.js', __FILE__ ), [], false, true );
	    wp_enqueue_script( 'woocommerce_converge_stored_card_service' );
    }

    /**
     * @param $item
     * @param $payment_token
     *
     * @return mixed
     */
    public function payment_methods_list_item($item, $payment_token)
    {
        if (WGC_PAYMENT_TOKEN_TYPE !== $payment_token->get_type()) {
            return $item;
        }

        $brand = $payment_token->get_card_scheme() == '' ? 'Card ' : $payment_token->get_card_scheme();
        $item['method']['last4'] = $payment_token->get_last4();
        $item['method']['brand'] = $brand;
        $item['expires'] = $payment_token->get_expiry_month() . '/' . substr($payment_token->get_expiry_year(),
                -2);

        return $item;
    }

    /**
     * @param $gateways
     *
     * @return mixed
     */
    public static function available_payment_gateways($gateways)
    {
        global $wp;

        if (is_add_payment_method_page() && isset ($wp->query_vars['add-payment-method'])) {
            // unset ( $gateways[ wgc_get_payment_name() ] );
        }

        return $gateways;
    }

    /**
     * @return WC_Gateway_Converge_Api
     */
    public function get_converge_api()
    {
        return $this->converge_api;
    }

    /**
     * Capture the transaction associated with the WC_Order.
     *
     * @param WC_Order $order
     */
    public function capture_handler($order)
    {
        $this->converge_api->capture_transaction($order);
    }

    /**
     * Voids the transaction associated with the WC_Order.
     *
     * @param WC_Order $order
     */
    public function void_handler($order)
    {
        $this->converge_api->void_transaction($order);
    }

    /**
     * Settles the transaction associated with the WC_Order.
     *
     * @param WC_Order $order
     */
    public function settle_handler($order)
    {
        $this->converge_api->settle_transaction($order);
    }

    /**
     * @return string
     */
    public function get_gateway_id()
    {
        return $this->id;
    }


    /**
     * @param string $name
     *
     * @return string
     */
    public function field_name($name)
    {
        return ' name="' . esc_attr($this->id . '-' . $name) . '" "';
    }

	public function add_payment_method_checkout( ) {
		$card_number = $_POST['elavon-converge-gateway-card-number'];
		$card_expiry = $_POST['elavon-converge-gateway-card-expiry'];
		$card_verification_number = $_POST['elavon-converge-gateway-card-cvc'];

		if (strpos($card_expiry, '/') !== false) {
			$card_expiry_array = explode("/", $card_expiry);
			$exp_month = trim($card_expiry_array[0]);
			$card_expiry_year = trim($card_expiry_array[1]);
			$exp_year = substr($card_expiry_year, -2);
		} else {
			$exp_month = substr($card_expiry, 0, 2);
			$exp_year = substr($card_expiry, -2);
		}

		$current_user = wp_get_current_user();
		$address = get_user_meta($current_user->ID, 'billing_address_1', true);
		$zip_code = get_user_meta($current_user->ID, 'billing_postcode', true);

		$user_info = get_userdata(get_current_user_id());
		$first_name = $user_info->first_name;
		$last_name = $user_info->last_name;

		$stored_card = new WC_Payment_Token_Converge_Gateway_StoredCard();

		$result = $stored_card->store_card($card_number, $exp_month, $exp_year, $card_verification_number, $address,
			$zip_code, $first_name, $last_name);

		if ($result['success'] == false) {
            WC()->session->set('notice_store_card', 1 );
		}
    }

    /**
     * @return array|void
     * @throws TransferObjectValidationException
     */
    public function add_payment_method()
    {
        $card_number = $_POST['elavon-converge-gateway-card-number'];
        $card_expiry = $_POST['elavon-converge-gateway-card-expiry'];
        $card_verification_number = $_POST['elavon-converge-gateway-card-cvc'];

        if (strpos($card_expiry, '/') !== false) {
            $card_expiry_array = explode("/", $card_expiry);
            $exp_month = trim($card_expiry_array[0]);
            $card_expiry_year = trim($card_expiry_array[1]);
            $exp_year = substr($card_expiry_year, -2);
        } else {
            $exp_month = substr($card_expiry, 0, 2);
            $exp_year = substr($card_expiry, -2);
        }


        $address = $_POST['elavon-converge-gateway-address'];
        $zip_code = $_POST['elavon-converge-gateway-zip-code'];
	    $user_info = get_userdata(get_current_user_id());
	    $first_name = $user_info->first_name;
	    $last_name = $user_info->last_name;


        $helper = new WC_Converge_Gateway_Helper();
        $message = $helper->validate_add_card_form($card_number, $card_expiry, $card_verification_number, $address,
            $zip_code);

        if ($message !== '') {
            wc_add_notice(
                __($message, 'elavon-converge-gateway'),
                'error'
            );
            return;
        }

        $stored_card = new WC_Payment_Token_Converge_Gateway_StoredCard();

        $result = $stored_card->store_card($card_number, $exp_month, $exp_year, $card_verification_number, $address,
            $zip_code, $first_name, $last_name);
        $message = $result['message'];

        if ($result['success'] === true) {
            $successOrError = 'success';
        } else {
            $successOrError = 'error';
        }

        wc_add_notice(__($message, 'elavon-converge-gateway'), $successOrError);
        return array('redirect'=> wc_get_account_endpoint_url( 'payment-methods' ));

    }

    /**
     * @param $text
     * @return string|void
     */
    function order_received_message($text)
    {
        $text = __('Thank you. Your order has been received. Warning! The credit card number could not be saved.');
        return $text;
    }

    /**
     * @param $stored_card
     * @return mixed
     */
    public function delete_stored_card($stored_card, $context = null, WC_Order $order = null)
    {
        wgc_log_converge_request(array('ssl_token' => $stored_card), $context, $order);

        $transaction = $this->apiGateway->getTransaction();
        $type = $transaction->getCardManagerType();
        $access_object = $type->tokenDelete($stored_card);

        if ($access_object->isValid()) {
            $response_data = $access_object->getResponse()->getData();

            wgc_log_converge_response($access_object->getResponse(), $context, $order);

            return true;

        } else {

            $error_code = $access_object->getResponse()->getException()->getCode();

            wgc_log_converge_response($access_object->getResponse(), $context, $order);

            if ($error_code === 5085) {
                return true;
            }

            return false;
        }
    }


    /**
     * @param $cc_fields
     * @param $payment_id
     * @return mixed
     */
    public function custom_credit_card_fields($cc_fields, $payment_id)
    {

        $cc_fields ['address_field'] = '<p class="form-row form-row-wide">
				<label for="' . esc_attr($this->id) . '-address">' . esc_html__('Address', 'woocommerce') . '&nbsp;<span class="required">*</span></label>
				<input id="' . esc_attr($this->id) . '-address" class="woocommerce-Input woocommerce-Input--text input-text" inputmode="text" autocorrect="no" autocapitalize="no" spellcheck="no" type="text"  ' . $this->field_name('address') . ' />
			    </p>';

        $cc_fields ['zip_code_field'] = '<p class="form-row form-row-first">
				<label for="' . esc_attr($this->id) . '-zip-code">' . esc_html__('Zip Code', 'woocommerce') . '&nbsp;<span class="required">*</span></label>
				<input id="' . esc_attr($this->id) . '-zip-code" class="woocommerce-Input woocommerce-Input--text input-text" inputmode="text" autocorrect="no" autocapitalize="no" spellcheck="no" type="tel"  ' . $this->field_name('zip-code') . ' />
			    </p>';

        return $cc_fields;
    }


    /**
     * @param $token
     * @return bool
     */
    function woocommerce_before_account_payment_methods_checkout($token)
    {

        /*Remove stored cards from checkout page if terminal does not support tokenization */
        $added_services = $this->get_option(WGC_KEY_VALUE_ADDED_SERVICE);

        if (in_array('value_added_service_tokenization', $added_services)) {
            return $token;
        } else {
            return false;
        }

    }


    /**
     * hide default checkbox save for later use
     */
    function save_payment_method_checkbox()
    {
        return null;
    }

    /**
     * @return string|void
     */
    function new_payment_method_label()
    {
        $label = __("Use new card");
        return $label;
    }


    /**
     * @param WC_Payment_Token $token
     * @return mixed|string|void
     */
    public function get_saved_payment_method_option_html($token)
    {

        $month = (int)$token->get_meta('expiry_month');
        $year = $token->get_meta('expiry_year');

        $currentMonth = (int)date("m");
        $currentYear = date("Y");

        $disabled = '';

        if ($currentYear > $year) {
            $disabled = ' disabled ';
        } elseif ($currentYear === $year) {
            if ($currentMonth > $month) {
                $disabled = ' disabled ';
            }
        }

        $html = sprintf(
            '<li class="woocommerce-SavedPaymentMethods-token">'
            . '<input id="wc-%1$s-payment-token-%2$s" type="radio" name="wc-%1$s-payment-token" value="%2$s" style="width:auto;" '
            . $disabled
            . ' class="woocommerce-SavedPaymentMethods-tokenInput" %4$s />
				<label for="wc-%1$s-payment-token-%2$s">%3$s</label>
			</li>',
            esc_attr($this->id),
            esc_attr($token->get_id()),
            $token->get_display_name(),
            checked($token->is_default(), true, false)


        );

        return apply_filters('woocommerce_payment_gateway_get_saved_payment_method_option_html', $html, $token, $this);
    }

    public function getReturnUrl(){
	    return WC()->api_request_url($this->get_gateway_id());
    }

	protected function get_return_from_three_d_secure( $params ) {

        $tplParams = array(
            'params' => $params,
            'checkoutJsUrl' => $this->getCheckoutJsUrl(),
            'returnUrlFormAction' => $this->getReturnUrl()
        );

		$template_path = WGC_DIR_PATH . 'templates/';

        wgc_log(sprintf("[order-id %s] Return from 3ds1 (3ds1 - step2) - params: %s",
                $this->get_converge_3ds1_order_id_session(),
                print_r($tplParams, true ))
        );

		return wc_get_template_html(
			'three-d-secure-response.php',
            $tplParams,
			'',
			$template_path
		);

	}

    protected function get_three_d_secure_redirect_form( $acsUrl, $pareq, $md ) {
        $template_path = WGC_DIR_PATH . 'templates/';

        $params = array(
            'acsUrl' => $acsUrl,
            'pareq' => $pareq,
            'md' => $md,
            'termUrl' => $this->getReturnUrl()
        );
        $content = wc_get_template_html(
            'three-d-secure-redirect-form.php',
            $params,
            '',
            $template_path
        );

        wgc_log(sprintf("[order-id %s] Redirect to 3DS1 (3ds1 - step1) params from the session: %s",
            $this->get_converge_3ds1_order_id_session(),
            print_r($params, true ))
        );

        return $content;

    }

    public function getPaymentTypesAccepted() {
	    return $this->get_option(WGC_KEY_PAYMENT_TYPE_ACCEPTED);
    }

	public function hasPaymentTypesAccepted() {
		$paymentTypesAccepted = $this->getPaymentTypesAccepted();
		return (is_array($paymentTypesAccepted) && count($paymentTypesAccepted) >= 1);
	}

	public function isCreditCardAccepted() {
		$paymentTypesAccepted = $this->getPaymentTypesAccepted();
		return ($this->hasPaymentTypesAccepted() && in_array(WGC_SETTING_PAYMENT_TYPE_CC, $paymentTypesAccepted));
	}

	public function isAchAccepted() {
		$paymentTypesAccepted = $this->getPaymentTypesAccepted();
		return ($this->hasPaymentTypesAccepted() && in_array(WGC_SETTING_PAYMENT_TYPE_ACH, $paymentTypesAccepted));
	}

	public function isGiftCardAccepted() {
		$paymentTypesAccepted = $this->getPaymentTypesAccepted();
		return ($this->hasPaymentTypesAccepted() && in_array(WGC_SETTING_PAYMENT_TYPE_GIFT_CARD, $paymentTypesAccepted));
	}

	public function isCheckoutJS() {
		return ($this->get_option(WGC_KEY_INTEGRATION_OPTION) === WGC_SETTING_INTEGRATION_HPP_CHECKOUT);
	}

    public function has3DS1Enabled() {
        $addedServices = $this->get_option(WGC_KEY_VALUE_ADDED_SERVICE);
        return (is_array($addedServices) && in_array(WGC_SETTING_VALUE_ADDED_SERVICE_3DS, $addedServices));
    }

	public function has3DS2Enabled() {
		$addedServices = $this->get_option(WGC_KEY_VALUE_ADDED_SERVICE);
		return (is_array($addedServices) && in_array(WGC_SETTING_VALUE_ADDED_SERVICE_3DS2, $addedServices));
	}

	public function isSavePaymentMethodsEnabled() {
		$addedServices = $this->get_option(WGC_KEY_VALUE_ADDED_SERVICE);
		return (is_array($addedServices) && in_array(WGC_SETTING_VALUE_ADDED_SERVICE_TOKENIZATION, $addedServices));
	}

	public function isLevel3Enabled() {
		$addedServices = $this->get_option(WGC_KEY_VALUE_ADDED_SERVICE);
		return (is_array($addedServices) && in_array(WGC_SETTING_VALUE_ADDED_SERVICE_3D_LEVEL, $addedServices));
	}

	public function isAuthOnly() {
		return ($this->get_option(WGC_KEY_PAYMENT_ACTION) === WGC_SETTING_PAYMENT_ACTION_AUTH_ONLY);
	}

	public function isGiftSecurityCode() {
		return ($this->get_option(WGC_GIFT_CARD_SECURITY_CODE) === "Y");
	}

	public function get_plugin_version() {
		return sprintf( __( 'Plugin version: %1$s', 'elavon-converge-gateway' ),  WGC_VERSION);
	}

	public function getCheckoutJsUrl() {
		return $this->sandboxMode  ? WGC_SANDBOX_CHECKOUT_JS_URL : WGC_PRODUCTION_CHECKOUT_JS_URL;
	}

	public function getLightboxJsUrl() {
		return $this->sandboxMode  ? WGC_SANDBOX_LIGHTBOX_JS_URL : WGC_PRODUCTION_LIGHTBOX_JS_URL;
	}

	public function getEfs3ds2JsUrl() {
		return $this->sandboxMode  ? WGC_SANDBOX_EFS_3DS2_JS_URL : WGC_PRODUCTION_EFS_3DS2_JS_URL;
	}

    public function getServer3ds2Url() {
        return $this->sandboxMode  ? WGC_SANDBOX_SERVER_3DS2_URL : WGC_PRODUCTION_SERVER_3DS2_URL;
    }

    protected function set_converge_3ds1_acs_url_session( $value ) {
        WC()->session->set('converge_3ds1_acs_url', $value );
    }

    protected function get_converge_3ds1_acs_url_session() {
        return WC()->session->get( 'converge_3ds1_acs_url' );
    }

    protected function set_converge_3ds1_pareq_session( $value ) {
        WC()->session->set('converge_3ds1_pareq', $value );
    }

    protected function get_converge_3ds1_pareq_session() {
        return WC()->session->get( 'converge_3ds1_pareq' );
    }

    protected function set_converge_3ds1_md_session( $value ) {
        WC()->session->set('converge_3ds1_md', $value );
    }

    protected function get_converge_3ds1_md_session() {
        return WC()->session->get( 'converge_3ds1_md' );
    }

    protected function set_converge_3ds1_order_id_session( $value ) {
        WC()->session->set('converge_3ds1_order_id', $value );
    }

    protected function get_converge_3ds1_order_id_session() {
        return WC()->session->get( 'converge_3ds1_order_id' );
    }

    protected function clear_sale_session() {
        unset( WC()->session->converge_3ds1_acs_url );
        unset( WC()->session->converge_3ds1_pareq );
        unset( WC()->session->converge_3ds1_md );
        unset( WC()->session->converge_3ds1_order_id );
    }




}
