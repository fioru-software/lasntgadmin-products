<?php

/**
 * Class WC_Converge_Giftcard_Handler
 */
class WC_Converge_Giftcard_Handler
{

    /**
     * @var  \Elavon\Converge\Api\Transaction\GiftCard\Type $giftCardTransaction
     */
    private $giftCardTransaction;

    /**
     * @var  WC_Order $order
     */
    private $order;

    /**
     * @var  string $return_url
     */
    private $return_url;

    /**
     * @var  $logger
     */
    private $logger;


    public function __construct($giftCardTransaction, $logger)
    {
        $this->giftCardTransaction = $giftCardTransaction;
        $this->logger = $logger;
    }


    public function getGiftCardBalance($cardnumber, $security_code = '')
    {
        $transferObject = new \Elavon\Converge\Api\Transaction\GiftCard\TransferObject\GiftCardBalanceTransferObject([
            'ssl_security_code' => $security_code,
            'ssl_card_number' => $cardnumber,
            'ssl_exp_date' => '1249',
            'ssl_vm_mobile_source' => 'NOMOB'

        ]);
        try {
            $accessObject = $this->giftCardTransaction->getBalance($transferObject);
        } catch (Exception $ex) {
            $this->logger->log($ex->getMessage());
            throw $ex;
        }

        $result = $accessObject->get('ssl_result');
        if ($result != 0 || $result == null) {
            throw new \Exception($accessObject->get('ssl_result_message'));
        }

        return $accessObject->get('ssl_account_balance');
    }

    public function refundGiftCard($cardnumber, $amount, $security_code = '')
    {
        $transferObject = new \Elavon\Converge\Api\Transaction\GiftCard\TransferObject\RefundTransferObject([
            'ssl_security_code' => $security_code,
            'ssl_card_number' => $cardnumber,
            'ssl_exp_date' => '1249',
            'ssl_amount' => (float)$amount,
            'ssl_vm_mobile_source' => 'NOMOB'

        ]);
        try {
            $accessObject = $this->giftCardTransaction->refundCard($transferObject);
        } catch (Exception $ex) {
            $this->logger->log($ex->getMessage());
            throw $ex;
        }
        return $accessObject->get('ssl_account_balance');
    }


    public function setLogger($logger)
    {
        $this->logger = $logger;
    }


    private function handleCancel()
    {
        // Maybe we will need this one ...
    }

    public function logResponse($response)
    {
        $this->logger->log($response);
    }
}