<?php

/**
 * Class WC_Converge_Lightbox_Response
 */
class WC_Converge_Lightbox_Response extends WC_Converge_Response_Handler
{
	protected function handleApproval(){
		return;
	}
}