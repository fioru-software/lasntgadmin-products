<?php

/**
 * Class WC_Converge_Response_Handler
 */
class WC_Converge_Response_Handler
{

    /**
     * @var array $converge_response
     */
    private $converge_response;


    /**
     * @var array $converge_gift_card_response - needed for partial payment with gift card
     */
    private $converge_gift_card_response = null;
    private $converge_token_response = null;
    private $save_for_later_use = false;

    /**
     * @var string $converge_response_type
     */
    private $converge_response_type;

    /**
     * @var  WC_Order $order
     */
    private $order;

    /**
     * @var  string $return_url
     */
    private $return_url;

    /**
     * @var  $logger
     */
    private $logger;

    /**
     * @var  string $context
     */
    private $context = '';

    public function __construct($order, $converge_response, $return_url, $logger, $converge_response_type, $context)
    {
        $this->order = $order;
        $this->converge_response = $converge_response;
        $this->return_url = $return_url;
        $this->logger = $logger;
        $this->converge_response_type = $converge_response_type;
        $this->context = $context;
    }

    public function setResponse($converge_response)
    {
        $this->converge_response = $converge_response;
    }


    public function setGiftCardResponse($converge_gift_card_response)
    {
        $this->converge_gift_card_response = $converge_gift_card_response;
    }

	public function setTokenResponse($converge_token_response)
	{
		$this->converge_token_response = $converge_token_response;
	}

	public function setSaveForLaterUse()
	{
		$this->save_for_later_use = true;
	}

    public function setLogger($logger)
    {
        $this->logger = $logger;
    }


    /**
     * @return array|void
     * @throws /Exception
     */
    public function handleResponse()
    {
        if ($this->converge_gift_card_response) {
            $this->logWithContext($this->converge_gift_card_response);
        }

        $this->logWithContext($this->converge_response);

        switch ($this->converge_response_type) {
            case 'approved':
                return $this->handleApproval();
            case 'declined':
                return $this->handleDeclined();
                break;
            default:
                return $this->handleError();
        }
    }


    protected function handleApproval()
    {
        global $woocommerce;
        $partial_payment = false;
        $paid_with_gift_card = 0;
        $order_total = (float)$this->order->get_total();
        $paid_amount = (float)$this->converge_response['ssl_amount'];
        $currency = $this->order->get_currency();
        $converge_token_response = $this->converge_token_response;

	    if ( $this->save_for_later_use ) {
		    if ( array_key_exists('ssl_token', $converge_token_response) ) {
			    $token                   = $converge_token_response['ssl_token'];
			    $card_type               = $converge_token_response['ssl_card_short_description'];
			    $card_expiry             = $converge_token_response['ssl_exp_date'];
			    $exp_month               = substr( $card_expiry, 0, 2 );
			    $exp_year                = substr( $card_expiry, - 2 );
			    $last4                   = substr( $converge_token_response['ssl_card_number'], - 4 );
			    $stored_card             = new WC_Payment_Token_Converge_Gateway_StoredCard();
			    $stored_card->create_or_update_stored_card_from_token( $token, $card_type, $last4, $exp_month, $exp_year );
		    } else {
			    wgc_get_gateway()->add_payment_method_checkout();
		    }
	    }

        // check if is partial payment
        if ($paid_amount != $order_total) {
            $paid_with_gift_card = WC()->session->get('paid_with_gift_amount') ? WC()->session->get('paid_with_gift_amount') : 0;
            if (!$order_total - $paid_with_gift_card === $paid_amount) {
                unset(WC()->session->paid_with_gift_amount);
                $this->handlePartialWrongAmount();
            }
            $partial_payment = true;
            $paid_amount = $order_total - $paid_with_gift_card;
        }

        // check if is gift card only payment
        $is_gift_card_only = false;
        if ( ( WC()->session->get( 'ssl_gift_card_number' ) && ! $partial_payment ) ||
             ( isset( $_REQUEST['converge-payment-option'] ) && $_REQUEST['converge-payment-option'] == 'converge-payment-option-gift-card' )
        ) {
            $is_gift_card_only = true;
        }

        if ( $is_gift_card_only ) {
            $this->converge_gift_card_response = $this->converge_response;
            $paid_with_gift_card               = $order_total;
            $payment_type = "Gift Card";
        } else {
            $payment_type = "Credit Card";
        }
        if ( isset( $this->converge_response['ssl_card_type'] ) && $this->converge_response['ssl_card_type'] == 'ELECTRONICCHECK' ) {
            $payment_type = "Electronic Check";
        }

        $paid_via_wallet = isset( $this->converge_response['paid_via_wallet'] );
        if ( $paid_via_wallet ) {
            $wallet_used = isset( $this->converge_response['wallet_used'] ) ? $this->converge_response['wallet_used'] : null;
            if ( $wallet_used == "masterpass" ) {
                $payment_type = "MasterPass";
            } elseif ( $wallet_used == "paypal" ) {
                $payment_type = "PayPal";
                $paid_amount  = $order_total;
            }
        }

        if ( ! WC()->session->get( 'ssl_gift_card_number' ) ) {
            if ( $this->converge_response['ssl_card_type'] == 'GIFTCARD' ) {
                WC()->session->set('ssl_gift_card_number', $this->converge_response['ssl_card_number'] );
            }
        }

        $this->order->set_transaction_id($this->converge_response['ssl_txn_id']);
        $this->order->payment_complete();

        // Add customer notes
        $transaction_type = $this->converge_response['ssl_transaction_type'];
        $transaction_id = $this->converge_response['ssl_txn_id'];

        $note = "Payment type: " . $payment_type . ". ";
        if ($transaction_type === 'AUTHONLY') {
            $note .= "Authorized: ";
        } else {
            $note .= "Captured: ";
        }
        $note .= $paid_amount . " " . $currency . ". Transaction ID: " . $transaction_id . ".";

        $this->order->add_order_note($note, true);

        $this->assign3dsStatus();

        $order_id = $this->order->get_id();

        // Payment with gift card complete or partial
        if (($partial_payment && $this->converge_gift_card_response) || $is_gift_card_only) {
            $gift_card_txn_id = wc_clean($this->converge_gift_card_response['ssl_txn_id']);
            update_post_meta($order_id, 'ssl_gift_txn_id', $gift_card_txn_id);
            update_post_meta($order_id, "ssl_gift_card_number", wc_clean(WC()->session->get('ssl_gift_card_number')));

            unset( WC()->session->ssl_gift_card_number );

            if ( WC()->session->get( 'paid_with_lightbox' ) ) {
                update_post_meta( $order_id, "paid_with_lightbox", wc_clean( WC()->session->get( 'paid_with_lightbox' ) ) );
                unset( WC()->session->paid_with_lightbox );
            }

	        update_post_meta($order_id, "ssl_gift_amount", $paid_with_gift_card);

            if (!$is_gift_card_only) {
                $note_gift = "Payment  type: Gift Card. Captured: " . $paid_with_gift_card . " " . $currency . ". Transaction ID: " . $gift_card_txn_id . ".";
                $this->order->add_order_note($note_gift, true);
            }

        }

        if (!$is_gift_card_only) {
            update_post_meta($order_id, 'ssl_txn_id', wc_clean($this->converge_response['ssl_txn_id']));
        }

        update_post_meta($order_id, "ssl_merchant_txn_id", WC()->session->get('ssl_merchant_txn_id'));

        $woocommerce->cart->empty_cart();

        // Redirect to the thank you page
        return array(
            'result' => 'success',
            'redirect' => $this->return_url
        );
    }

    /**
     * @throws Exception
     */
    private function handleDeclined()
    {
        $result_message = $this->converge_response;
        if (is_array($this->converge_response) && array_key_exists('ssl_result_message', $this->converge_response))
            $result_message = $this->converge_response['ssl_result_message'];

        $note = __("Invalid Transaction ! Converge error: ") . $result_message;
        $this->order->set_status('failed');
        $this->order->add_order_note($note);
        $this->assign3dsStatus();

        $this->order->set_status( 'failed' );
        if ( is_array( $this->converge_response ) && array_key_exists( 'ssl_txn_id', $this->converge_response ) ) {
            $this->order->set_transaction_id( $this->converge_response['ssl_txn_id'] );
        }
        $this->order->save();

        if ( $this->save_for_later_use && WC()->session->get( 'paid_with_lightbox' ) ) {
            $token = $this->converge_token_response['ssl_token'];
            wgc_get_gateway()->delete_stored_card( $token , "delete stored card ->  handleDeclined", $this->order);

            // clean session
            WC()->session->set( 'paid_with_lightbox', null );
            unset(WC()->session->paid_with_lightbox);
        }

        $message = 'Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again';
        return $this->errorProcessingPayment($message);
    }

    /**
     * @throws Exception
     */
    public function handleError()
    {
	    if ( $this->save_for_later_use && WC()->session->get('paid_with_lightbox') ) {
		    $token = $this->converge_token_response['ssl_token'];
		    wgc_get_gateway()->delete_stored_card($token, "delete stored card ->  handleError");

		    // clean session
            WC()->session->set( 'paid_with_lightbox', null);
            unset(WC()->session->paid_with_lightbox);
	    }

        $message = 'Your order could not be placed. Please try again later.';
        return $this->errorProcessingPayment($message);
    }


    private function handlePartialWrongAmount()
    {
        $note = __("Wrong amount in partial payment . Please, try again ! ") . $this->converge_response['ssl_txn_id'];
        $this->order->set_status('failed');
        $this->order->add_order_note($note);
        $this->order->save();

        $message = 'Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again';
        return $this->errorProcessingPayment($message);
    }

    protected function errorProcessingPayment( $message ) {
        $order_from_merchant_view = isset($_GET['pay_for_order']) && isset($_GET['key']);
        if ( $order_from_merchant_view ) {
            wc_print_notice( $message, 'error' );
        } else {
            wc_add_notice( __( $message, 'elavon-converge-gateway' ), 'error' );
        }

        return array( 'result' => 'failure' );
    }

    public function logResponse($response)
    {
        $this->logger->log($response);
    }
    public function logWithContext($response)
    {
        $this->logger->logWithContext($response, $this->context);
    }

    private function assign3dsStatus()
    {
        if ( $this->save_for_later_use && ! wgc_get_gateway()->isCheckoutJS() ) {
            $converge_response = $this->converge_token_response;
        } else {
            $converge_response = $this->converge_response;
        }
        
        if ( ( ! wgc_get_gateway()->has3DS1Enabled() && ! wgc_get_gateway()->has3DS2Enabled() ) ||
             ( array_key_exists( 'ssl_card_type', $converge_response )
               && $converge_response['ssl_card_type'] != 'CREDITCARD' )
        ) {
            return;
        }

        $ssl_eci_ind = 'Not Authenticated';

        if (array_key_exists('ssl_eci_ind', $converge_response)) {

            if ($converge_response['ssl_eci_ind'] == 3)
                $ssl_eci_ind = "Card Authentication Failed";
            else
                $ssl_eci_ind = $converge_response['ssl_eci_ind'];
        }
        $this->order->add_order_note(sprintf("3DS Authentication Status: %s", $ssl_eci_ind));
    }

}