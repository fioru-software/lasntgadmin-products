<?php
/**
 * Class WC_Gateway_Converge_Response_Handler file.
 *
 * @package WooCommerce\Gateways
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elavon\Converge\Api\Transaction\CreditCard\TransferObject\CompletionTransferObject;
use Elavon\Converge\Api\Transaction\EndOfDay\TransferObject\SettleTransferObject;
use Elavon\Converge\Api\Transaction\CreditCard\TransferObject\VoidTransferObject as CreditCardVoidTransferObject;
use Elavon\Converge\Api\Transaction\GiftCard\TransferObject\RefundTransferObject;
use Elavon\Converge\Api\Transaction\ACH\TransferObject\VoidTransferObject as ACHVoidTransferObject;
use Elavon\Converge\Api\Transaction\CreditCard\TransferObject\ReturnTransferObject;
use Elavon\Converge\Constant\Field;

/**
 * Handles Responses.
 */
class WC_Gateway_Converge_Api {

	/**
	 * Pointer to gateway making the request.
	 *
	 * @var WC_Converge_Gateway
	 */
	protected $gateway;

	/**
	 * Constructor.
	 *
	 * @param WC_Converge_Gateway $gateway
	 */
	public function __construct( WC_Converge_Gateway $gateway ) {
		$this->gateway = $gateway;
	}

	public function is_partial_payment_order ($order){

	    $is_partial_payment = false;

	    $txn_id_gift = $order->get_meta('ssl_gift_txn_id');

        if ($txn_id_gift !== '') {
            $is_partial_payment = true;
        }

        return $is_partial_payment;

    }

	public function is_paid_with_lightbox ($order){
		return $order->get_meta('paid_with_lightbox') !== '';
	}

    public function is_paid_only_with_gift ($order){

        $is_payed_only_with_gift = false;

        $txn_id = $order->get_meta('ssl_txn_id');
        $txn_id_gift = $order->get_meta('ssl_gift_txn_id');

        if ($txn_id == '' && $txn_id_gift !== '') {
            $is_payed_only_with_gift = true;
        }

        return $is_payed_only_with_gift;

    }

	public function void_transaction( WC_Order $order ) {

        $gift_voided = false;
        $is_partial_payment = $this->is_partial_payment_order($order);
        $is_payed_only_with_gift = $this->is_paid_only_with_gift($order);

	    $transaction = $this->gateway->getApiGateway()->getTransaction();
	    $transaction_state = wgc_get_order_transaction_state( $order );

	    if($transaction_state->getResponse()->isSuccess() === false ){

	        $order->add_order_note(wgc_get_order_error_note(__('There was an error processing the void.',
                'elavon-converge-gateway'),
                $transaction_state->getResponse()));

	        return;
	    }


        if ($transaction_state->isACHTransaction()) {
            $type = $transaction->getACHType();
            $voidTransferObject = new ACHVoidTransferObject([
                Field::SSL_TXN_ID => $order->get_meta(Field::SSL_TXN_ID)
            ]);
        } else {

            if ($transaction_state->isCreditCardTransaction()) {

                if ($is_partial_payment === true) {

                    $type = $transaction->getGiftCardType();

                    $voidGiftTransferObject = new RefundTransferObject([
                        'ssl_card_number' => $order->get_meta('ssl_gift_card_number'),
                        'ssl_exp_date' => '1249',
                        'ssl_amount' => (float)$order->get_meta('ssl_gift_amount'),
                        'ssl_vm_mobile_source' => 'NOMOB'
                    ]);

                    $giftVoidResponse = $type->refundCard($voidGiftTransferObject);

                    if ($giftVoidResponse->getResponse()->isSuccess()) {

                        $gift_total = wc_price($order->get_meta('ssl_gift_amount'));

                        $order->add_order_note(sprintf(__('Voided %1$s Transaction id: %2$s',
                            'elavon-converge-gateway'),
                            $gift_total,
                            $order->get_meta('ssl_gift_txn_id')));

                        $res = $giftVoidResponse->getResponse()->getData();
                        update_post_meta($order->get_id(), 'ssl_gift_txn_id', wc_clean($res['ssl_txn_id']));
                        $gift_voided = true;

                    } else {

                        $order->add_order_note(wgc_get_order_error_note(__('There was an error processing the void.',
                            'elavon-converge-gateway'),
                            $giftVoidResponse->getResponse()));

                    }

                }

            }
        }

        if (($gift_voided === true && $is_payed_only_with_gift === false)|| $is_partial_payment === false) {
            $type = $transaction->getCreditCardType();
            $voidRequest = array(
                Field::SSL_TXN_ID => $order->get_meta(Field::SSL_TXN_ID)
            );
            $voidTransferObject = new CreditCardVoidTransferObject($voidRequest);

            wgc_log_converge_request($voidRequest, "cc void",  $order);
        }

        if ($voidTransferObject) {
            $response = $type->void($voidTransferObject);

            wgc_log_converge_response($response->getResponse(), "cc void",  $order);

            if ($response->getResponse()->isSuccess()) {

                $response = $response->getResponse()->getData();
                $total = $order->get_total();

                if($is_partial_payment === true){
                    $gift_amount = (float)$order->get_meta('ssl_gift_amount');
                    $total = $total - $gift_amount;
                    $total = (float) $total;
                }

                $order->add_order_note(sprintf(__('Voided %1$s Transaction id: %2$s', 'elavon-converge-gateway'),
                    wc_price($total),
                    $order->get_transaction_id()));

                $order->set_transaction_id($response['ssl_txn_id']);
                update_post_meta($order->get_id(), 'ssl_txn_id', wc_clean($response['ssl_txn_id']));
                $this->payment_cancelled($order);
            } else {

                $order->add_order_note(wgc_get_order_error_note(__('There was an error processing the void.',
                    'elavon-converge-gateway'),
                    $response->getResponse()));
            }
        }
	}

    public function refund_transaction( WC_Order $order, $amount ) {

        $transaction_state = wgc_get_order_transaction_state( $order );

	    $gift_refunded = false;
        $is_partial_payment = $this->is_partial_payment_order($order);
        $is_paid_only_with_gift = $this->is_paid_only_with_gift( $order );

	    if ( $is_paid_only_with_gift && $this->is_paid_with_lightbox( $order ) ) {
		    return new WP_Error ( 'refund-error',
			    /* translators: %s: transaction status */
			    sprintf( __( 'Cannot refund a gift card transaction.', 'elavon-converge-gateway' ) ) );
	    }

        if(!$transaction_state) {
            $order->add_order_note( sprintf( __( 'There was an error processing the refund.', 'elavon-converge-gateway' )));
            return new WP_Error ( 'refund-error',
                /* translators: %s: transaction status */
                sprintf( __( 'There was an error processing the refund.', 'elavon-converge-gateway' )));
        }

        if ($transaction_state->isACHTransaction() ) {
            return new WP_Error ( 'refund-error',
                /* translators: %s: transaction status */
                sprintf( __( 'Cannot refund an ACH transaction.', 'elavon-converge-gateway' )));
        }

        if (!$transaction_state->isRefundable()) {
            $order->add_order_note( sprintf( __( 'There was an error processing the refund. Error: Cannot refund a transaction that has the %s status.', 'elavon-converge-gateway' ), $transaction_state->getValue()));
            return new WP_Error ( 'refund-error',
                /* translators: %s: transaction status */
                sprintf( __( 'There was an error processing the refund. Error: Cannot refund a transaction that has the %s status.',
                    'elavon-converge-gateway' ), $transaction_state->getValue() ) );
        }

	    if ( $is_partial_payment === true ) {

		    $total = $order->get_total();
		    if ( $total !== $amount && ! $is_paid_only_with_gift ) {
			    return new WP_Error ( 'refund-error',
				    /* translators: %s: transaction status */
				    sprintf( __( 'Invalid refund amount. Please enter the total available to refund.', 'elavon-converge-gateway' ) ) );
		    }

            $transaction = $this->gateway->getApiGateway()->getTransaction();
            $type = $transaction->getGiftCardType();

		    if ( $is_paid_only_with_gift ) {
			    $amount_to_refund = $amount;
		    } else {
			    $amount_to_refund = $order->get_meta( 'ssl_gift_amount' );
		    }

            $requestRefundGiftTransfer = array(
                'ssl_card_number'      => $order->get_meta( 'ssl_gift_card_number' ),
                'ssl_exp_date'         => '1249',
                'ssl_amount'           => (float) $amount_to_refund,
                'ssl_vm_mobile_source' => 'NOMOB',
            );
		    $refundGiftTransferObject = new RefundTransferObject($requestRefundGiftTransfer);
            $giftRefundResponse = $type->refundCard($refundGiftTransferObject);

            wgc_log_converge_request($requestRefundGiftTransfer, "gc refund",  $order);
            wgc_log_converge_response($giftRefundResponse->getResponse(), "gc refund",  $order);

            if ($giftRefundResponse->getResponse()->isSuccess() && $giftRefundResponse->get('ssl_result') == 0) {

                $order->add_order_note(sprintf(__('Order was successfully refunded in the amount of %1$s.',
                    'elavon-converge-gateway'), wc_price($amount_to_refund)));

                $res = $giftRefundResponse->getResponse()->getData();
	            if ( ! $is_paid_only_with_gift ) {
		            update_post_meta( $order->get_id(), 'ssl_gift_txn_id', wc_clean( $res['ssl_txn_id'] ) );
	            }
	            $gift_refunded = true;

            } else {

                $order->add_order_note( sprintf( __( 'There was an error processing the refund.', 'elavon-converge-gateway' )));
                return new WP_Error ( 'refund-error',
                    /* translators: %s: transaction status */
                    sprintf( __( 'There was an error processing the refund.', 'elavon-converge-gateway' )));
            }

        }

	    $txn_id = $order->get_meta( Field::SSL_TXN_ID );
	    if ( empty( $txn_id ) && $gift_refunded === true && $is_partial_payment === true ) {
		    return true;
	    }

        if($is_partial_payment === false || ($gift_refunded === true && $is_partial_payment === true)) {

            if($is_partial_payment === true){
                $gift_amount = (float)$order->get_meta('ssl_gift_amount');
                $amount = $amount - $gift_amount;
                $amount = (float) $amount;
            }

            $transaction = $this->gateway->getApiGateway()->getTransaction();
	        $creditCardType = $transaction_state->get('ssl_card_type');
	        $returnParams = array(
	            'txn_id' => $txn_id,
                'amount' => $amount
            );

	        if ($creditCardType === 'PAYPAL') {
		        $type = $transaction->getPayPalType();
		        $response = $type->peReturn($returnParams['txn_id'], $returnParams['amount']);
		        $context = "paypal refund";
	        } else {
		        $type = $transaction->getCreditCardType();
		        $response = $type->ccReturn($returnParams['txn_id'], $returnParams['amount'] );
                $context = "cc refund";
	        }

            wgc_log_converge_request($returnParams, $context,  $order);
            wgc_log_converge_response($response->getResponse(), $context,  $order);

	        if ($response->getResponse()->isSuccess()) {
                $amount = (float)$amount;

                $order->add_order_note(sprintf(__('Order was successfully refunded in the amount of %1$s.',
                    'elavon-converge-gateway'), wc_price($amount)));

                return true;
            } else {

                $order->add_order_note(wgc_get_order_error_note(__('There was an error processing the refund.',
                    'elavon-converge-gateway'),
                    $response->getResponse()));

                return new WP_Error ('refund-error',
                    /* translators: %s: error message */
                    sprintf(__('There was an error processing the refund. %s.',
                        'elavon-converge-gateway'), $response->getResponse()->getExceptionMessage()));
            }
        }
    }

	public function capture_transaction( WC_Order $order ) {

		$transaction_state = wgc_get_order_transaction_state( $order );

		if(!$transaction_state->getResponse()->isSuccess()) {
            $order->add_order_note(
                wgc_get_order_error_note(__('There was an error processing the capture.', 'elavon-converge-gateway'),
                    $transaction_state->getResponse()));
            return;
        }

		if ( ! $transaction_state || ! $transaction_state->isCapturable() ) {
            $order->add_order_note( sprintf( __( 'There was an error processing the capture. Converge error: Cannot capture a transaction that has the %s status.', 'elavon-converge-gateway' ), $transaction_state->getValue()));
			return;
		}

		$transaction_id = $order->get_meta(Field::SSL_TXN_ID);

        $transaction = $this->gateway->getApiGateway()->getTransaction();
        $type = $transaction->getCreditCardType();
        $requestCompletion = array(
            Field::SSL_TXN_ID => $transaction_id,
            Field::SSL_AMOUNT => (float)$order->get_total()
        );
        $completionTransferObject = new CompletionTransferObject($requestCompletion);
		$response = $type->completion( $completionTransferObject );

        wgc_log_converge_request($requestCompletion, "capture",  $order);
        wgc_log_converge_response($response->getResponse(), "capture",  $order);

		if ( $response->getResponse()->isSuccess() ) {
		    $response = $response->getResponse()->getData();
            $total = wc_price($order->get_total());
			/* translators: %1$s: amount, %2$s: transaction id */
			$order->add_order_note( sprintf( __( 'Captured %1$s Transaction id: %2$s', 'elavon-converge-gateway' ), $total,
				$transaction_id ) );

		} else {

			$order->add_order_note( wgc_get_order_error_note( __( 'There was an error processing the capture.',
				'elavon-converge-gateway' ),
                $response->getResponse() ) );
		}
	}

    public function settle_transaction( WC_Order $order ) {

	    $transaction_id = $order->get_meta(Field::SSL_TXN_ID);

        $transaction = $this->gateway->getApiGateway()->getTransaction();
        $type = $transaction->getEndOfDayType();
        $response = $type->settle( $transaction_id );

        wgc_log_converge_request(array('ssl_txn_id' => $transaction_id), "settle",  $order);
        wgc_log_converge_response($response->getResponse(), "settle",  $order);

        if ( $response->getResponse()->isSuccess() ) {
            $response = $response->getResponse()->getData();
            $total = wc_price($order->get_total());
            /* translators: %1$s: amount, %2$s: transaction id */
            $order->add_order_note( sprintf( __( 'Settled %1$s. Transaction id: %2$s', 'elavon-converge-gateway' ), $total,
                $transaction_id ) );

        } else {

            $order->add_order_note( wgc_get_order_error_note( __( 'There was an error processing the settle.',
                'elavon-converge-gateway' ),
                $response->getResponse() ) );
        }
    }

	public function get_order_transaction( WC_Order $order, $force_call = false ) {
		static $cache = [];

		$order_id = $order->get_id();

		if (!$force_call && isset( $cache[$order_id] ) && $cache[$order_id]->getResponse()->isSuccess()) {
			return $cache[$order_id];
		}

		$transaction = $this->gateway->getApiGateway()->getTransaction();
        $type = $transaction->getEndOfDayType();

        $is_payed_only_with_gift = $this->is_paid_only_with_gift($order);
        if($is_payed_only_with_gift === true){
            $txnQueryAO = $type->txnQuery($order->get_meta('ssl_gift_txn_id'));
        } else{
            $txnQueryAO = $type->txnQuery($order->get_meta(Field::SSL_TXN_ID));
        }

        $cache[$order_id] = $txnQueryAO;

		return $txnQueryAO;
	}

	/**
	 * Complete order, add transaction ID and note.
	 *
	 * @param WC_Order $order Order object.
	 * @param string $transaction_id Transaction ID.
	 */
	protected function payment_complete( $order, $transaction_id = '' ) {
		$order->payment_complete( $transaction_id );
		WC()->cart->empty_cart();
	}

	/**
	 * Hold order and add note.
	 *
	 * @param WC_Order $order Order object.
	 */
	protected function payment_on_hold( $order ) {
		$order->update_status( 'on-hold' );
		WC()->cart->empty_cart();
	}

	/**
	 * Mark order as voided.
	 *
	 * @param WC_Order $order Order object.
	 */
	protected function payment_voided( $order ) {
		$order->update_status( 'voided' );
	}

    /**
     * Mark order as voided.
     *
     * @param WC_Order $order Order object.
     */
    protected function payment_refunded( $order ) {
        $order->update_status( 'refunded' );
    }

	/**
	 * Mark order as failed.
	 *
	 * @param WC_Order $order Order object.
	 */
	protected function payment_failed( $order ) {
		$order->update_status( 'failed' );
	}

	/**
	 * Mark order as cancelled.
	 *
	 * @param WC_Order $order Order object.
	 */
	protected function payment_cancelled( $order ) {
		$order->update_status( 'cancelled' );
	}

}
