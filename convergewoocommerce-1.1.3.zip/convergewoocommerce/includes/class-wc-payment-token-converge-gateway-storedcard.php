<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit (); // Exit if accessed directly.
}

use Elavon\Converge\Api\Transaction\CreditCard\TransferObject\TokenSaleTransferObject;
use Elavon\Converge\Api\Transaction\CreditCard\TransferObject\TokenAuthOnlyTransferObject;
use Elavon\Converge\Api\Transaction\CreditCard\TransferObject\GetTokenTransferObject;
use Elavon\Converge\Api\Transaction\CreditCard\TransferObject\VerifyTransferObject;

class WC_Payment_Token_Converge_Gateway_StoredCard extends WC_Payment_Token {
    /**
     * @var string
     */
    protected $type = WGC_PAYMENT_TOKEN_TYPE;

    /**
     * @var array
     */
    protected $extra_data = array(
        'last4'        => '',
        'expiry_year'  => '',
        'expiry_month' => '',
        'card_scheme'  => '',
    );

    /**
     * @return DateTime
     */
    public function get_expiry_date() {
        $expiry_date = new DateTime( $this->get_expiry_year() . '-' . $this->get_expiry_month() );
        $expiry_date->modify('first day of next month');
        $expiry_date->modify('-1 second');
        return $expiry_date;
    }

    /**
     * @return bool
     */
    public function is_expired() {
        $now = new DateTime( 'now', new \DateTimeZone( 'UTC' ));
        $expiry_date = $this->get_expiry_date() ;

        if ( $now  > $expiry_date ) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * @param string $deprecated
     * @return string
     */
    public function get_display_name( $deprecated = '' ) {

        if ( $this->is_expired() ) {
            /* translators: %1$s: credit card brand, %2$s: last 4 digits, %3$s: expiry month 4: expiry year */
            $display_name_format = __( '%1$s ending in %2$s <span class="red">(expired %3$s/%4$s)</span>', 'elavon-converge-gateway' );
        } else {
            /* translators: %1$s: credit card brand, %2$s: last 4 digits, %3$s: expiry month 4: expiry year */
            $display_name_format = __( '%1$s ending in %2$s (expires %3$s/%4$s)', 'elavon-converge-gateway' );
        }

        return sprintf(
            $display_name_format,
            $this->get_card_scheme(),
            $this->get_last4(),
            $this->get_expiry_month(),
            substr( $this->get_expiry_year(), 2 )
        );
    }

    /**
     * @return string
     */
    protected function get_hook_prefix() {
        return 'woocommerce_payment_token_cc_get_';
    }

    /**
     * @return bool
     */
    public function validate() {
        if ( false === parent::validate() ) {
            return false;
        }

        if ( ! $this->get_last4( 'edit' ) ) {
            return false;
        }

        if ( ! $this->get_expiry_year( 'edit' ) ) {
            return false;
        }

        if ( ! $this->get_expiry_month( 'edit' ) ) {
            return false;
        }

        if ( ! $this->get_card_scheme( 'edit' ) ) {
            return false;
        }

        if ( 4 !== strlen( $this->get_expiry_year( 'edit' ) ) ) {
            return false;
        }

        if ( 2 !== strlen( $this->get_expiry_month( 'edit' ) ) ) {
            return false;
        }

        return true;
    }

    /**
     * @param string $context
     * @return mixed
     */
    public function get_card_scheme( $context = 'view' ) {
        return $this->get_prop( 'card_scheme', $context );
    }

    /**
     * @param $brand
     */
    public function set_card_scheme( $brand ) {
        $this->set_prop( 'card_scheme', $brand );
    }

    /**
     * @param string $context
     * @return mixed
     */
    public function get_expiry_year( $context = 'view' ) {
        return $this->get_prop( 'expiry_year', $context );
    }

    /**
     * @param $year
     */
    public function set_expiry_year( $year ) {
        $this->set_prop( 'expiry_year', $year );
    }

    /**
     * @param string $context
     * @return mixed
     */
    public function get_expiry_month( $context = 'view' ) {
        return $this->get_prop( 'expiry_month', $context );
    }

    /**
     * @param $month
     */
    public function set_expiry_month( $month ) {
        $this->set_prop( 'expiry_month', str_pad( $month, 2, '0', STR_PAD_LEFT ) );
    }

    /**
     * @param string $context
     * @return mixed
     */
    public function get_last4( $context = 'view' ) {
        return $this->get_prop( 'last4', $context );
    }

    /**
     * @param $last4
     */
    public function set_last4( $last4 ) {
        $this->set_prop( 'last4', $last4 );
    }

    /**
     * Returns the card type (mastercard, visa, ...).
     *
     * @since  2.6.0
     * @param  string $context What the value is for. Valid values are view and edit.
     * @return string Card type
     */
    public function get_card_type( $context = 'view' ) {
        return $this->get_prop( 'card_type', $context );
    }

    /**
     * Set the card type (mastercard, visa, ...).
     *
     * @since 2.6.0
     * @param string $type Credit card type (mastercard, visa, ...).
     */
    public function set_card_type( $type ) {
        $this->set_prop( 'card_type', $type );
    }

    /**
     * @param string $context
     * @return mixed|string
     */
    public function get_token( $context = 'view' ) {
        return $this->get_prop( 'token', $context );
    }


    /**
     * @param bool $force_delete
     * @return bool
     */
    public function delete( $force_delete = false ) {
        $stored_card         = $this->get_token( wgc_get_payment_name() );
        $deleted_on_converge = wgc_get_gateway()->delete_stored_card( $stored_card, $context = "delete stored card -> my account" );

        if ( $deleted_on_converge ) {
            $parent_result = parent::delete( $force_delete );
            if ( $this->get_is_default() ) {
                $tokens = WC_Payment_Tokens::get_customer_tokens( get_current_user_id(), $this->get_gateway_id() );
                $token  = reset( $tokens );
                if ( $token ) {
                    $token->set_default( true );
                    $token->save();
                }
            }
            return $parent_result;
        } else {
            wc_add_notice(
                __( 'Payment method cannot be deleted. Please contact the merchant.', 'elavon-converge-gateway' ),
                'error'
            );
            wp_redirect( wc_get_account_endpoint_url( 'payment-methods' ) );
            exit();
        }
    }

	public function pay_with_token($token, $context,  WC_Order $order){

		$gateway = wgc_get_gateway();
		$api_gateway = $gateway->getApiGateway();
		$payment_action = $gateway->get_option(WGC_KEY_PAYMENT_ACTION) === 'auth_only' ? "ccauthonly" : "ccsale";
        $amount = $order->get_total();


		if ($payment_action === 'ccsale') {

		    $request_data = array(
                "ssl_transaction_type" => $payment_action,
                "ssl_amount" => floatval($amount),
                "ssl_token" => $token,
                'ssl_vm_mobile_source' => 'NOMOB'
            );
			$sale = new TokenSaleTransferObject($request_data);

			$transaction = $api_gateway->getTransaction();
			$type = $transaction->getCreditCardType();
			$response = $type->tokenSale($sale);

		} else {

            $request_data = array(
                "ssl_transaction_type" => $payment_action,
                "ssl_amount" => floatval($amount),
                "ssl_token" => $token,
                'ssl_vm_mobile_source' => 'NOMOB'
            );
			$sale = new TokenAuthOnlyTransferObject($request_data);

			$transaction = $api_gateway->getTransaction();
			$type = $transaction->getCreditCardType();
			$response = $type->tokenAuthOnly($sale);
		}


        wgc_log_converge_request($request_data, $context,  $order);
        wgc_log_converge_response($response->getResponse(), $context,  $order);

        $converge_response = $response->getResponse()->getData();

		return $converge_response;
	}

	/**
	 * @return mixed
	 */
	public function pay_with_stored_card( WC_Order $order, $context ) {

		$token_id  = $_POST['wc-elavon-converge-gateway-payment-token'];
		$token     = WC_Payment_Tokens::get( $token_id );
		$token_key = $token->get_token();

        return $this->pay_with_token( $token_key,
            "pay with token -> " . $context,
            $order );
	}

	public function create_or_update_stored_card_from_token( $token_number, $card_type, $last4, $exp_month, $exp_year ) {
		$gateway = wgc_get_gateway();

		$token = new WC_Payment_Token_Converge_Gateway_StoredCard();
		$token->set_gateway_id( $gateway->get_gateway_id() );
		$token->set_token( $token_number );
		$token->set_card_type( $card_type );
		$token->set_last4( $last4 );
		$token->set_expiry_month( $exp_month );
		$token->set_expiry_year( substr( date( 'Y' ), 0, 2 ) . $exp_year );
		$token->set_user_id( get_current_user_id() );
		$token->set_card_scheme( $card_type );

		$all_tokens = WC_Payment_Tokens::get_customer_tokens( get_current_user_id(),
			$this->get_gateway_id() );

		$token_exist    = false;
		$token_exist_id = null;

		foreach ( $all_tokens as $old_token ) {
			$token_code = $old_token->get_token();
			if ( $token_code == $token_number ) {
				$token_exist    = true;
				$token_exist_id = $old_token->get_id();
				break;
			}
		}

		if ( $token_exist == true ) {
			$token->set_id( $token_exist_id );
			if ( $token->save() ) {
				$response ['success'] = true;
				$response ['message'] = __( 'Payment method successfully updated.' );
			} else {
				$response ['success'] = false;
				$response ['message'] = __( 'Something went wrong.' );
			}
		} else {
			if ( $token->save() ) {
				$response ['success'] = true;
				$response ['message'] = __( 'Payment method successfully added.' );
			} else {
				$response ['success'] = false;
				$response ['message'] = __( 'Something went wrong.' );
			}
		}

		return $response;
	}


	public function store_card ($card_number, $exp_month, $exp_year, $card_verification_number, $address, $zip_code, $first_name, $last_name)
    {
        $response = array();
        $gateway = wgc_get_gateway();
        $api_gateway = $gateway->getApiGateway();

        $transaction = $api_gateway->getTransaction();
        $type = $transaction->getCreditCardType();

        $verifyRequest = array(
            'ssl_card_number' => $card_number,
            'ssl_exp_date' => $exp_month . $exp_year,
            'ssl_cvv2cvc2' => $card_verification_number,
            'ssl_avs_address' => $address,
            'ssl_avs_zip' => $zip_code,
            'ssl_vm_mobile_source' => 'NOMOB',
        );
        $getVerify = new VerifyTransferObject($verifyRequest);

        $transactionVerify = $api_gateway->getTransaction();
        $typeVerify = $transactionVerify->getCreditCardType()->verify($getVerify);
        $isValid = $typeVerify->isValid();

        wgc_log_converge_request($verifyRequest, "store card -> verify card");
        wgc_log_converge_response($typeVerify->getResponse(), "store card -> verify card");

        if ($isValid === true) {

            $tokenRequest = array(
                'ssl_card_number' => $card_number,
                'ssl_exp_date' => $exp_month . $exp_year,
                'ssl_cvv2cvc2' => $card_verification_number,
                'ssl_avs_address' => $address,
                'ssl_avs_zip' => $zip_code,
                'ssl_verify' => 'Y',
                'ssl_add_token' => 'Y',
                'ssl_cvv2cvc2_indicator' => 1,
                "ssl_first_name" => $first_name,
                "ssl_last_name" => $last_name
            );
            $getToken = new GetTokenTransferObject($tokenRequest);

            $access_object = $type->getToken($getToken);

            wgc_log_converge_request($tokenRequest, "store card -> get token");
            wgc_log_converge_response($access_object->getResponse(), "store card -> get token");

            if ($access_object->isValid()) {

                $response_data = $access_object->getResponse()->getData();

	            $token_number = $response_data['ssl_token'];
                $card_type = $response_data['ssl_card_short_description'];
                $last4 = substr($card_number, -4);

	            $response = $this->create_or_update_stored_card_from_token( $token_number, $card_type, $last4,  $exp_month, $exp_year );

            } else {
                $response ['success'] = false;
                $response ['message'] = __('Something went wrong.');

            }
        } else {
	        $response ['success'] = false;
	        $response ['message'] = __( 'Something went wrong.' );
        }

        return $response;
    }

}
