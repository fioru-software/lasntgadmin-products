<?php

/**
 * Functions used by plugins
 */
if (!class_exists('WC_Converge_Gateway_Dependencies')) {
    require_once 'class-wc-converge-gateway-dependencies.php';
}

/**
 * Helper function to get payment name.
 */

if (!function_exists('wgc_get_payment_name')) {
    function wgc_get_payment_name()
    {
        return WGC_PAYMENT_NAME;
    }
}


if (!function_exists('wgc_get_order_transaction_state')) {
    /**
     * Helper function to get a Converge TransactionState object from an order.
     *
     * @param WC_Order $order
     *
     * @return TransactionState|null
     */
    function wgc_get_order_transaction_state(WC_Order $order)
    {
        return wgc_get_gateway()->getConvergeOrderWrapper()->get_sale_transaction_state($order);
    }
}

/**
 * Helper function to get the Converge gateway.
 */
if (!function_exists('wgc_get_gateway')) {
    function wgc_get_gateway()
    {
        /** @var WC_Converge_Gateway $gateway */
        static $gateway;

        if (!isset($gateway)) {
            $payment_gateways = wc()->payment_gateways()->payment_gateways();
            $id = wgc_get_payment_name();
            if (isset($payment_gateways[$id])) {
                $gateway = $payment_gateways[$id];
            }
        }
        return $gateway;
    }
}

if (!function_exists('wgc_get_order_transaction_state')) {
    /**
     * Helper function to get a Converge TransactionState object from an order.
     *
     * @param WC_Order $order
     *
     * @return \Elavon\Converge\Api\Transaction\EndOfDay\AccessObject\EodAccessObject|null
     */
    function wgc_get_order_transaction_state(WC_Order $order)
    {
        return wgc_get_gateway()->getConvergeOrderWrapper()->get_sale_transaction_state($order);
    }
}

if (!function_exists('wgc_log_data')) {
    function wgc_log_data( array $data, $context = null,  WC_Order $order = null)
    {
        $data = wgc_data_masking($data);
        $log_prefix = " Data: ";

        if ($context)
            $log_prefix = sprintf("[context: %s]", $context) . $log_prefix;

        if ($order)
            $log_prefix = sprintf("[order-id %s]", $order->get_id()) . $log_prefix;

        $message = $log_prefix . (!empty($data) ? print_r($data, true) : '{}');
        wgc_log($message);
    }
}

if (!function_exists('wgc_log_converge_request')) {
    function wgc_log_converge_request( array $data, $context = null,  WC_Order $order = null)
    {
        $data = wgc_data_masking($data);
        $log_prefix = " Request data to Converge: ";

        if ($context)
            $log_prefix = sprintf("[context: %s]", $context) . $log_prefix;

        if ($order)
            $log_prefix = sprintf("[order-id %s]", $order->get_id()) . $log_prefix;

        $message = $log_prefix . (!empty($data) ? print_r($data, true) : '{}');
        wgc_log($message);
    }
}

if (!function_exists('wgc_log_converge_response')) {
    function wgc_log_converge_response(
        \Elavon\Converge\Response\Response $response,
        $context,
        WC_Order $order = null
    ) {
        $log_prefix = sprintf("[context: %s]", $context);
        if ($order) {
            $log_prefix = sprintf("[order-id %s]", $order->get_id()) . $log_prefix;
        }

        $log_prefix .= sprintf("[status: %s]", $response->getRawResponseStatusCode());

        if ($response->isSuccess()) {
            wgc_log(sprintf(__('%s Received data from Converge: %s'),
                $log_prefix, $response->getRawResponseBody()));
        } else {
            if ($response->hasRawResponse()) {
                wgc_log(sprintf(__('%s Raw response from Converge: %s'),
                    $log_prefix, $response->getRawResponseBody()), WC_Log_Levels::ERROR);
            } else {
                wgc_log(sprintf(__('%s Converge was not reached. Error: %s'),
                    $log_prefix, $response->getExceptionMessage()), WC_Log_Levels::ERROR);
            }
        }
    }
}

/**
 * Helper function to get and format order error note.
 */
if (!function_exists('wgc_get_order_error_note')) {
    function wgc_get_order_error_note($message, \Elavon\Converge\Response\Response $response)
    {
        /* translators: %1$s: already translated text, %2$s: non-translatable error message. */
        return sprintf(__('%1$s Converge error: %2$s', 'elavon-converge-gateway'), $message,
            $response->getExceptionMessage());
    }
}

/**
 * Helper function to log messages.
 */
if (!function_exists('wgc_log')) {
    function wgc_log($message, $level = WC_Log_Levels::DEBUG)
    {
        static $log_enabled;

        if (!isset($log_enabled)) {
            $log_enabled = 'yes' === wgc_get_option('debug', 'no');
        }

        if (!$log_enabled) {
            return;
        }

        $logger = wc_get_logger();
        $logger->log($level, $message, array('source' => wgc_get_payment_name()));
    }
}


/**
 * Helper function to get plugin settings option.
 */
if (!function_exists('wgc_get_option')) {
    function wgc_get_option($key, $empty_value = null)
    {
        $gateway = wgc_get_gateway();

        if ($gateway) {
            return $gateway->get_option($key, $empty_value);
        }

        return $empty_value;
    }
}


if (!function_exists('wc_get_merchant_txn_id')) {
    function wc_get_merchant_txn_id()
    {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            // 32 bits for "time_low"
            random_int(0, 0xffff), random_int(0, 0xffff),

            // 16 bits for "time_mid"
            random_int(0, 0xffff),

            // 16 bits for "time_hi_and_version",
            // four most significant bits holds version number 4
            random_int(0, 0x0fff) | 0x4000,

            // 16 bits, 8 bits for "clk_seq_hi_res",
            // 8 bits for "clk_seq_low",
            // two most significant bits holds zero and one for variant DCE1.1
            random_int(0, 0x3fff) | 0x8000,

            // 48 bits for "node"
            random_int(0, 0xffff), random_int(0, 0xffff), random_int(0, 0xffff)
        );
    }
}

/**
 *  Get plugin settings option.
 */
if (!function_exists('wgc_get_option')) {
    function wgc_get_option($key, $empty_value = null)
    {

        $gateway = wgc_get_gateway();

        if ($gateway) {
            return $gateway->get_option($key, $empty_value);
        }

        return $empty_value;
    }
}

/**
 *  Check if order is converge order.
 */
if (!function_exists('wgc_is_converge_order')) {
    /**
     * @param WC_Order $order
     * @return bool
     */
    function wgc_is_converge_order($order)
    {
        if (
            !$order instanceof WC_Order ||
            in_array($order->get_status(), ['failed']) ||
            $order->get_payment_method() != wgc_get_payment_name()
        ) {
            return false;
        }

        $txn_id = $order->get_meta("ssl_txn_id");
        $txn_id_gift = $order->get_meta('ssl_gift_txn_id');

        if ($txn_id == '' && $txn_id_gift !== '') {
            $txn_id = $txn_id_gift;
        }

        if (empty($txn_id)) {
            return false;
        }

        return true;
    }
}

if (!function_exists('wgc_get_template')) {
    function wgc_get_template($template, $buffering = true)
    {
        /** @noinspection PhpUnusedLocalVariableInspection */
        $gateway = wgc_get_gateway();

        if (!$buffering) {
            include(__DIR__ . '/views/' . $template . '.php');
            return;
        }

        ob_start();
        /** @noinspection PhpIncludeInspection */
        include(__DIR__ . '/views/' . $template . '.php');
        $returned = ob_get_contents();
        ob_end_clean();

        return $returned;
    }
}

if ( ! function_exists( 'wgc_data_masking' ) ) {
    function wgc_data_masking( $data ) {
        if ( ! is_array( $data ) ) {
            return $data;
        }

        $secret_fields = array(
            'ssl_pin',
            'ssl_token',
            'ssl_card_number',
	        'ssl_cvv2cvc2',
        );

        foreach ( $secret_fields as $secret_field ) {

            if ( array_key_exists( $secret_field, $data ) ) {

                if ( $secret_field == "ssl_token" && strlen( $data[$secret_field] ) > 4 )
                    $data[ $secret_field ] = sprintf( "%s*** secret data ***%s",
                        substr( $data[$secret_field], 0, 2 ),
                        substr( $data[$secret_field], - 2 ) );
                else
                    $data[ $secret_field ] = "*** secret data ***";
            }
        }

        return $data;
    }
}

if ( ! function_exists( 'wgc_get_custom_fields' ) ) {
    function wgc_get_custom_fields() {
        return array(
            WGC_KEY_VENDOR_ID          => WGC_KEY_VENDOR_ID_VALUE,
            WGC_KEY_VENDOR_APP_NAME    => WGC_KEY_VENDOR_APP_NAME_VALUE,
            WGC_KEY_VENDOR_APP_VERSION => WGC_KEY_VENDOR_APP_VERSION_VALUE,
        );
    }
}

