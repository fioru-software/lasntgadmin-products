<?php
declare(strict_types=1);

require plugin_dir_path(__FILE__) . 'vendor/autoload.php';