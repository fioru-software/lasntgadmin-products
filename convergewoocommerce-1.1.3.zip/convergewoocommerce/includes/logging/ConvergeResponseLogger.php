<?php

/**
 * @noinspection DuplicatedCode
 * @noinspection PhpUndefinedClassInspection
 */


/**
 * Class RequestMiddleware
 */
class ConvergeResponseLogger extends AbstractMiddleware
{
    public function __construct()
    {
        $this->setLogger();
    }

    public function log($message)
    {
        $message = '[CONVERGE-RESPONSE]' . PHP_EOL .
            '[BODY]: ' . print_r($message, true) . PHP_EOL;
        parent::log($message);
    }

    public function logWithContext($message, $context)
    {
        $log_prefix = sprintf("[context: %s]", $context);

        $message = sprintf(__('%s Received data from Converge: %s'),
                $log_prefix, print_r($message, true));

        parent::log($message);
    }
}
