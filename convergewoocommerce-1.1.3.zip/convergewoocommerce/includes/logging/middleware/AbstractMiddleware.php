<?php

/**
 * Class AbstractMiddleware
 * @noinspection PhpUndefinedClassInspection
 */
abstract class AbstractMiddleware
{

    /**
     * @var array
     */
    const LOG_LEVEL_MAP = [
        'log_level_debug' => WC_Log_Levels::DEBUG,
        'log_level_error' => WC_Log_Levels::ERROR,
        'log_level_critical' => WC_Log_Levels::CRITICAL
    ];
    /**
     * @var callable $handler
     */
    protected $handler;
    /**
     * @var WC_Logger $logger
     */
    protected $logger;
    /**
     * @var callable $nextTick
     */
    protected $nextTick;

    /**
     * @return callable
     */
    public function getHandler()
    {
        return $this->handler;
    }

    /**
     * @param callable $handler
     * @return $this
     */
    public function setHandler(callable $handler)
    {
        $this->handler = $handler;
        return $this;
    }

    /**
     * @return WC_Logger
     */
    public function getLogger()
    {
        return $this->logger;
    }

    /**
     * @return $this
     */
    public function setLogger()
    {
        $this->logger = wc_get_logger();
        return $this;
    }

    /**
     * @return mixed
     */
    public function next()
    {
        if (is_array($this->nextTick)) {
            return call_user_func_array($this->handler, $this->nextTick);
        }

        return $this->nextTick;
    }

    /**
     * @param mixed $data
     * @return false|string
     */
    public function toJson($data)
    {
        return json_encode($data, JSON_UNESCAPED_SLASHES);
    }

    /**
     * @param string $message
     */
    protected function log($message)
    {
        $settings = get_option('woocommerce_' . WGC_PAYMENT_NAME . '_settings');
        $debug = $settings['debug'];

        if ('yes' ===  $debug)
            $this->logger->log(WC_Log_Levels::DEBUG, $message, array('source' => WGC_PAYMENT_NAME));
    }

    /**
     * @param mixed $options
     * @return $this
     */
    public function setNextTick($options)
    {
        $this->nextTick = $options;
        return $this;
    }
}
