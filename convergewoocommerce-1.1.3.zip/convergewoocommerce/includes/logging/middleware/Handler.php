<?php

/**
 * @noinspection PhpUndefinedClassInspection
 * @noinspection DuplicatedCode
 */

use GuzzleHttp\HandlerStack;
use GuzzleHttp\Promise\PromiseInterface;
use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\ResponseInterface;

/**
 * Class Handler
 */
class Handler
{

    /**
     * @var array $subscribers
     */
    protected static $middlewareStack = [
        RequestMiddleware::class,
        ResponseMiddleware::class
    ];

    /**
     * @param callable|null $handler
     * @return HandlerStack
     */
    static public function get(callable $handler = null)
    {
        $stack = HandlerStack::create($handler);
        foreach (self::$middlewareStack as $middlewareClass) {
            $middleware = new $middlewareClass();
            /** @var AbstractMiddleware $middleware */
            $stack->push(function (callable $handler) use ($middleware) {
                $constructedMiddleware = $middleware->setHandler($handler)->setLogger();
                return self::wrapMiddleware($constructedMiddleware);
            });
        }
        return $stack;
    }

    /**
     * @param AbstractMiddleware $preparedMiddleware
     * @return Closure|AbstractMiddleware
     */
    static protected function wrapMiddleware(AbstractMiddleware $preparedMiddleware)
    {
        $middleware = self::wrapWithNextTick($preparedMiddleware);
        if (!$preparedMiddleware instanceof ResponseMiddleware) {
            return $middleware;
        }

        return function (RequestInterface $request, array $options) use ($preparedMiddleware, $middleware) {
            $handler = $preparedMiddleware->getHandler();
            $promise = $handler($request, $options);
            /** @var PromiseInterface $promise */
            return $promise->then($middleware);
        };
    }

    /**
     * @param AbstractMiddleware|callable $middleware
     * @return Closure|void
     */
    static protected function wrapWithNextTick(AbstractMiddleware $middleware)
    {
        if ($middleware instanceof RequestMiddleware) {
            return function (RequestInterface $request, array $options) use ($middleware) {
                $middleware->setNextTick([$request, $options]);
                return $middleware($request, $options);
            };
        }

        if ($middleware instanceof ResponseMiddleware) {
            return function (ResponseInterface $response) use ($middleware) {
                $middleware->setNextTick($response);
                return $middleware($response);
            };
        }
    }
}