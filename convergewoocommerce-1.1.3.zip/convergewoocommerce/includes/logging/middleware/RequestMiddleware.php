<?php

/**
 * @noinspection DuplicatedCode
 * @noinspection PhpUndefinedClassInspection
 */

use Psr\Http\Message\RequestInterface;

/**
 * Class RequestMiddleware
 */
class RequestMiddleware extends AbstractMiddleware
{

    /**
     * @param RequestInterface $request
     * @param array $options
     * @return mixed
     */
    public function __invoke(RequestInterface $request, array $options)
    {
        $this->log($this->formatMessage($request));
        return $this->next();
    }

    /**
     * @param RequestInterface $request
     * @return string
     */
    protected function formatMessage(RequestInterface $request)
    {
        $uri = $request->getUri();
        $normalizedUriFragment = str_replace('do?xmldata=', '', substr($uri, strpos($uri, 'do?')));

        if (strpos($normalizedUriFragment, 'transaction_token') !== false) {

            parse_str($request->getBody(), $output);
            $output = wgc_data_masking($output);
            $result = $result = '[REQUEST]' . PHP_EOL .
                                '[BODY] ' . print_r($output, true) ;
        } else{
            $xml = simplexml_load_string(urldecode($normalizedUriFragment), 'SimpleXMLElement', LIBXML_NOCDATA);
            $json = json_encode($xml);
            $array = json_decode($json, true);
            $array = wgc_data_masking($array);
            $normalizedUri = explode('?', $uri);
            $result = '[REQUEST]' . PHP_EOL .
                      '[URI]: ' . $normalizedUri[0] . PHP_EOL .
                      '[BODY]: ' . (!empty($array) ? print_r($array, true) : '{}');

        }

        return $result;

    }
}
