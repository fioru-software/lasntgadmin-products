<?php

/**
 * @noinspection DuplicatedCode
 * @noinspection PhpUndefinedClassInspection
 */

use Psr\Http\Message\ResponseInterface;

/**
 * Class ResponseMiddleware
 */
class ResponseMiddleware extends AbstractMiddleware
{

    /**
     * @param ResponseInterface $response
     * @return ResponseInterface
     */
    public function __invoke(ResponseInterface $response)
    {
        $this->log($this->formatMessage($response));
        return $this->next();
    }

    /**
     * @param ResponseInterface $response
     * @return string
     */
    protected function formatMessage(ResponseInterface $response)
    {

        $body = (string)$response->getBody();

        if(substr( $body, 0, 5 ) === "<?xml"){
            $xml = simplexml_load_string($body, 'SimpleXMLElement', LIBXML_NOCDATA);
            $json = json_encode($xml);
            $array = json_decode($json, true);

            $result = '[RESPONSE]' . PHP_EOL .
                      '[STATUS_CODE]: ' . $response->getStatusCode() . PHP_EOL .
                      '[BODY]: ' . (!empty($array) ? print_r($array, true) : '{}');
        } else{

            $result =   '[RESPONSE]' . PHP_EOL .
                        '[STATUS_CODE]: ' . $response->getStatusCode() . PHP_EOL .
                        '[BODY]: ' . $body . PHP_EOL ;
        }

        return $result;
    }
}
