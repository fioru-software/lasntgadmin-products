<?php

require_once __DIR__ . '/../../../../wp-load.php';


global $woocommerce;

/** @noinspection PhpUndefinedMethodInspection */
$woocommerce->checkout()->process_checkout();