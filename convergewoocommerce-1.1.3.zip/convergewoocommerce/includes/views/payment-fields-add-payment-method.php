<?php
woocommerce_form_field("elavon-converge-gateway-card-number", [
	"type" => "tel",
	"required" => true,
	"id" => "elavon-converge-gateway-card-number",
	"label" => "Card Number",
	"placeholder" => "&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull;",
	"autocomplete" => "cc-number",
	"class" => ["form-row-wide"],
	"custom_attributes" => [
		"inputmode" => "numeric",
		"autocorrect" => "no",
		"autocapitalize" => "no",
		"spellcheck" => "no",
		"maxlength" => 23
	]
]);
woocommerce_form_field( "elavon-converge-gateway-card-expiry", [
	"type"              => "tel",
	"required"          => true,
	"id"                => "elavon-converge-gateway-card-expiry",
	"label"             => "Expiry (MM/YY)",
	"placeholder"       => "MM / YY",
	"autocomplete"      => "cc-exp",
	"class"             => [ "form-row-first" ],
	"input_class"       => [ "wc-credit-card-form-card-expiry" ],
	"custom_attributes" => [
		"inputmode"      => "numeric",
		"autocorrect"    => "no",
		"autocapitalize" => "no",
		"spellcheck"     => "no",
		"maxlength"      => 7,
	],
] );
woocommerce_form_field( "elavon-converge-gateway-card-cvc", [
	"type"              => "tel",
	"required"          => true,
	"id"                => "elavon-converge-gateway-card-cvc",
	"label"             => "CVC",
	"placeholder"       => "CVC",
	"autocomplete"      => "off",
	"class"             => [ "form-row-last" ],
	"input_class"       => [ "wc-credit-card-form-card-cvc" ],
	"custom_attributes" => [
		"inputmode"      => "numeric",
		"autocorrect"    => "no",
		"autocapitalize" => "no",
		"spellcheck"     => "no",
		"maxlength"      => 4,
	],
] );
?>
