<style>
    .payment_box.payment_method_elavon-converge-gateway label {
        display: inline;
    }

    #wgc1-payment-gateway label {
        font-weight: 400;
        display: inline;
    }

    #wgc1-payment-gateway .converge-payment-type {
        display: none;
        padding-left: 20px;
    }

    #wgc1-payment-gateway .converge-payment-type .woocommerce-SavedPaymentMethods-saveNew {
        display: block !important;
    }

    #wgc1-payment-gateway p.form-row {
        margin: 0 0 0.5em;
    }

</style>
<div id="wgc1-payment-gateway">

    <?php if ( $gateway->isGiftCardAccepted() && ! $gateway->isAuthOnly() ) : ?>
        <?php woocommerce_form_field( "converge-payment-option", [
            "type"        => "radio",
            "id"          => "payment-option-gift-card",
            "input_class" => [ "converge-payment-option" ],
            "options"     => [ 'converge-payment-option-gift-card' => "Gift Card" ]
        ] );
        ?>
        <?php if ( $gateway->isCheckoutJS() ): ?>
            <div id="fieldset-converge-gift" class="converge-payment-type">
                <?php
                woocommerce_form_field( "elavon-converge-gateway-gift-card-number", [
                    "type"     => "tel",
                    "required" => true,

                    "id"                => "elavon-converge-gateway-gift-card-number",
                    "label"             => "Card Number",
                    "placeholder"       => "&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull;",
                    "autocomplete"      => "cc-number",
                    "class"             => [ "form-row-wide" ],
                    "input_class"       => [ "wc-gift-card-form-card-number" ],
                    "custom_attributes" => [
                        "inputmode"      => "numeric",
                        "autocorrect"    => "no",
                        "autocapitalize" => "no",
                        "spellcheck"     => "no",
                        "style"          => "display: inline-block",
                        "maxlength"      => 19
                    ]
                ] );
                if ( $gateway->isGiftSecurityCode() ) {
                    woocommerce_form_field( "elavon-converge-gateway-gift-card-code", [
                        "type"     => "tel",
                        "required" => false,

                        "id"                => "elavon-converge-gateway-gift-card-code",
                        "label"             => "Code",
                        "placeholder"       => "Card Code",
                        "autocomplete"      => "off",
                        "class"             => [ "form-row-first" ],
                        "custom_attributes" => [
                            "inputmode"      => "numeric",
                            "autocorrect"    => "no",
                            "autocapitalize" => "no",
                            "spellcheck"     => "no",
                            "maxlength"      => 6
                        ]
                    ] );
                }
                ?>
                <button type="button" id="converge-apply-gift"
                        class="gift-button-apply button button-primary">
                    <?php echo __( "APPLY" ); ?>
                </button>

                <p style="margin-bottom:10px; color:red" id="converge-gift-card-info"></p>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if ( $gateway->isCreditCardAccepted() ) : ?>
        <?php woocommerce_form_field( "converge-payment-option", [
            "type"        => "radio",
            "id"          => "payment-option-credit-card",
            "input_class" => [ "converge-payment-option" ],
            "options"     => [ 'converge-payment-option-credit-card' => "Credit Card" ]
        ] );
        ?>

        <div id="fieldset-converge-credit" class="converge-payment-type">
        <?php if ( $gateway->isCheckoutJS() ): ?>
                <?php
                woocommerce_form_field( "elavon-converge-gateway-card-number", [
                    "type"              => "tel",
                    "required"          => true,
                    "id"                => "elavon-converge-gateway-card-number",
                    "label"             => "Card Number",
                    "placeholder"       => "&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull;",
                    "autocomplete"      => "cc-number",
                    "class"             => [ "form-row-wide" ],
                    "custom_attributes" => [
                        "inputmode"      => "numeric",
                        "autocorrect"    => "no",
                        "autocapitalize" => "no",
                        "spellcheck"     => "no",
                        "maxlength"      => 23
                    ]
                ] );
                woocommerce_form_field( "elavon-converge-gateway-card-expiry", [
                    "type"              => "tel",
                    "required"          => true,
                    "id"                => "elavon-converge-gateway-card-expiry",
                    "label"             => "Expiry (MM/YY)",
                    "placeholder"       => "MM / YY",
                    "autocomplete"      => "cc-exp",
                    "class"             => [ "form-row-first" ],
                    "input_class"       => [ "wc-credit-card-form-card-expiry" ],
                    "custom_attributes" => [
                        "inputmode"      => "numeric",
                        "autocorrect"    => "no",
                        "autocapitalize" => "no",
                        "spellcheck"     => "no",
                        "maxlength"      => 7
                    ]
                ] );
                woocommerce_form_field( "elavon-converge-gateway-card-cvc", [
                    "type"              => "tel",
                    "required"          => true,
                    "id"                => "elavon-converge-gateway-card-cvc",
                    "label"             => "CVC",
                    "placeholder"       => "CVC",
                    "autocomplete"      => "off",
                    "class"             => [ "form-row-last" ],
                    "input_class"       => [ "wc-credit-card-form-card-cvc" ],
                    "custom_attributes" => [
                        "inputmode"      => "numeric",
                        "autocorrect"    => "no",
                        "autocapitalize" => "no",
                        "spellcheck"     => "no",
                        "maxlength"      => 4
                    ]
                ] );
                ?>
        <?php endif; ?>
            <p class="form-row form-row-wide woocommerce-SavedPaymentMethods-saveNew">
		        <?php if ( $gateway->isSavePaymentMethodsEnabled() && is_user_logged_in() ): ?>
                    <input id="wc-elavon-converge-gateway-new-payment-method"
                           name="wc-elavon-converge-gateway-new-payment-method-save-for-later-use" type="checkbox"
                           value="true"
                    />
                    <label for="wc-elavon-converge-gateway-new-payment-method"><?php echo __( "Save for later use" ); ?></label>
                    <?php if ( ! empty( $gateway->get_option( WGC_KEY_SAVE_FOR_LATER_USE ) ) ) : ?>
                        <p class="save-for-later-use-message"><?php echo $gateway->get_option( WGC_KEY_SAVE_FOR_LATER_USE ); ?></p>
                    <?php endif; ?>
		        <?php endif; ?>
            </p>
        </div>

    <?php endif; ?>

    <?php if ( $gateway->isAchAccepted() ) : ?>

        <?php woocommerce_form_field( "converge-payment-option", [
            "type"        => "radio",
            "id"          => "payment-option-ach",
            "input_class" => [ "converge-payment-option" ],
            "options"     => [ 'converge-payment-option-ach' => "ACH" ]
        ] );
        ?>
        <?php if ( $gateway->isCheckoutJS() ): ?>
            <div id="fieldset-converge-ach" class="converge-payment-type">
                <?php
                woocommerce_form_field( "elavon-converge-gateway-ach-transit-number", [
                    "type"     => "tel",
                    "required" => true,

                    "class"             => [ "form-row-wide" ],
                    "input_class"       => [ "converge-input" ],
                    "label"             => "Bank Routing/Transit Number",
                    "autocomplete"      => "off",
                    "custom_attributes" => [
                        "inputmode"      => "numeric",
                        "autocorrect"    => "no",
                        "autocapitalize" => "no",
                        "spellcheck"     => "no",
                        "maxlength"      => 9
                    ]
                ] );
                woocommerce_form_field( "elavon-converge-gateway-ach-bank-account-number", [
                    "type"     => "tel",
                    "required" => true,

                    "class"             => [ "form-row-wide" ],
                    "input_class"       => [ "converge-input" ],
                    "label"             => "Bank Account Number",
                    "autocomplete"      => "off",
                    "custom_attributes" => [
                        "inputmode"      => "numeric",
                        "autocorrect"    => "no",
                        "autocapitalize" => "no",
                        "spellcheck"     => "no",
                        "maxlength"      => 16
                    ]
                ] );
                woocommerce_form_field( "elavon-converge-gateway-ach-check-number", [
                    "type"     => "tel",
                    "required" => false,

                    "class"             => [ "form-row-wide" ],
                    "input_class"       => [ "converge-input" ],
                    "label"             => "Check Number",
                    "autocomplete"      => "off",
                    "custom_attributes" => [
                        "inputmode"      => "numeric",
                        "autocorrect"    => "no",
                        "autocapitalize" => "no",
                        "spellcheck"     => "no",
                        "maxlength"      => 16
                    ]
                ] );
                woocommerce_form_field( "elavon-converge-gateway-ach-bank-account-type", [
                    "type"        => "select",
                    "label"       => "Bank account type",
                    "required"    => true,
                    "input_class" => [ "select2" ],
                    "options"     => [ '0' => "Personal", "1" => "Business" ]
                ] );
                woocommerce_form_field( "elavon-converge-gateway-ach-first-name", [
                    "type"     => "text",
                    "required" => true,

                    "class"             => [ "form-row-wide" ],
                    "input_class"       => [ "converge-input" ],
                    "label"             => "First Name",
                    "autocomplete"      => "off",
                    "custom_attributes" => [
                        "autocorrect"    => "no",
                        "autocapitalize" => "no",
                        "spellcheck"     => "no",
                        "maxlength"      => 20
                    ]
                ] );
                woocommerce_form_field( "elavon-converge-gateway-ach-last-name", [
                    "type"     => "text",
                    "required" => true,

                    "class"             => [ "form-row-wide" ],
                    "input_class"       => [ "converge-input" ],
                    "label"             => "Last Name",
                    "autocomplete"      => "off",
                    "custom_attributes" => [
                        "autocorrect"    => "no",
                        "autocapitalize" => "no",
                        "spellcheck"     => "no",
                        "maxlength"      => 30
                    ]
                ] );
                woocommerce_form_field( "elavon-converge-gateway-ach-company", [
                    "type"     => "text",
                    "required" => true,

                    "class"             => [ "form-row-wide", "converge-display-none" ],
                    "input_class"       => [ "converge-input" ],
                    "label"             => "Company",
                    "autocomplete"      => "off",
                    "custom_attributes" => [
                        "autocorrect"    => "no",
                        "autocapitalize" => "no",
                        "spellcheck"     => "no",
                        "maxlength"      => 50
                    ]
                ] );
                ?>
                <p>By Clicking the "I Agree" box below, you authorize
                    <strong><?php $gateway->get_option( WGC_KEY_MERCHANT_NAME ); ?></strong> to use
                    information from your check to initiate a one-time fund transfer from your account or to process the
                    payment as a check transaction or bank drawn draft from your account for the amount shown above. If
                    your
                    payment is returned due to insufficient funds, you authorize us to make a one-time electronic funds
                    transfer or to use a bank draft drawn from your account to collect a fee as allowed by state law.
                </p>
                <?php
                woocommerce_form_field( "elavon-converge-gateway-ach-agree", [
                    "type"        => "checkbox",
                    "required"    => true,
                    "class"       => [ "form-row-wide" ],
                    "input_class" => [ "converge-input" ],
                    "label"       => "I Agree"
                ] );
                ?>
            </div>
        <?php endif; ?>

    <?php endif; ?>
</div>
