<?php
?>
<div id="wallet-iframes">
    <div id="paypal-checkout-button" style="display:inline-block; position: relative; top: 4px;" tabindex="-1"></div>
    <div id="paypalcredit-checkout-button" style="display:inline-block; position: relative; top: 4px;"></div>
    <?php if ( is_user_logged_in() ): ?>
        <div id="masterpass-checkout-button" style="display:inline-block; position: relative; bottom: 4px;"></div>
    <?php endif; ?>
    <div id="applepay-checkout-button" style="display:inline-block;"></div>
</div>