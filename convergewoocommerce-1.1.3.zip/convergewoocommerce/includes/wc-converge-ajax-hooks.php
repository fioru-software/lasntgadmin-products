<?php

use Elavon\Converge\Api\Transaction\SessionToken\TransferObject\SessionTokenTransferObject;
use Elavon\Converge\Config\MerchantConfig;
use Elavon\Converge\Converge;

add_action('wc_ajax_giftcard_balance', 'giftcard_order_balance');
add_action('wc_ajax_get_nonce', 'get_nonce');

function getConverge($sessionTokenRequest)
{
    $gateway = wgc_get_gateway();
    $merchant_id = $gateway->get_option(WGC_MODULE_MERCHANT_ID);
    $user_id = $gateway->get_option(WGC_MODULE_USER_ID);
    $user_pin = $gateway->get_option(WGC_MODULE_USER_PIN);
    $sandboxMode = WGC_SETTING_ENV_SANDBOX === $gateway->get_option( WGC_KEY_ENVIRONMENT, WGC_SETTING_ENV_PRODUCTION );

    $config = new MerchantConfig($merchant_id, $user_id, $user_pin, $sessionTokenRequest);
    $config->setSandboxMode($sandboxMode);

    if ( ! empty( $gateway->get_option( WGC_KEY_USE_PROXY ) ) ) {
        $proxy = trim(
            $gateway->get_option( WGC_KEY_PROXY_HOST ) . ':' . $gateway->get_option( WGC_KEY_PROXY_PORT ),
            ': '
        );
        $config->setProxyRepresentation( $proxy );
    }

    $converge = new Converge($config);
    $transaction = $converge->getTransaction();
    return $transaction;

}

function get_nonce()
{
    global $woocommerce;
    $order = null;

    $ssl_merchant_txn_id = wc_get_merchant_txn_id();
    WC()->session->set('ssl_merchant_txn_id', $ssl_merchant_txn_id );

    $is_lightbox = false;
	if($_POST['is_lightbox'] == "true"){
        WC()->session->set('paid_with_lightbox', true );
		$is_lightbox = true;
	}
    $gateway = wgc_get_gateway();

    // default value for getting nonce for wallets
    $payment_action = $gateway->get_option( WGC_KEY_PAYMENT_ACTION ) === 'auth_only' ? "ccauthonly" : "ccsale";

    if (isset($_POST['payment_type'])) {
        if ($_POST['payment_type'] === "converge-payment-option-ach") {
	        $payment_action = "ecspurchase";
        } elseif ( $_POST['payment_type'] === "converge-payment-option-credit-card" ) {
	        if ( $is_lightbox && isset( $_POST['save_for_later_use'] ) && $_POST['save_for_later_use'] == "true" ) {
		        $payment_action = 'ccgettoken';
	        }
        } elseif ($_POST['payment_type'] === "converge-payment-option-gift-card") {
            $payment_action = "egcsale";
        }
    }


    $partial_amount = 0;

    if (isset($_POST['partial_amount'])) {
        $partial_amount = $_POST['partial_amount'];
    }

	$order_from_merchant_view = isset( $_POST['order_key'] );

    if ($order_from_merchant_view) {
        $order = wc_get_order( wc_get_order_id_by_order_key( wc_clean( $_POST['order_key'] ) ) );
    }

	if ( $partial_amount ) {
		$amount = $partial_amount;
	} elseif ( $order_from_merchant_view ) {

	    $amount = $order->get_total();

	} else {
		$amount = $woocommerce->cart->total;
	}

	if ($payment_action == "egcsale") {
        WC()->session->set('ssl_gift_card_number', $_POST['elavon-converge-gateway-gift-card-number'] );
        WC()->session->set('paid_with_gift_amount', $amount );
    }

	$dutyAmount = 0;
	$ssl_customer_code = wc()->customer->get_id() ?? null;
	$productArray = [];
	$is_level_3 = $gateway->isLevel3Enabled();

	if ($order_from_merchant_view) {
        $company = $order->get_billing_company();
        $ssl_first_name = $order->get_billing_first_name();
		$ssl_last_name = $order->get_billing_last_name();
		$address1 = $order->get_billing_address_1();
		$address2 = $order->get_billing_address_2();
        $city = $order->get_billing_city();
        $state = $order->get_billing_state();
		$zip_code = $order->get_billing_postcode();
        $country = $order->get_billing_country();
        $phone = $order->get_billing_phone();
        $email = $order->get_billing_email();
        $ship_company = $order->get_shipping_company();
        $ship_first_name = $order->get_shipping_first_name();
        $ship_last_name = $order->get_shipping_last_name();
        $ship_address1 = $order->get_shipping_address_1();
        $ship_address2 = $order->get_shipping_address_2();
        $ship_city = $order->get_shipping_city();
        $ship_state = $order->get_shipping_state();
        $ship_country = $order->get_shipping_country();
        $ship_phone = $order->get_billing_phone();

        if ( $is_level_3 ) {
            $ship_zip_code = $order->get_shipping_postcode();
            foreach ( $order->get_items() as $item_id => $product ) {
                $total    = $product->get_total();
                $quantity = $product->get_quantity();
                $product_id = $product->get_product_id();
                $product_entity = wc_get_product( $product->get_product_id() );
                $price    = $total / $quantity;
                $sale_price = $product_entity->get_sale_price();
                $product_discount = $product_entity->get_regular_price() - $price;

                $productData = [
                    'ssl_line_item_description'        => WC_Converge_Gateway_Helper::cleanString( $product_entity->get_short_description(), 25 ),
                    'ssl_line_Item_unit_cost'          => $price,
                    'ssl_line_Item_quantity'           => $quantity,
                    'ssl_line_item_total'              => $total,
                    'ssl_line_Item_commodity_code'     => get_post_meta( $product_id, 'wgc-commodity-code', true ),
                    'ssl_line_Item_unit_of_measure'    => get_post_meta( $product_id, 'wgc-uom-code', true ),
                    'ssl_line_Item_discount_indicator' => $price == $sale_price ? 'Y' : 'N',
                    'ssl_line_Item_discount_amount'    => $product_discount,
                ];
                array_push( $productArray, $productData );
            }

            $LineItemProducts = json_encode( $productArray );
            $tax_amount         = $order->get_total_tax();
            $shipping_amount    = $order->get_shipping_total();
            $ssl_invoice_number = $order->get_id();
            $ssl_discount_amount = $order->get_total_discount(get_option( 'woocommerce_tax_display_cart' ) == 'excl');
        }
    } else {
		$cart = wc()->cart;
		$customer = $cart->get_customer();
        $company = $_POST['billing_company'] ?? null;
        $ssl_first_name = $_POST['billing_first_name'] ?? null;
        $ssl_last_name = $_POST['billing_last_name'] ?? null;
        $address1 = $customer->get_billing_address_1();
        $address2 = $customer->get_billing_address_2();
        $city = $customer->get_billing_city();
        $state = $customer->get_billing_state();
        $zip_code = $customer->get_billing_postcode();
        $country = $customer->get_billing_country();
        $phone = $_POST['billing_phone'] ?? null;
        $email = $_POST['billing_email'] ?? null;
        $ship_address1 = $customer->get_shipping_address_1();
        $ship_address2 = $customer->get_shipping_address_2();
        $ship_city = $customer->get_shipping_city();
        $ship_state = $customer->get_shipping_state();
        $ship_country = $customer->get_shipping_country();

        if ( isset( $_POST['ship_to_different_address'] ) && filter_var( $_POST['ship_to_different_address'], FILTER_VALIDATE_BOOLEAN ) ) {
            $ship_company = $_POST['shipping_company'] ?? null;
            $ship_first_name = $_POST['shipping_first_name'] ?? null;
            $ship_last_name = $_POST['shipping_last_name'] ?? null;
            $ship_phone = $_POST['shipping_phone'] ?? null;
        } else {
            $ship_company = $company;
            $ship_first_name = $ssl_first_name;
            $ship_last_name = $ssl_last_name;
            $ship_phone = $phone;
        }

        if ( $is_level_3 ) {
            $ship_zip_code =  $customer->get_shipping_postcode();
            foreach ( wc()->cart->get_cart() as $cart_item_key => $cart_item ) {
                $product  = $cart_item['data'];
                $price    = $product->get_price();
                $sale_price = $product->get_sale_price();
                $quantity = $cart_item['quantity'];
                $product_discount = $product->get_regular_price() - $price;

                $productData = [
                    'ssl_line_item_description'        => WC_Converge_Gateway_Helper::cleanString( $product->get_short_description(), 25 ),
                    'ssl_line_Item_unit_cost'          => $price,
                    'ssl_line_Item_quantity'           => $quantity,
                    'ssl_line_item_total'              => $price * $quantity,
                    'ssl_line_Item_commodity_code'     => get_post_meta($product->get_id(),'wgc-commodity-code', true),
                    'ssl_line_Item_unit_of_measure'    => get_post_meta($product->get_id(),'wgc-uom-code', true),
                    'ssl_line_Item_discount_indicator' => $price == $sale_price ? 'Y' : 'N',
                    'ssl_line_Item_discount_amount'    => $product_discount,
                ];

                array_push( $productArray, $productData );
            }

            $LineItemProducts = json_encode( $productArray );
            $tax_amount       = $cart->get_taxes_total();
            $shipping_amount  = $cart->get_shipping_total();
            $ssl_invoice_number = null;
            $ssl_discount_amount = $cart->get_discount_total();
            if ( $cart->display_prices_including_tax() ) {
                $ssl_discount_amount += $cart->get_cart_discount_tax_total();
            }
        }

    }

    $data = [
        "ssl_transaction_type"      => $payment_action,
        "ssl_amount"                => $amount,
        "ssl_merchant_txn_id"       => $ssl_merchant_txn_id,
        "ssl_get_token"             => 'Y',
        'ssl_company'               => $company,
        "ssl_first_name"            => $ssl_first_name,
        "ssl_last_name"             => $ssl_last_name,
        'ssl_avs_address'           => $address1,
        'ssl_address2'              => $address2,
        'ssl_city'                  => $city,
        'ssl_state'                 => $state,
        'ssl_avs_zip'               => $zip_code,
        'ssl_country'               => $country,
        'ssl_phone'                 => $phone,
        'ssl_email'                 => $email,
        'ssl_ship_to_company'       => $ship_company,
        'ssl_ship_to_first_name'    => $ship_first_name,
        'ssl_ship_to_last_name'     => $ship_last_name,
        'ssl_ship_to_address1'      => $ship_address1,
        'ssl_ship_to_address2'      => $ship_address2,
        'ssl_ship_to_city'          => $ship_city,
        'ssl_ship_to_state'         => $ship_state,
        'ssl_ship_to_country'       => $ship_country,
        'ssl_ship_to_phone'         => $ship_phone,
    ];

    if ( $is_level_3 ) {
        $data = array_merge( $data, [
            "ssl_level3_indicator"      => 'Y',
            "LineItemProducts"          => $LineItemProducts,
            "ssl_salestax"              => number_format( $tax_amount, 2 ),
            "ssl_salestax_indicator"    => $tax_amount > 0 ? 'Y' : 'N',
            "ssl_duty_amount"           => number_format( $dutyAmount, 2 ),
            "ssl_shipping_amount"       => $shipping_amount,
            "ssl_customer_code"         => $ssl_customer_code,
            "ssl_invoice_number"        => $ssl_invoice_number,
            "ssl_ship_from_postal_code" => get_option( 'woocommerce_store_postcode' ),
            "ssl_discount_amount"       => $ssl_discount_amount,
            'ssl_ship_to_zip'           => $ship_zip_code,
        ] );
    }

    $data = array_merge( $data, wgc_get_custom_fields() );

    $to = new SessionTokenTransferObject($data);

    $type = getConverge(true)->geSessionTokenType();

    $sessionTokenAO = $type->getSessionToken($to);
    $response = $sessionTokenAO->getResponse();
    $context = isset( $_POST['context'] ) ? $_POST['context'] : "get nonce";

    wgc_log_converge_request( $data, $context, $order );
    wgc_log_converge_response( $response, $context, $order );

    wp_send_json(["token" => $sessionTokenAO->getToken(), 'amount' => $amount, 'is_success' => $response->isSuccess()]);

}

function giftcard_order_balance()
{

    global $woocommerce;
    $type = getConverge(false)->getGiftCardType();
    $giftCardHandler = new  WC_Converge_Giftcard_Handler($type,
        new ConvergeResponseLogger());

    $cardNumber = sanitize_text_field($_POST['elavon-converge-gateway-gift-card-number']);
    $security_code = sanitize_text_field($_POST['elavon-converge-gateway-gift-card-code']);

    try {
        $balance = $giftCardHandler->getGiftCardBalance($cardNumber, $security_code);
    } catch (Exception $ex) {
        if (strpos($ex->getMessage(), 'code') !== false) {
            $message = __('The security code is not valid');
        } else {
            $message = __('The card number is not valid');
        }
        wp_send_json_error($message);

    }
	if ( isset( $_POST['order_key'] ) ) {
		$amount = wc_get_order( wc_get_order_id_by_order_key( wc_clean( $_POST['order_key'] ) ) )->get_total();
	} else {
		$amount = $woocommerce->cart->total;
	}

    wp_send_json_success(["balance" => $balance, "order_total" => $amount]);
//    wp_die();
}

