<?php

/**
 * Constants related to settings for Converge Gateway.
 * @noinspection DuplicatedCode
 */

defined('ABSPATH') || exit;

define('WGC_MODULE_MERCHANT_ID', 'merchant_id');
define('WGC_MODULE_USER_ID', 'user_id');
define('WGC_MODULE_USER_PIN', 'user_pin');
define('WGC_MODULE_TERMINAL_NAME', 'terminal_name');
define('WGC_MODULE_TERMINAL_SETUP', 'terminal_setup');
define('WGC_CONVERGE_ROUTE', 'converge_route');
define('WGC_KEY_ENVIRONMENT', 'environment');
define('WGC_KEY_TITLE', 'title');
define('WGC_KEY_ENABLED', 'enabled');
define('EPSILON', 0.000001);

define('ENCRYPTION_KEY_MASK', '******');
define('ENCRYPTION_CIPHER_KEY', 'converge-gateway-cipher');
define('WGC_MODULE_TERMINAL_SETUP_VALUE', __('Setup', 'elavon-converge-gateway'));
define('WGC_SETTING_ENABLED_NO', 'no');
define('WGC_SETTING_ENABLED_YES', 'yes');
define('WGC_KEY_TITLE_DEFAULT', 'Elavon Converge NA Gateway');
define('WGC_KEY_TITLE_MAXLENGTH', 64);
define('WGC_SETTING_ENV_PRODUCTION', 'production');
define('WGC_SETTING_ENV_SANDBOX', 'sandbox');


define('WGC_SETTING_INTEGRATION_HPP', 'integration_hpp');
define('WGC_SETTING_INTEGRATION_HPP_CHECKOUT', 'integration_checkout');
define('WGC_KEY_SAVE_FOR_LATER_USE', 'save_for_later_use');
define('WGC_SETTING_PAYMENT_TYPE_CC', 'payment_type_credit_card');
define('WGC_SETTING_PAYMENT_TYPE_ACH', 'payment_type_ach');
define('WGC_SETTING_PAYMENT_TYPE_GIFT_CARD', 'payment_type_gift_card');
define('WGC_GIFT_CARD_SECURITY_CODE', 'gift_card_security_code');

define('WGC_SETTING_CC_ACCEPTED_VISA', 'cc_accepted_visa');
define('WGC_SETTING_CC_ACCEPTED_MASTER_CARD', 'cc_accepted_master_card');
define('WGC_SETTING_CC_ACCEPTED_AMERICAN_EXPRESS', 'cc_accepted_american_express');
define('WGC_SETTING_CC_ACCEPTED_JCB', 'cc_accepted_jcb');
define('WGC_SETTING_CC_ACCEPTED_CUP', 'cc_accepted_cup');
define('WGC_SETTING_CC_ACCEPTED_DISCOVER', 'cc_accepted_discover');

define('WGC_SETTING_LANGUAGE_TRANSLATION_EN', 'language_translation_en');
define('WGC_SETTING_LANGUAGE_TRANSLATION_FR', 'language_translation_fr');

define('WGC_SETTING_CURRENCY_MULTI', 'currency_multi');
define('WGC_SETTING_CURRENCY_DYNAMIC', 'currency_dynamic');
define('WGC_SETTING_VALUE_ADDED_SERVICE_3D_LEVEL', 'value_added_service_3d_level');
define('WGC_SETTING_VALUE_ADDED_SERVICE_TOKENIZATION', 'value_added_service_tokenization');
define('WGC_SETTING_VALUE_ADDED_SERVICE_3DS', 'value_added_service_3ds');
define('WGC_SETTING_VALUE_ADDED_SERVICE_3DS2', 'value_added_service_3ds2');

define('WGC_SETTING_LOG_LEVEL_DEBUG', 'log_level_debug');
define('WGC_SETTING_LOG_LEVEL_ERROR', 'log_level_error');
define('WGC_SETTING_LOG_LEVEL_CRITICAL', 'log_level_critical');
define('WGC_SETTING_WALLET_MASTERPASS', 'wallet_masterpass');
define('WGC_SETTING_WALLET_VISA', 'wallet_visa');
define('WGC_SETTING_WALLET_PP', 'wallet_pp');
define('WGC_SETTING_WALLET_APPLE', 'wallet_apple');

define('WGC_KEY_LOG_LEVEL', 'log_level');
define('WGC_KEY_LANGUAGE_TRANSLATION', 'language_translations');
define('WGC_KEY_VALUE_ADDED_SERVICE', 'value_added_service');
define('WGC_KEY_WALLETS_ENABLED', 'wallets_enabled');
define('WGC_KEY_CURRENCY_CONVERSION', 'currency_conversion');
define('WGC_KEY_DEBUG', 'debug');
define('WGC_SETTING_DEBUG_NO', 'no');

define( 'WGC_KEY_PROXY_SETTING', 'proxy_setting' );
define( 'WGC_KEY_USE_PROXY', 'use_proxy' );
define( 'WGC_SETTING_USE_PROXY_YES', true );
define( 'WGC_SETTING_USE_PROXY_NO', false );
define( 'WGC_KEY_PROXY_HOST', 'proxy_host' );
define( 'WGC_KEY_PROXY_PORT', 'proxy_port' );

define('WGC_KEY_PUBLIC_KEY', 'public_key');
define('WGC_KEY_SECRET_KEY', 'secret_key');
define('WGC_KEY_MERCHANT_ALIAS', 'merchant_alias');

define('WGC_KEY_CONVERGE_EMAIL', 'converge_email');
define('WGC_SETTING_CONVERGE_EMAIL_NO', false);
define('WGC_SETTING_CONVERGE_EMAIL_YES', true);

define('WGC_KEY_PROCESSOR_ACCOUNT_ID', 'processor_account_id');
define('WGC_KEY_MERCHANT_NAME', 'merchant_name');
define('WGC_KEY_REGION', 'region');
define('WGC_KEY_CURRENCY', 'currency');

define('WGC_KEY_PAYMENT_TYPE_ACCEPTED', 'payment_types_accepted');
define('WGC_KEY_CREDIT_CARD_ACCEPTED', 'credit_cards_accepted');

define('WGC_KEY_PAYMENT_ACTION', 'payment_action');
define('WGC_SETTING_PAYMENT_ACTION_AUTH_ONLY', 'auth_only');
define('WGC_SETTING_PAYMENT_ACTION_CAPTURE', 'capture');

define('WGC_KEY_SHOPPER_STATEMENT', 'shopper_statement');
define('WGC_KEY_NAME', 'name');
define('WGC_KEY_PHONE', 'phone');
define('WGC_KEY_URL', 'url');

define('WGC_KEY_INTEGRATION_OPTION', 'integration_option');
define('WGC_SETTING_INTEGRATION_HPP_REDIRECT', 'hpp_redirect');
define('WGC_SETTING_INTEGRATION_HPP_POPUP', 'hpp_popup');

define('WGC_KEY_VENDOR_ID', 'ssl_vendor_id');
define('WGC_KEY_VENDOR_APP_NAME', 'ssl_vendor_app_name');
define('WGC_KEY_VENDOR_APP_VERSION', 'ssl_vendor_app_version');

define('WGC_KEY_VENDOR_ID_VALUE', 'Endava');
define('WGC_KEY_VENDOR_APP_NAME_VALUE', 'Converge NA WooCommerce Plugin');
define('WGC_KEY_VENDOR_APP_VERSION_VALUE', '1.1.3');

define('WGC_KEY_WOOCOMMERCE_ID', 'WooCommerceID');

define('WGC_KEY_LICENSE_CODE', 'license_code');

define('WGC_PAYMENT_TOKEN_TYPE', 'Converge_Gateway_StoredCard');

define('WGC_SANDBOX_CHECKOUT_JS_URL', 'https://demo.convergepay.com/hosted-payments/Checkout.js');
define('WGC_SANDBOX_LIGHTBOX_JS_URL', 'https://demo.convergepay.com/hosted-payments/PayWithConverge.js');
define('WGC_SANDBOX_EFS_3DS2_JS_URL', 'https://libs.fraud.elavongateway.com/sdk-web-js/0.13.8/3ds2-web-sdk.min.js');
define('WGC_SANDBOX_SERVER_3DS2_URL', 'https://uat.gw.fraud.eu.elavonaws.com/3ds2');

define('WGC_PRODUCTION_CHECKOUT_JS_URL', 'https://www.convergepay.com/hosted-payments/Checkout.js');
define('WGC_PRODUCTION_LIGHTBOX_JS_URL', 'https://www.convergepay.com/hosted-payments/PayWithConverge.js');
define('WGC_PRODUCTION_EFS_3DS2_JS_URL', 'https://libs.fraud.elavongateway.com/sdk-web-js/0.13.8/3ds2-web-sdk.min.js');
define('WGC_PRODUCTION_SERVER_3DS2_URL', 'https://gw.fraud.elavongateway.com/3ds2');

