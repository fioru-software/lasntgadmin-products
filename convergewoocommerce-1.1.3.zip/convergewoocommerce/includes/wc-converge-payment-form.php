<?php

/** @noinspection PhpUndefinedClassInspection */
/** @noinspection DuplicatedCode */

defined('ABSPATH') || exit;
add_filter('woocommerce_credit_card_form_fields', 'custom_form_cc_ach_gift', 10, 2);

function custom_form_cc_ach_gift($cc_fields, $payment_id)
{
    if (is_add_payment_method_page()) {
	    $cc_fields = [
		    "form" => wgc_get_template('payment-fields-add-payment-method')
	    ];
        return $cc_fields;
    }

    $cc_fields = [
        "form" => wgc_get_template('payment-fields')
    ];

	if ( !empty(wgc_get_option(WGC_KEY_WALLETS_ENABLED)) ) {
		$cc_fields["wallets"] = wgc_get_template( 'wallets' );
	}

    return $cc_fields;
}
