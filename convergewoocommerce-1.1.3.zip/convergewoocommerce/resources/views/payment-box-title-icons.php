<?php /** @noinspection PhpUndefinedVariableInspection */
return '
    <span class="title-icon">
        <img alt="visa" class="card-image grayscale" id="visa" src="' . $visa . '">
        <img alt="mastercard" class="card-image grayscale" id="mastercard" src="' . $masterCard . '">
        <img alt="discover" class="card-image grayscale" id="discover" src="' . $discover . '">
        <img alt="american-express" class="card-image grayscale" id="american-express" src="' . $americanExpress . '">
    </span>
';