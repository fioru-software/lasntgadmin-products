<?php

if (
    ! isset( $acsUrl )
    || ! isset( $pareq )
    || ! isset( $md )
    || ! isset( $termUrl )
) {
    die;
}
?>

<form id="converge-three-d-secure-redirect" action="<?php echo $acsUrl; ?>" method="post">
    <input name="PaReq" type="hidden" value="<?php echo $pareq; ?>"/>
    <input name="MD" type="hidden" value="<?php echo $md; ?>"/>
    <input name="TermUrl" type="hidden" value="<?php echo $termUrl; ?>"/>
</form>
<script type="text/javascript">
    document.getElementById('converge-three-d-secure-redirect').submit();
</script>