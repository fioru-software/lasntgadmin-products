<?php

if (
    ! isset( $params['PaRes'] )
    || ! isset( $returnUrlFormAction )
) {
    die;
}
?>
<!doctype html>
<html lang="en">
<head>
	<script src="<?php echo $checkoutJsUrl; ?>"></script>
</head>
<body>
<p>Please wait while we process your payment ...</p>
<script type="text/javascript">
    var ifGiftNeedRefund = false;
    function sendOrderToWoo(response, context = '') {
        var form = document.getElementById('form');

        var formElem = document.createElement('input');
        formElem.setAttribute('type', 'hidden');
        formElem.setAttribute('name', 'converge_response');
        formElem.setAttribute('value', JSON.stringify(response));
        form.append(formElem);

        var formElem = document.createElement('input');
        formElem.setAttribute('type', 'hidden');
        formElem.setAttribute('name', 'context');
        formElem.setAttribute('value', context);
        form.append(formElem);

        if (ifGiftNeedRefund) {
            var formElem = document.createElement('input');
            formElem.setAttribute('type', 'hidden');
            formElem.setAttribute('name', 'refund_gift');
            formElem.setAttribute('value', 'true');
            form.append(formElem);
        }

        form.submit();
    }

    function threeDSecure() {
        var paRes = '<?php echo $params['PaRes'] ?>';
        ConvergeEmbeddedPayment.threeDSecureReturn(paRes, {
            onError: function (response) {
                ifGiftNeedRefund = true;
                sendOrderToWoo(response, '3ds1 return - error');
            },
            onDeclined: function (response) {
                ifGiftNeedRefund = true;
                sendOrderToWoo(response, '3ds1 return - declined');
            },
            onApproval: function (response) {
                sendOrderToWoo(response, '3ds1 return - approval');
            }
        });
    }

    window.onload = function () {
        threeDSecure();
    };
</script>

<form id="form" action="<?php echo $returnUrlFormAction; ?>" method="post">
    <input type="hidden" name="cc_authenticated" value="1">
</form>
</body>
</html>