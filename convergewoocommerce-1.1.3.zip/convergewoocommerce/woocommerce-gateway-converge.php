<?php
/** @noinspection DuplicatedCode */

/**
 * Woocommerce Elavon Converge NA Gateway -  bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              http://www.elavon.com
 * @since             1.0.0
 * @package           Woocommerce_Gateway_Converge
 *
 * @wordpress-plugin
 * Plugin Name:       WooCommerce Elavon Converge NA Gateway
 * Plugin URI:        https://woocommerce.com/product-category/woocommerce-extensions
 * Description:       Receive credit card payments using Elavon Converge NA Gateway.
 * Version:           1.1.3
 * Author:            Elavon
 * Author URI:        http://www.elavon.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       elavon-converge-gateway
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

define('WGC_DIR_PATH', plugin_dir_path(__FILE__));
define('WGC_VERSION', '1.1.3');
define('WGC_PAYMENT_NAME', 'elavon-converge-gateway');
define('WGC_MAIN_FILE', __FILE__);


/**
 * WooCommerce fallback notice.
 *
 * @return string
 * @since 4.1.2
 */
function woocommerce_converge_missing_wc_notice()
{
    echo '<div class="error"><p><strong>' . sprintf(esc_html__('Elavon Converge NA Gateway requires WooCommerce to be installed and active. You can download %s here.',
            'elavon-converge-gateway'),
            '<a href="https://woocommerce.com/" target="_blank">WooCommerce</a>') . '</strong></p></div>';
}


add_action('plugins_loaded', 'init_woocommerce_gateway_converge');
add_filter('woocommerce_payment_gateways', 'add_gateway_class_to_payment_methods');
add_filter('plugin_action_links', 'add_settings_to_plugins_list', 10, 5);

require_once __DIR__ . '/includes/wc-converge-ajax-hooks.php';
require_once __DIR__ . '/includes/wc-converge-payment-form.php';


 function wgc_add_product_fields_admin() {
    add_action( 'woocommerce_product_options_inventory_product_data',  'wgc_product_fields' );
    add_action( 'woocommerce_process_product_meta', 'wgc_save_field_input'  );
}

function wgc_product_fields() {
    wp_nonce_field( basename( __FILE__ ), 'wgc_product_fields_nonce' );
    woocommerce_wp_text_input(
        array(
            'id'                => 'wgc-commodity-code',
            'label'             => __( 'Commodity code', 'elavon-converge-gateway' ),
            'placeholder'       => '',
            "custom_attributes" => [
                "maxlength" => 12,
            ],
        )
    );
    woocommerce_wp_text_input(
        array(
            'id'                => 'wgc-uom-code',
            'label'             => __( 'Unit of measure code', 'elavon-converge-gateway' ),
            'placeholder'       => '',
            "custom_attributes" => [
                "maxlength" => 3,
            ],
        )
    );
}

function wgc_save_field_input( $post_id ) {
    if ( isset( $_POST['wgc_product_fields_nonce'] ) && wp_verify_nonce( sanitize_key( $_POST['wgc_product_fields_nonce'] ), basename( __FILE__ ) ) ) {
        if ( isset( $_POST['wgc-commodity-code'] ) ) {
            $woo_uom_input = sanitize_text_field( wp_unslash( $_POST['wgc-commodity-code'] ) );
            update_post_meta( $post_id, 'wgc-commodity-code', esc_attr( $woo_uom_input ) );
        }

        if ( isset( $_POST['wgc-uom-code'] ) ) {
            $woo_uom_input = sanitize_text_field( wp_unslash( $_POST['wgc-uom-code'] ) );
            update_post_meta( $post_id, 'wgc-uom-code', esc_attr( $woo_uom_input ) );
        }

    }
}

/**
 * @noinspection PhpUnused
 * @return void
 */
function init_woocommerce_gateway_converge()
{
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', 'woocommerce_converge_missing_wc_notice');
        return;
    }


    // Set up localisation.
    $textDomain = WGC_PAYMENT_NAME;
    unload_textdomain($textDomain);
    load_plugin_textdomain($textDomain, false, basename(WGC_DIR_PATH) . '/i18n/languages');

    define('WGC_MODULE_MAIN_FILE', __FILE__);

    // Logging handlers & middleware's
    require_once 'includes/logging/middleware/AbstractMiddleware.php';
    require_once 'includes/logging/middleware/RequestMiddleware.php';
    require_once 'includes/logging/middleware/ResponseMiddleware.php';
    require_once 'includes/logging/middleware/Handler.php';
    require_once 'includes/logging/ConvergeResponseLogger.php';

    require_once 'includes/class-wc-converge-gateway-helper.php';
    require_once 'includes/abstracts/abstract-wc-converge-payment-gateway.php';
    require_once 'includes/admin/class-wc-converge-gateway-settings.php';
	require_once 'includes/class-wc-converge-encryption.php';
    require_once 'includes/class-wc-converge-gateway.php';
	require_once 'includes/class-wc-converge-response-handler.php';
	require_once 'includes/class-wc-converge-lightbox-response.php';
	require_once 'includes/class-wc-payment-token-converge-gateway-storedcard.php';


    require_once(WGC_DIR_PATH . 'includes/wc-converge-gateway-constants.php');
    require_once(WGC_DIR_PATH . 'includes/functions-wc-converge-gateway.php');
    require_once __DIR__ . '/vendor/autoload.php';
    include_once 'includes/class-wc-gateway-converge-admin-order-converge-status.php';

    include_once 'includes/class-wc-gateway-converge-order-wrapper.php';
    include_once 'includes/class-wc-gateway-converge-admin-order-actions.php';
    include_once 'includes/class-wc-gateway-converge-api.php';
    include_once 'includes/class-wc-converge-giftcard-handler.php';

    require_once __DIR__ . '/includes/wc-converge-ajax-hooks.php';

    wgc_add_product_fields_admin();

}

/**
 * @noinspection PhpUnused
 * @param array $actions
 * @param string $plugin_file
 * @return array
 */
function add_settings_to_plugins_list($actions, $plugin_file)
{
    static $plugin;
    if (!isset($plugin)) {
        $plugin = plugin_basename(__FILE__);
    }

    if ($plugin == $plugin_file) {
        $page = admin_url(sprintf('admin.php?page=wc-settings&tab=checkout&section=%s', WGC_PAYMENT_NAME));
        $settings = ['settings' => '<a href=' . $page . '>' . __('Settings', 'elavon-converge-gateway') . '</a>'];
        $actions = array_merge($settings, $actions);
    }
    return $actions;
}

/**
 * @noinspection PhpUnused
 * @param array $methods
 * @return array
 */
function add_gateway_class_to_payment_methods($methods)
{
    $methods[] = 'WC_Converge_Gateway';
    return $methods;
}
