=== WooCommerce Admin Custom Order Fields ===
Author: skyverge
Tags: woocommerce
Requires at least: 5.2
Tested up to: 6.0.1
Requires PHP: 7.0

Easily add custom fields to your WooCommerce orders and display them in the Orders admin, the My Orders section, and even order emails!

See https://docs.woocommerce.com/document/woocommerce-admin-custom-order-fields/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-admin-custom-order-fields' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
