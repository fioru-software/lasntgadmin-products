=== WooCommerce Gateway Purchase Order ===
Contributors:
Donate link:
Tags:
Requires at least: 3.9.0
Tested up to: 6.0
Stable tag: 1.1.3
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Accept payments via purchase order using WooCommerce.

== Description ==

Accept payments via purchase order using WooCommerce.

Looking for a helping hand? [View plugin documentation](https://docs.woocommerce.com/document/woocommerce-purchase-order-gateway/).

== Upgrade Notice ==

= 1.0.0 =
* 2014-08-07
* Initial release. Woo!

== Changelog ==

= 1.0.0 =
* 2014-08-07
* Initial release. Woo!
