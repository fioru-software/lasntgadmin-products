=== WooCommerce Order Status Manager ===
Author: skyverge
Tags: woocommerce
Requires at least: 5.2
Tested up to: 6.0.1
Requires PHP: 7.0

Easily create custom order statuses and trigger custom emails when order status changes

See https://docs.woocommerce.com/document/woocommerce-order-status-manager/ for full documentation.

== Installation ==

1. Upload the entire 'wocoommerce-order-status-manager' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
